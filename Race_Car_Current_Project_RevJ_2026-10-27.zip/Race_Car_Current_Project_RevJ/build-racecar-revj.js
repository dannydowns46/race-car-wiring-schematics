// Reproducible KiCad 7 harness draft. Native symbols, pins, wires and global nets.
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const dir=path.join(__dirname,'Race_Car_RevJ');fs.mkdirSync(dir,{recursive:true});
const project='Race_Car_RevJ',root=crypto.randomUUID(),q=JSON.stringify;
const uuid=()=>crypto.randomUUID(),f=n=>Number(n.toFixed(4));
const fx=(s=1.27,extra='')=>`(effects (font (size ${s} ${s})) ${extra})`;
const nets=new Map(),parts=[],pages=[];
const prior=JSON.parse(fs.readFileSync(path.join(__dirname,'Race_Car_RevI/Design_Data.json')));
const oldIds=new Map(prior.nets.map(n=>[n.name,n.id]));
// Explicit maintained J additions; never recycle retired W004 external-to-chassis loop.
oldIds.set('TRANS_TEMP_SIG','W135');oldIds.set('GT_EXTERNAL_BLUE_LOOP','W136');oldIds.set('TC_TRIM_SIG','W137');
oldIds.set('MAIN_FUSED_BUS','W003'); // K1 removed by owner; retain downstream bus identity. W128 retired.
let nextId=138;
const readable=Object.fromEntries(JSON.parse(fs.readFileSync(path.join(__dirname,'Race_Car_Readable/Readable_Names.json'))).map(n=>[n.reference,n.name]));
Object.assign(readable,{J12:'Haltech R3 - integrated PDM outputs',U20:'Haltech PD16 - main power',J40:'Haltech PD16 - connector A',J41:'Haltech PD16 - 25 A power outputs',M6:'Radiator fan 1',M7:'Radiator fan 2',F50:'PD16 main supply fuse',B30:'Transaxle gear-position sensor',B31:'HGT shift-force sensing knob',U10:'Haltech iC-7 digital dash',B5:'Haltech HT-010206 intake air temperature',B11:'Haltech HT-010910 fuel pressure',B9:'Single wideband O2 / R3 onboard',B32:'HT-010306 engine oil temperature',B33:'HT-010306 transmission oil temperature',U23:'Haltech TMS-4 receiver / HT-011600',U21:'WolfBox G900 Pro mirror and front camera',U24:'WolfBox G900 Pro hardwire converter',U25:'WolfBox rear camera',H30:'Left LED headlight',H37:'Right LED headlight',H31:'Left tail LED bulb',H34:'Left brake LED bulb',H35:'Right tail LED bulb',H36:'Right brake LED bulb'});
Object.assign(readable,{F2:'Shared starter / charging cable fuse'});
Object.assign(readable,{U2:'CARTEK GT battery isolator',S40:'BAOMAIN latching stop / NC',TB1:'Sierra FS46540 / PROPOSED',TB2:'Summit SUM-900533 / PROPOSED'});
Object.assign(readable,{U3:'Cole Hersee 24059 starter relay',D60:'Starter-relay coil suppression diode'});
Object.assign(readable,{S50:'Traction-control level selector'});
const stockHarness=JSON.parse(fs.readFileSync(path.join(dir,'Stock_Engine_Harnesses.json')));
for(let i=1;i<=8;i++){readable['IC'+i]='Stock L94 coil - cylinder '+i;readable['INJ'+i]='LS3 injector - cylinder '+i;}
for(const bank of stockHarness.coil_banks)readable[bank.ref]=bank.label;
function net(n){if(!nets.has(n))nets.set(n,{id:oldIds.get(n)||('W'+String(nextId++).padStart(3,'0')),name:n,endpoints:[]});return nets.get(n).id+'_'+n;}
const P=(num,func,n,status='TBD cavity')=>({num:String(num),func,net:n,status});
const V=(num,func,n)=>P(num,func,n,'Documented cavity');
class Page {
 constructor(file,title,sub){this.file=file;this.title=title;this.id=uuid();this.sheetId=uuid();this.items=[];this.libs=[];this.number=pages.length+2;pages.push(this);this.text(title,17.78,20.32,2.54);this.text(sub,17.78,27.94,1.27);this.text('REV J  |  DESIGN REVIEW DRAFT  |  TBD = NOT RELEASED FOR WIRING',17.78,35.56,1.27);}
 text(t,x,y,s=1.27){this.items.push(`(text ${q(t)} (at ${f(x)} ${f(y)} 0) ${fx(s,'(justify left)')} (uuid ${uuid()}))`);}
 notes(lines,y=238.76){lines.forEach((t,i)=>this.text(t,17.78,y+i*5.08,1.15));}
 wire(x,y,a,b){this.items.push(`(wire (pts (xy ${f(x)} ${f(y)}) (xy ${f(a)} ${f(b)})) (stroke (width 0) (type default)) (uuid ${uuid()}))`);}
 label(n,x,y){this.items.push(`(global_label ${q(net(n))} (shape input) (at ${f(x)} ${f(y)} 180) ${fx(1.0,'(justify right)')} (uuid ${uuid()}) (property "Intersheetrefs" "\${INTERSHEET_REFS}" (at ${f(x+1.27)} ${f(y+1.5)} 0) ${fx(0.85,'(justify left)')}))`);}
 nc(x,y){this.items.push(`(no_connect (at ${f(x)} ${f(y)}) (uuid ${uuid()}))`);}
 block(ref,val,x,y,pins,opt={}) {
  const w=opt.w||55.88,step=opt.step||6.35,h=Math.max(12.7,(pins.length+1)*step),lib=ref.replace(/[^A-Za-z0-9]/g,'_');
  const libpins=pins.map((p,i)=>`(pin passive line (at -5.08 ${f(-(i+1)*step)} 0) (length 5.08) (name ${q(p.func)} ${fx(1.05)}) (number ${q(p.num)} ${fx(0.95)}))`).join('\n');
  const common=`(pin_names (offset 1.27)) (in_bom yes) (on_board yes) (property "Reference" ${q(ref)} (at 0 0 0) ${fx()}) (property "Value" ${q(val)} (at 0 0 0) ${fx()})`;
  this.libs.push(`(symbol "RaceCar:${lib}" ${common} (symbol "${lib}_0_1" (rectangle (start 0 0) (end ${w} ${-h}) (stroke (width 0.254) (type default)) (fill (type background)))) (symbol "${lib}_1_1" ${libpins}))`);
  this.items.push(`(symbol (lib_id "RaceCar:${lib}") (at ${x} ${y} 0) (unit 1) (in_bom yes) (on_board yes) (uuid ${uuid()}) (property "Reference" ${q(ref)} (at ${f(x+w/2)} ${f(y-7.62)} 0) ${fx(0.95,'hide')}) (property "Technical ID" ${q(ref+' | '+val)} (at ${f(x+w/2)} ${f(y-7.62)} 0) ${fx(0.95)}) (property "Value" ${q(readable[ref]||val)} (at ${f(x+w/2)} ${f(y-3.81)} 0) ${fx(ref.startsWith('INJ')||ref.startsWith('IC')?1.4:1.65)}) ${pins.map(p=>`(pin ${q(p.num)} (uuid ${uuid()}))`).join(' ')} (instances (project "${project}" (path "/${root}/${this.sheetId}" (reference ${q(ref)}) (unit 1)))))`);
  const component={ref,value:readable[ref]||val,technical_label:val,page:this.number,file:this.file,pins};parts.push(component);
  pins.forEach((p,i)=>{const py=f(y+(i+1)*step);if(p.net){this.wire(x-5.08,py,x-12.7,py);this.label(p.net,x-12.7,py);net(p.net);nets.get(p.net).endpoints.push({ref,pin:p.num,function:p.func,page:this.number,status:p.status});}else this.nc(x-5.08,py);});
  return h;
 }
 pair(ref,val,x,y,n1,n2,kind='fuse'){
  const lib=ref,w=10.16,shape=kind==='switch_nc'?`(polyline (pts (xy -5.08 0) (xy 5.08 0)) (stroke (width 0.254) (type default)) (fill (type none)))`:kind==='switch'?`(polyline (pts (xy -5.08 0) (xy 4.0 3.0)) (stroke (width 0.254) (type default)) (fill (type none)))`:`(rectangle (start -3.81 1.27) (end 3.81 -1.27) (stroke (width 0.254) (type default)) (fill (type none))) (polyline (pts (xy -5.08 0) (xy 5.08 0)) (stroke (width 0.254) (type default)) (fill (type none)))`;
  this.libs.push(`(symbol "RaceCar:${lib}" (pin_names hide) (in_bom yes) (on_board yes) (property "Reference" ${q(ref)} (at 0 0 0) ${fx()}) (property "Value" ${q(val)} (at 0 0 0) ${fx()}) (symbol "${lib}_0_1" ${shape}) (symbol "${lib}_1_1" (pin passive line (at -10.16 0 0) (length 5.08) (name "~" ${fx()}) (number "1" ${fx(1)})) (pin passive line (at 10.16 0 180) (length 5.08) (name "~" ${fx()}) (number "2" ${fx(1)}))))`);
  this.items.push(`(symbol (lib_id "RaceCar:${lib}") (at ${x} ${y} 0) (unit 1) (in_bom yes) (on_board yes) (uuid ${uuid()}) (property "Reference" ${q(ref)} (at ${x} ${y-10.16} 0) ${fx(0.95,'hide')}) (property "Technical ID" ${q(ref+' | '+val)} (at ${x} ${y-10.16} 0) ${fx(0.95)}) (property "Value" ${q(readable[ref]||val)} (at ${x} ${y-6.35} 0) ${fx(1.65)}) (pin "1" (uuid ${uuid()})) (pin "2" (uuid ${uuid()})) (instances (project "${project}" (path "/${root}/${this.sheetId}" (reference ${q(ref)}) (unit 1)))))`);
  this.wire(x-10.16,y,x-20.32,y);this.label(n1,x-20.32,y);this.wire(x+10.16,y,x+20.32,y);this.wire(x+20.32,y,x+20.32,y+7.62);this.label(n2,x+20.32,y+7.62);
  const pins=[P(1,'IN',n1,'Functional terminal'),P(2,'OUT',n2,'Functional terminal')];parts.push({ref,value:readable[ref]||val,technical_label:val,page:this.number,file:this.file,pins});pins.forEach(p=>{net(p.net);nets.get(p.net).endpoints.push({ref,pin:p.num,function:p.func,page:this.number,status:p.status});});
 }
 save(){fs.writeFileSync(path.join(dir,this.file+'.kicad_sch'),`(kicad_sch (version 20230121) (generator racecar_draft) (uuid ${this.id}) (paper "A3") (title_block (title ${q(this.title)}) (date "2026-10-27") (rev "J - REVIEW") (company "Danny's Race Car | Harness design") (comment 1 "DRAFT - NOT A BUILD RELEASE")) (lib_symbols ${this.libs.join('\n')}) ${this.items.join('\n')})`);}
}

// 02 - selected negative isolation, physical engine-power contactor and protected feeders.
let p=new Page('02_Power','02 / BATTERY, ISOLATION AND STARTER','CARTEK GT is the master isolator; K1 removed. F0 feeds TB2 directly. Returns are downstream of isolation.');
p.block('BT1','BRAILLE G30H',76.2,55.88,[P('+','POSITIVE','BATT_RAW'),P('-','ONLY TO U2 M8','BATT_NEG')]);
p.block('G1','79376G / ONE-WIRE',345.44,55.88,[P('B+','CHARGE OUTPUT','ALT_BPLUS'),P('CASE','CASE RETURN','ENGINE_GND')]);
p.pair('F0','MAIN BUS FUSE / SELECT',127,111.76,'BATT_RAW','MAIN_FUSED_BUS');
p.text('PHYSICAL ROUTE: battery-side BATT_RAW block -> F2 -> M1 battery B+ stud -> F3 -> G1 B+.',17.78,94.0,1.15);
p.pair('F3','ALT BRANCH FUSE / AT STARTER',345.44,111.76,'STARTER_FEED','ALT_BPLUS');
p.pair('F1','R3 FEED / SELECT',127,149.86,'MAIN_FUSED_BUS','R3_MAIN_POS');
p.block('U3','COLE HERSEE 24059 / 12V / 85A',218.44,124.46,[P('PWR','LARGE 5/16-24 / F5 IN','START_DRIVER_FEED','Functional stud tag; large contact stud, not a factory pin number'),P('GND','SMALL 10-32 / COIL MINUS','VEHICLE_RETURN','Functional stud tag; small insulated coil stud, not a factory pin number'),P('CMD','SMALL 10-32 / COIL PLUS','START_CMD','Functional stud tag; small insulated coil stud, not a factory pin number'),P('OUT','LARGE 5/16-24 / TO SOL','START_SOL','Functional stud tag; large contact stud, not a factory pin number')],{w:76.2});
p.block('D60','1N5408 / BAND TO CMD',218.44,93.98,[P('K','BANDED CATHODE / COIL PLUS','START_CMD','Diode lead: body band identifies cathode K'),P('A','ANODE / COIL MINUS','VEHICLE_RETURN','Diode lead: unbanded anode A')],{w:76.2,step:5.08});
p.text('U3 / 24059 BULKHEAD RELAY WIRING',187.96,50.8,1.4);
['Large PWR <- F5/2; large OUT -> M1 SOL.',
 'Small CMD <- R3 A18/HBO5 (+12V ON).',
 'Small GND -> VEHICLE_RETURN (not case).',
 'D60 band/K -> CMD; unbanded/A -> GND.',
 'PWR/OUT/CMD/GND are installer tags.',
 '12V coil: 17.5 ohm / ~0.69A calculated.'].forEach((t,i)=>p.text(t,187.96,57.15+i*5.08,1.12));
p.block('M1','VW HIGH-TORQUE STARTER',345.44,149.86,[P('B+','SHARED BATTERY B+ STUD','STARTER_FEED'),P('SOL','SOLENOID','START_SOL'),P('CASE','MOTOR RETURN','ENGINE_GND')]);
p.block('J1','R3 MAIN SURLOK',76.2,180.34,[V('+','R3 BATTERY +','R3_MAIN_POS'),V('-','ISOLATOR VEHICLE SIDE','VEHICLE_RETURN')]);
p.pair('F5','START DRIVER FUSE / SELECT',218.44,187.96,'MAIN_FUSED_BUS','START_DRIVER_FEED');
p.pair('F2','SHARED CABLE FUSE / AT BATTERY',345.44,210.82,'BATT_RAW','STARTER_FEED');
p.block('J2','GROUND STRAP / ENGINE',76.2,220.98,[P('BAT','VEHICLE RETURN BUS','VEHICLE_RETURN'),P('ENG','ENGINE END','ENGINE_GND')]);
p.block('J3','GROUND STRAP / CHASSIS',218.44,220.98,[P('BAT','VEHICLE RETURN BUS','VEHICLE_RETURN'),P('CH','CHASSIS END / U2 CASE','CHASSIS_GND')]);
p.notes(['U2 isolates NEGATIVE. Positive starter/alternator cables remain battery-connected when OFF: insulate, route and protect them.',
'GT M6_IGN -> S1 -> R3 A13 is the engine-stop control. F0 -> TB2 is permanently battery-positive when connected.',
'F5 protects the relay-contact/solenoid branch; value TBD. Estimated 30A solenoid pull-in is NOT a measurement. No motor current through U3.',
'K1 omitted by owner. Verify R3 ignition-OFF stops injection/ignition/fuel and PD16 loads, including CAN-loss/shutdown timing.',
'No wire except U2 M8 may return to BT1 negative. R3/PD16 and every load use VEHICLE_RETURN; verify with all service cables.',
'W011: one shared start/charge trunk. F3 branches at M1 BATTERY B+ stud, never SOL or motor-side stud. Size/protection TBD.'],251.46);

// 03 - pin-accurate R3 connectors, assignments are draft design choices.
p=new Page('03_R3_Pin_Allocation','03 / NEXUS R3 PIN ALLOCATION','ONE R3 with owner-selected HT-183200 flying-lead harness. Supplied controller leads need routing and free-end termination.');
const a=[];for(let i=1;i<=8;i++)a.push(V(i,'INJECTOR '+i,'INJ_'+i));
a.push(V(9,'DPO1 / SPARE',null),V(10,'GROUND OUT / SHIELDS','R3_SHIELD_RETURN'),V(11,'GROUND OUT / CAN','R3_CAN_RETURN'),V(12,'DPO2 / SPARE',null),V(13,'IGN SWITCH INPUT','R3_WAKE'),V(14,'DPO3 / SPARE',null),V(15,'DPO4 / SPARE',null),V(16,'DPO5 / SPARE',null),V(17,'DPO6 / SPARE',null),V(18,'HBO5 / START CMD','START_CMD'),V(19,'HBO1 / DBW MOTOR A','DBW_MA'),V(20,'HBO2 / DBW MOTOR B','DBW_MB'),V(21,'HBO3 / ABS IGNITION','ABS_IGN_SOURCE'),V(22,'HBO4 / COCKPIT 12V','COCKPIT_12V'),V(23,'CAN1 HIGH','CAN1_H'),V(24,'CAN1 LOW','CAN1_L'),V(25,'HBO6 / PD16 WAKE','PD16_WAKE'),V(26,'IGN SOURCE / UNUSED',null));
for(let i=1;i<=8;i++)a.push(V(i+26,'IGNITION '+i,'IGN_'+i));
p.block('J10','R3 A / AMP34 KEY1',109.22,50.8,a,{step:5.08,w:76.2});
const cn=[V(1,'TRIGGER +','CRANK_SIG'),V(2,'TRIGGER - / HOLD',null),V(3,'HOME +','CAM_SIG'),V(4,'HOME - / HOLD',null),V(5,'SPI1 / TC ROTARY - PULLUP OFF','TC_TRIM_SIG'),V(6,'SPI2 / BRAKE REQUEST','BRAKE_REQUEST'),V(7,'SPI3 / SPARE',null),V(8,'SPI4 / SPARE',null),V(9,'SENSOR 8V / SPARE',null)];
const avis=['APP1','APP2','TPS1','TPS2','OIL_PRESS','FUEL_PRESS','COOLANT_TEMP','AIR_TEMP'];avis.forEach((n,i)=>cn.push(V(10+i,'AVI'+(i+1)+' / '+n,n)));cn.push(V(18,'AVI9 / SPARE - ONBOARD MAP',null));
cn.push(V(19,'SPI5 / SPARE',null),V(20,'SPI6 / SPARE',null),V(21,'CAN2 HIGH','CAN2_H'),V(22,'CAN2 LOW','CAN2_L'),V(23,'KNOCK1','KNOCK1'),V(24,'KNOCK2','KNOCK2'),V(25,'SENSOR 5V / 200mA','R3_REF5'),V(26,'SIGNAL GROUND','R3_SG'),V(27,'AVI10 / GEAR','GEAR_SIG'),V(28,'AVI11 / SHIFT FORCE','SHIFT_FORCE_SIG'));
['HTR_PLUS','INPUT','PUMP','NERNST','HTR_MINUS','CAL'].forEach((n,i)=>cn.push(V(29+i,'WBI1 / '+n,'WBO_'+n)));
p.block('J11','R3 C / AMP34 KEY2',307.34,50.8,cn,{step:5.08,w:86.36});
p.notes(['One wideband: onboard WBI1 / C29-C34. No external WB controller. Confirm sensor type/adapter; configure NSP.',
'A10/A11 are ground OUTPUTS: do not bond them directly to battery, engine or chassis. C26 is sensor return only.',
'DBW HBO1/2; HBO3 = ABS ignition; HBO4 = cockpit; HBO6 = PD16 wake. Separate protected feeds; verify each load.',
'HT-183200 supplies labeled flying leads, CAN plugs and wideband plug. Keep shielding; verify revision, reach and sensor adapters.',
'SPI3-6 remain spare; AVI11/C28 = HGT. A26 is NC: CARTEK U2 M6_IGN is the only source for S1 / R3 A13 (sheet 18).']);

// 04 engine distribution and complete 8 cylinder device circuits.
p=new Page('04_Engine_Power','04 / ENGINE POWER, INJECTION AND IGNITION','2011 L94 with LS3 cam/intake/throttle body  |  Donor connectors reused only after condition and cavity checks.');
p.block('J12','R3 E / DTP4',88.9,50.8,[V(1,'HCO1 / INJECTORS','INJECTOR_SUPPLY'),V(2,'HCO2 / COILS','COIL_SUPPLY'),V(3,'HCO3 / DW200','HP_PUMP_SUPPLY'),V(4,'HCO4 / DW100 LIFT 1','LIFT_SUPPLY')]);


p.text('ELECTRONIC OUTPUT PROTECTION / NO DOWNSTREAM BANK FUSES',218.44,55.88,1.4);
p.text('HCO1 -> all injector +12V branches; HCO2 -> all coil +12V branches.',218.44,66.04,1.15);
p.text('Set fuse current / startup time / delay / retries in NSP.',218.44,76.2,1.15);
p.text('Each channel senses the SUM of its connected loads.',218.44,86.36,1.15);
p.text('All branch wires and contacts must tolerate the programmed trip curve.',218.44,96.52,1.15);
p.text('25A is output capacity, NOT a selected protection setting.',218.44,106.68,1.15);
for(let i=1;i<=8;i++){
 const x=66.04+((i-1)%4)*99.06,y=124.46+Math.floor((i-1)/4)*62.23;
 p.block('INJ'+i,'INJECTOR / CYL '+i,x,y,[P('PWR','SUPPLY','INJECTOR_SUPPLY'),P('DRV','LOW-SIDE DRIVER','INJ_'+i)],{w:35.56,step:5.08});
 p.block('IC'+i,'COIL / CYL '+i,x,y+26.67,[P('PWR','SUPPLY','COIL_SUPPLY'),P('SIG','IGN SIGNAL','IGN_'+i),P('PG','POWER RETURN','ENGINE_GND'),P('SG','SIGNAL RETURN','R3_SG')],{w:35.56,step:4.445});
}
p.notes(['HOLD P02: HCO1/2 must protect retained OEM wire/contact branches. Stock L94 coil and injector wiring is retained; see sheet 19.',
'PWR/DRV/SIG/PG/SG remain functional device IDs. Stock bank connector reference cavities are on sheet 19; inspect donor before wiring.',
'IGN and INJ channel number = cylinder number; firing order is an ECU configuration item, not a reason to reorder wires.',
'Do not merge HCO1/HCO2 through donor shared feeds. Coil low-reference grounding remains HOLD pending exact coil/R3 evidence.'],251.46);

// 05 sensor network
p=new Page('05_Engine_Sensors','05 / ENGINE SENSORS AND WIDEBAND','R3 analog allocation is on sheet 03. Sensor model, reference voltage and calibration must match before connection.');
const sb=(ref,val,x,y,pins)=>p.block(ref,val,x,y,pins,{w:48.26,step:6.35});
sb('B1','CRANK / GM 12703627',88.9,55.88,[P('A','TRIGGER SIGNAL','CRANK_SIG','GM application cavity; check mating view'),P('B','SIGNAL RETURN','R3_SG','GM application cavity; check mating view'),P('C','REGULATED +5V','R3_REF5','GM application cavity; check mating view')]);
sb('B2','CAM / GM 12591720',218.44,55.88,[V('A','REGULATED +5V','R3_REF5'),V('B','SIGNAL RETURN','R3_SG'),V('C','HOME SIGNAL','CAM_SIG')]);
p.text('MAP SENSOR IS INSIDE NEXUS R3',307.34,55.88,1.4);
p.text('Onboard 4-bar absolute MAP selected in NSP.',307.34,66.04,1.15);
p.text('Intake manifold -> pressure hose -> R3 MAP barb.',307.34,73.66,1.15);
p.text('Pneumatic connection only; no external sensor wires.',307.34,81.28,1.15);
p.text('AVI9 / C18 spare (onboard MAP). One wideband only.',307.34,88.9,1.15);
sb('B4','COOLANT TEMP',88.9,114.3,[P('SIG','THERMISTOR SIGNAL','COOLANT_TEMP'),P('RET','SIGNAL RETURN','R3_SG')]);
sb('B5','HT-010206 / INTAKE AIR',218.44,114.3,[V(1,'AIR TEMP SIGNAL','AIR_TEMP'),V(2,'SIGNAL GROUND','R3_SG')]);
sb('B6','OIL PRESSURE / TBD',345.44,114.3,[P('V+','5V REFERENCE','R3_REF5'),P('SIG','PRESSURE SIGNAL','OIL_PRESS'),P('RET','SIGNAL RETURN','R3_SG')]);
sb('B7','KNOCK / BANK 1',88.9,172.72,[P('SIG','KNOCK SIGNAL','KNOCK1'),P('RET','SIGNAL RETURN','R3_SG')]);
sb('B8','KNOCK / BANK 2',218.44,172.72,[P('SIG','KNOCK SIGNAL','KNOCK2'),P('RET','SIGNAL RETURN','R3_SG')]);
sb('B9','ONE WIDEBAND / R3 WBI1',345.44,172.72,['HTR_PLUS','INPUT','PUMP','NERNST','HTR_MINUS','CAL'].map(n=>P(n,n,'WBO_'+n)));
p.notes(['Crank A -> C1; B -> C26; C -> C25. Cam A -> C25; B -> C26; C -> C3. W078/W079 retired; never reuse.',
'Shield crank/cam/knock cables; shield/drain to R3 A10 only at ECU end. Sensor return remains C26.',
'Owner confirms crank GM12703627 and cam GM12591720. Verify molded cavities; C25 200mA includes BOTH sensors.',
'WBI1 C29-C34: HTR+ / INPUT / PUMP / NERNST / HTR- / CAL. Retain matching sensor/adapter; no separate power/ground.',
'HT-010206: C17, 1k pull-up, GM Air calibration. O2: select LSU4.9 or NTK in NSP; exact pack/cavities and exhaust location TBD.']);

// 06 DBW; owner removes clutch/neutral start switch S2.
p=new Page('06_DBW','06 / DRIVE-BY-WIRE','Pedal GM 19417903  |  Stock LS3 throttle body  |  Function labels below are NOT physical cavity numbers.');
p.block('B10','C6 PEDAL / GM 19417903',101.6,66.04,[P('REF1','APP1 REFERENCE','R3_REF5'),P('SIG1','PEDAL TRACK 1','APP1'),P('RET1','APP1 RETURN','R3_SG'),P('REF2','APP2 REFERENCE','R3_REF5'),P('SIG2','PEDAL TRACK 2','APP2'),P('RET2','APP2 RETURN','R3_SG')],{w:73.66});
p.block('M2','LS3 THROTTLE BODY',312.42,66.04,[P('MA','MOTOR A','DBW_MA'),P('MB','MOTOR B','DBW_MB'),P('REF','TPS REFERENCE','R3_REF5'),P('TPS1','POSITION TRACK 1','TPS1'),P('TPS2','POSITION TRACK 2','TPS2'),P('RET','TPS RETURN','R3_SG')],{w:73.66});
p.text('S2 REMOVED / NO CLUTCH SWITCH',101.6,154.94,1.52);p.text('R3 C5 / SPI1 now serves S50 TC trim; W046 remains retired.',101.6,162.56);p.text('Fresh start request, engine-not-running and bounded crank remain required.',101.6,170.18);p.text('No clutch/neutral switch input; physical master stop remains independent.',101.6,177.8);
p.notes(['HOLD D01: verify all six pedal cavities and all throttle-body cavities, including motor polarity, before terminating.',
'Pedal pigtail missing: donor connector may be reusable; CPP-LSAPP is a listed candidate. Housing fit does not prove wiring.',
'APP1/APP2 -> C10/C11; TPS1/TPS2 -> C12/C13. No pull-ups assumed for powered position signals.',
'Complete Haltech DBW calibration, track correlation, brake override and fault checks before any powered vehicle test.',
'Owner removes S2 and its two wires. No clutch/neutral start interlock is drawn; SPI1 must not be jumpered.']);

// 07 fuel and fans
p=new Page('07_Fuel_Cooling','07 / FUEL PUMPS, SENDERS AND COOLING','Two DW100 lift pumps -> surge tank -> DW200 feed pump  |  PROFORM 67049 kit: two 67048 brushless puller fans; 10 A each; independent on/off feeds.');

p.text('LIFT PUMPS: SEPARATE PROTECTED CHANNELS',17.78,55.88,1.35);
p.text('Lift 1 = R3 E4; lift 2 = PD16 B4. No F31/F32 inline fuses.',17.78,66.04,1.15);
p.text('Set each trip curve for its own leads; verify cold/hot startup.',17.78,76.2,1.15);
p.block('M3','DW100 / LIFT 1',88.9,96.52,[P('+','PUMP POSITIVE','LIFT_SUPPLY'),P('-','RETURN','VEHICLE_RETURN')]);
p.block('M4','DW100 / LIFT 2',218.44,96.52,[P('+','PUMP POSITIVE','LIFT2_SUPPLY'),P('-','RETURN','VEHICLE_RETURN')]);
p.block('M5','DW200 / HIGH PRESSURE',345.44,96.52,[P('+','PUMP POSITIVE','HP_PUMP_SUPPLY'),P('-','RETURN','VEHICLE_RETURN')]);
p.block('B11','HT-010910 / 150 PSI FUEL',345.44,50.8,[V('A','SIGNAL GROUND','R3_SG'),V('B','POWER +5V','R3_REF5'),V('C','0.5-4.5V SIGNAL','FUEL_PRESS')],{step:5.08});
p.block('M6','PROFORM 67048 / 10 A',88.9,157.48,[P('+','SWITCHED +12V','FAN1_POWER'),P('-','POWER RETURN','VEHICLE_RETURN')]);
p.block('M7','PROFORM 67048 / 10 A',218.44,157.48,[P('+','SWITCHED +12V','FAN2_POWER'),P('-','POWER RETURN','VEHICLE_RETURN')]);
p.block('B12','FUEL LEVEL / SN38T10',345.44,157.48,[P('SIG','SENDER SIGNAL','LEVEL_SIG'),P('RET','SENDER RETURN','DASH_SG')]);
p.text('HT-010910: A ground / B +5V / C signal -> R3 AVI6 C15. Pull-up OFF; 0.5V = 0 PSI / 4.5V = 150 PSI.',17.78,220.98,1.15);
p.text('Remote-mount HT-010910 with flexible fuel-rated hose; do not mount directly on rail/block. PROFORM pair: 20 A listed.',17.78,227.33,1.15);
p.notes(['Lift pumps now have independent 25A-capable outputs. Select lower trip thresholds from measured load and lead/contact ratings.',
'Fuel permission requires engine run or timed prime AND valid PD16 communication/output status. Trip/CAN loss -> fuel/engine stop.',
'Fuel pumps: prime/run logic with engine-stall shutdown; service prime must be momentary/time-limited and master-stop subordinate.',
'Fans: PD16 B1/B2 supply independent switched +12V (100% when on). No motor-power PWM or external speed-control signal.',
'Fans: 11.43 x 10.75 x 3.25 in each; pair 22.86 x 10.75 in on 24 x 12 in core. Rear clearance confirmed; verify brackets/shroud.']);

// 08 ABS 38-pin single unit
p=new Page('08_ABS_Main','08 / DELTA ABS GEN 2 MAIN CONNECTOR','Bosch 1928405167 / 38 cavities  |  Source: owner-supplied SCS Delta Gen 2 Rev.3 allocation.');
const abs=[V(1,'PUMP SUPPLY / 40A NOTE','ABS_PUMP_POS'),V(2,'FR SPEED OUT / UNUSED',null),V(3,'ABS ACTIVE / UNUSED',null),V(4,'FR SENSOR RETURN','ABS_FR_RET'),V(5,'SLIP 5V REF','ABS_SLIP_5V'),V(6,'PRESSURE 5V REF','ABS_PRESS_5V'),V(7,'SLIP RETURN','ABS_SLIP_RET'),V(8,'FL SENSOR RETURN','ABS_FL_RET'),V(9,'SENSOR RETURN','ABS_SG9'),V(10,'WARNING LAMP SINK','ABS_WARN_SINK'),V(11,'SPEEDOMETER / UNUSED',null),V(12,'RR SPEED OUT / UNUSED',null),V(13,'SUPPLY / 25A NOTE','ABS_MAIN_POS'),V(14,'CAN2 LOW / HOLD','ABS_PORT2_L_TBD'),V(15,'BRAKE LIGHT SINK','BRAKE_REQUEST'),V(16,'RL SPEED OUT / UNUSED',null),V(17,'FL SPEED OUT / UNUSED',null),V(18,'RL SENSOR RETURN','ABS_RL_RET'),V(19,'FL SENSOR SIGNAL','ABS_FL_SIG'),V(20,'CAN1 LOW / HOLD','ABS_PORT1_L_TBD'),V(21,'ANALOG1 / SPARE',null),V(22,'SLIP ANALOG SIGNAL','ABS_SLIP_SIG'),V(23,'ANALOG RETURN','ABS_SG23'),V(24,'ANALOG2 / SPARE',null),V(25,'PUMP GROUND','ABS_POWER_RETURN'),V(26,'CAN2 HIGH / HOLD','ABS_PORT2_H_TBD'),V(27,'ANALOG3 / SPARE',null),V(28,'IGNITION WAKE','ABS_WAKE'),V(29,'RR SENSOR RETURN','ABS_RR_RET'),V(30,'ANALOG4 / SPARE',null),V(31,'RL SENSOR SIGNAL','ABS_RL_SIG'),V(32,'RR SENSOR SIGNAL','ABS_RR_SIG'),V(33,'CAN1 HIGH / HOLD','ABS_PORT1_H_TBD'),V(34,'FR SENSOR SIGNAL','ABS_FR_SIG'),V(35,'ENABLE / GROUND ON','ABS_ENABLE'),V(36,'FRONT PRESSURE','ABS_PRESS_FRONT'),V(37,'REAR PRESSURE','ABS_PRESS_REAR'),V(38,'POWER GROUND','ABS_POWER_RETURN')];
p.block('J20','DELTA HCU / 38 PIN',149.86,48.26,abs,{step:4.445,w:88.9});
p.pair('F41','ABS PUMP / VALUE TBD',345.44,68.58,'MAIN_FUSED_BUS','ABS_PUMP_POS');p.pair('F42','ABS MAIN / VALUE TBD',345.44,106.68,'MAIN_FUSED_BUS','ABS_MAIN_POS');p.pair('F43','ABS WAKE / VALUE TBD',345.44,144.78,'ABS_IGN_SOURCE','ABS_WAKE');
p.block('J21','ABS GROUND / HOLD',330.2,182.88,[P('ABS','HARNESS RING','ABS_POWER_RETURN'),P('BAT','PROPOSED BATTERY END','VEHICLE_RETURN')],{w:63.5});
p.notes(['Owner retains complete Delta loom and its fuses. Guide: pump40A/solenoid20A/ignition10A; older25A label requires revision check.',
'J21 records the proposed battery return; HOLD A01: reconcile manual chassis-ground wording with pinout battery-negative wording.',
'HOLD A02: identify which HCU CAN pair serves public CAN and which serves the supplied IMU/diagnostic harness.',
'ABS sensor grounds remain within ABS. Main connector unused output pins have NC marks; public-interface detail follows.',
'Finished Delta branches and IMU/private CAN are supplied, not wires to fabricate. Vehicle power/public-CAN interface only.']);

// 09 ABS sensors/control and public interface. Private internal CAN mapping held.
p=new Page('09_ABS_Sensors','09 / ABS SENSORS, CONTROLS AND PUBLIC CAN','Wheel sensors -> Delta ABS -> public CAN -> R3 traction control. Selected path; Gen 2 protocol check remains open.');
[['B20','FRONT LEFT / GM 22742183','FL'],['B21','FRONT RIGHT / GM 22742183','FR'],['B22','REAR LEFT / DELTA SENSOR','RL'],['B23','REAR RIGHT / DELTA SENSOR','RR']].forEach((r,i)=>p.block(r[0],r[1],88.9,55.88+i*43.18,[P('SIG','7/14mA SIGNAL','ABS_'+r[2]+'_SIG'),P('RET','SENSOR RETURN','ABS_'+r[2]+'_RET')],{w:68.58}));
p.block('B24','FRONT BRAKE PRESSURE',218.44,55.88,[P('V+','5V FROM ABS','ABS_PRESS_5V'),P('SIG','PRESSURE OUTPUT','ABS_PRESS_FRONT'),P('RET','DELTA LOOM INTERNAL RETURN','ABS_PRESS_RET_TBD','Supplied loom internal; not a fabrication terminal')]);
p.block('B25','REAR BRAKE PRESSURE',218.44,111.76,[P('V+','5V FROM ABS','ABS_PRESS_5V'),P('SIG','PRESSURE OUTPUT','ABS_PRESS_REAR'),P('RET','DELTA LOOM INTERNAL RETURN','ABS_PRESS_RET_TBD','Supplied loom internal; not a fabrication terminal')]);
p.block('S20','SLIP SELECTOR / PHYSICAL',218.44,167.64,[P('REF','5V REFERENCE','ABS_SLIP_5V'),P('SIG','POSITION SIGNAL','ABS_SLIP_SIG'),P('RET','SENSOR RETURN','ABS_SLIP_RET')]);
p.block('J22','PUBLIC DTM06-12S',345.44,55.88,[V(1,'GROUND','ABS_POWER_RETURN'),V(2,'CAN LOW','CAN2_L'),V(3,'CAN HIGH','CAN2_H'),V(4,'ACTIVE / UNUSED',null),V(5,'BRAKE LIGHT SINK','BRAKE_REQUEST'),V(6,'SPEEDO / UNUSED',null),V(7,'FL OUT / UNUSED',null),V(8,'FR OUT / UNUSED',null),V(9,'RL OUT / UNUSED',null),V(10,'RR OUT / UNUSED',null),V(11,'EMPTY',null),V(12,'AUX12 / UNUSED',null)],{step:5.08});
p.pair('S21','ABS ENABLE / GROUND ON',345.44,152.4,'ABS_ENABLE','ABS_POWER_RETURN','switch');
p.block('H20','ABS WARNING LAMP',345.44,177.8,[P('+','IGNITION SUPPLY','ABS_WAKE'),P('-','LOW-SIDE SINK','ABS_WARN_SINK')]);
p.notes(['HOLD A03: GM 22742183 signal compatibility/polarity unverified. Check both corners; GM lists it as front-left assembly.',
'Both pressure sensors use labelled 3-pin Delta loom plugs. Return W112 is supplier-internal; no added ground wire or R3 tap.',
'IMU/yaw sensor and its private CAN remain in supplied harness: map with verified harness data before build release.',
'S21/C158 HOLD: current guide describes hardware solenoid-power OFF; old pin35 ground-enable map is not a fabrication instruction.',
'CAN wheel speeds selected per Haltech support. J22:7-10 unused; verify Gen 2 profile/bitrate (sheet 15). SPI2 = brake request.']);

// 10 cockpit including real wake circuit and net-separated CAN.
p=new Page('10_CAN_Cockpit','10 / CAN, DASH, KEYPAD AND WAKE','CAN1: R3 / PD16 / iC-7 / keypad / TMS-4 (1 Mbit/s Haltech). CAN2: Delta ABS public bus, separately verified.');
p.pair('S1','NORMAL R3 WAKE / U2 PERMIT',114.3,66.04,'WAKE_SOURCE','R3_WAKE','switch');
p.block('U10','HALTECH IC-7',223.52,55.88,[V(1,'CAN1 HIGH','CAN1_H'),V(2,'CAN1 LOW','CAN1_L'),V(3,'SWITCHED +12V','COCKPIT_12V'),V(4,'GROUND','R3_CAN_RETURN'),V(21,'AVI4 / FUEL LEVEL','LEVEL_SIG'),V(30,'SIGNAL GROUND','DASH_SG')],{w:63.5});
p.block('U11','HT-011502 / 15 BUTTON',345.44,55.88,[P('PWR','CAN CABLE +12V','COCKPIT_12V'),P('GND','CAN CABLE RETURN','R3_CAN_RETURN'),P('H','CAN HIGH','CAN1_H'),P('L','CAN LOW','CAN1_L')]);
p.block('J30','PD16 INTERNAL / CAN1 END',88.9,127,[P('H','120R EFFECTIVE END','CAN1_H'),P('L','INTERNAL OR EXTERNAL','CAN1_L')]);
p.block('J31','CAN2 FAR-END TERM',223.52,127,[P('H','120R EFFECTIVE END','CAN2_H'),P('L','VERIFY DEVICE RESISTORS','CAN2_L')]);
p.block('B30','NOVOTECHNIK RSC-2841-634-211-202',345.44,127,[P('WH','WHITE / ANALOG OUT','GEAR_SIG','Documented wire color'),P('GN','GREEN / +5V','R3_REF5','Documented wire color'),P('BN','BROWN / SENSOR GND','R3_SG','Documented wire color'),P('YE','YELLOW / UNUSED',null,'Documented unused lead'),P('SH','SHIELD / ECU END ONLY','R3_SHIELD_RETURN','Shield at ECU end only')]);
p.text('GEAR DISPLAY - R3 TO IC-7 OVER CAN1',218.44,185.42,1.35);
p.text('NSP: Gear Position Sensor; AVI10 / C27; pull-up OFF.',218.44,193.04,1.15);
p.text('Calibrate every forward gear, neutral and reverse in place.',218.44,200.66,1.15);
p.text('Set non-overlapping voltage windows; check repeatability.',218.44,208.28,1.15);
p.text('IC-7: display ECU Gear channel. No separate display needed.',218.44,215.9,1.15);
p.text('KEYPAD / CAMERA CONFIRMED; POSITION 10 PROPOSED',17.78,185.42,1.52);
['1 Run/Stop    2 Start (momentary)    3 Headlights    4 Tail lights    5 Hazards',
'6 Fan override    7 Timed fuel prime    8 Dash next    9 Alarm acknowledge    10 Camera ON/OFF',
'11 Spare    12 Spare    13 Spare    14 Spare    15 Spare'].forEach((t,i)=>p.text(t,17.78,193.04+i*6.35,1.27));
p.notes(['S1 is normal wake, supplied only by CARTEK U2 M6_IGN. Emergency stop uses U2/S40 and R3 A13; verify engine/output shutdown and no backfeed.',
'CAN termination is a topology requirement, not two extra resistors to fit blindly. R3 has selectable internal termination per bus.',
'CAN1: R3 termination at one end; choose PD16 at the other and enable its termination. J30 represents that same resistor.',
'Twist each H/L pair; minimize stubs. Do not tie CAN1 to CAN2. R3 A11 total device return current must stay within its rating.',
'iC-7 fuel level: AVI4 pin 21 / return 30; 240R pull-up for resistive sender. Confirm dash hardware and NSP firmware.']);

// 11 auxiliary power controller and all lighting/accessories
p=new Page('11_Auxiliary_Power','11 / AUXILIARY DISTRIBUTION AND LIGHTING','One Haltech PD16 / HT-198100 kit. U20, J40 (sheet 13) and J41 are interfaces on the SAME module.');
p.block('J41','PD16 B / DTP4',101.6,50.8,[V(1,'25A HCO1 / FAN 1','FAN1_POWER'),V(2,'25A HCO2 / FAN 2','FAN2_POWER'),V(3,'25A HCO3 / HEADLIGHTS','HEADLIGHT_POS'),V(4,'25A HCO4 / LIFT 2','LIFT2_SUPPLY')],{w:73.66});
p.block('U20','PD16 / HT-198100',101.6,116.84,[V('+','MAIN +12V / SURLOK','AUX_MAIN_POS')],{w:73.66});
p.text('Control, CAN and all four ground wires: J40 on sheet 13.',88.9,157.48,1.2);
p.text('Main +12V: 4 AWG manufacturer baseline; F50 rating TBD.',88.9,165.1,1.2);
p.pair('F50','AUX MAIN / TBD',127,190.5,'MAIN_FUSED_BUS','AUX_MAIN_POS');
p.block('H30','LEFT HEADLIGHT / TBD',236.22,55.88,[P('+','HEAD / HAZARD POWER','HEADLIGHT_POS'),P('-','RETURN','VEHICLE_RETURN')]);
p.block('H37','RIGHT HEADLIGHT / TBD',365.76,55.88,[P('+','HEAD / HAZARD POWER','HEADLIGHT_POS'),P('-','RETURN','VEHICLE_RETURN')],{w:38.1});
p.block('H31','LEFT TAIL LED / TBD',236.22,106.68,[P('+','TAIL / HAZARD POWER','TAIL_POS'),P('-','BULB RETURN','VEHICLE_RETURN')]);
p.block('H35','RIGHT TAIL LED / TBD',365.76,106.68,[P('+','TAIL / HAZARD POWER','TAIL_POS'),P('-','BULB RETURN','VEHICLE_RETURN')],{w:38.1});
p.block('H34','LEFT BRAKE LED / TBD',236.22,157.48,[P('+','BRAKE POWER','BRAKE_POS'),P('-','BULB RETURN','VEHICLE_RETURN')]);
p.block('H36','RIGHT BRAKE LED / TBD',365.76,157.48,[P('+','BRAKE POWER','BRAKE_POS'),P('-','BULB RETURN','VEHICLE_RETURN')],{w:38.1});
p.text('WOLFBOX CAMERA SYSTEM - SHEET 17',218.44,203.2,1.35);
p.text('A7 / HCO5 -> kit -> USB-C mirror power.',218.44,212.09,1.15);
p.text('Keypad camera toggle; proposed position 10.',218.44,220.98,1.15);
p.block('U22','BRAKE MARKER / CONVERTER',365.76,203.2,[P('12V','CAR SUPPLY IN','MARKER_POS'),P('GND','POWER RETURN','VEHICLE_RETURN')],{w:38.1,step:5.08});
p.notes(['HEADLIGHT_POS = both headlights / PD16 B3. TAIL_POS = both tail bulbs / A3. BRAKE_POS = both brake bulbs / A4.',
'Keypad hazards: flash headlights AND tail bulbs together. Hazard logic overrides steady ON so the lamps can turn OFF each cycle.',
'Brake bulbs stay steady on brake request; no hazard flashing of brake bulbs. A5/HCO3 and A6/HCO4 are now SPARE.',
'Hazards OFF: restore normal head/tail requests. Implement shared flash phase and verify LED-driver cycling; no lamp models selected.',
'HOLD L01: configure/test flash logic, CAN-loss behavior, bulb currents, conductor/contact protection and repeated-start allowance.']);

// 12 release notes / wiring conventions
p=new Page('12_Design_Notes','12 / HARNESS CONVENTIONS AND OPEN ITEMS','This is a connected functional draft for review. It is not a fabrication release or an ECU configuration file.');
const sections=[
 ['HOW TO READ THIS SET',[
 'Identical Wxxx_NAME global labels are electrically connected across sheets.',
 'Wxxx identifies an electrical net; branched nets require individual harness conductor IDs later.',
 'Numeric R3/PD16/Delta/IC-7 pins are documented. Alphabetic functional IDs on TBD parts are not cavity numbers.',
 'NC marks identify deliberately unused pins. A net ending TBD may have only one endpoint.',
 'Reference J10/J11/J12 identifies R3 connectors A/C/E; J1 identifies its main power interface.']],
 ['GROUNDING AND CONSTRUCTION',[
 'Battery/engine/chassis returns, R3 sensor return, R3 ground outputs and ABS sensor returns are distinct nets.',
 'Do not bond R3 ground-output pins A10/A11 to chassis. Use A10 for shield drains at the ECU end only.',
 'Reuse L94 donor plugs/pigtails after inspection; verify cavity identity and record color changes.',
 'Wire sizes, insulation class, connector contacts, splice sizes and route lengths remain build-stage selections.',
 'Electronic output protection must protect EVERY branch wire/contact; verify trip curves, cranking drop and startup.']],
 ['RELEASE HOLDS',[
 'P01 CARTEK GT alone selected; verify engine-stop input, return isolation, cutoff timing, charging and starter driver.',
 'E01 Crank/cam PNs identified; verify actual cavities, coil/injector/DBW hardware, 200mA reference and 500mA return budgets.',
 'P02 Electronic trip curves vs weakest injector/coil/pump branches; F01 load/startup, fan settings and hot-idle test.',
 'A01 ABS ground wording; A02 private/public CAN mapping; A03 C7 sensor signal/polarity compatibility.',
 'N01 Gen 2 CAN profile/bitrate, TC loss behavior (sheet 15), PD16 setup; gear/HGT calibration and fuel-level input details.']],
 ['CONFIGURATION AND COMMISSIONING',[
 'Load/program NSP separately: I/O mapping, output protection, sensor calibration, DBW faults and start permissives.',
 'Check continuity/cavity orientation with electronics unplugged; then check supplies before connecting sensors.',
 'Verify master cutoff with engine running, fuel stall shutdown, fan control and brake-light response.',
 'Review source revisions and actual hardware before termination. No vehicle-powered test was performed.',
 'NASA CCR is the requested safety reference; this drawing does not certify compliance.']]
];sections.forEach((s,j)=>{const y=55.88+j*45.72;p.text(s[0],17.78,y,1.52);s[1].forEach((t,i)=>p.text(t,17.78,y+7.62+i*5.08,1.2));});
p.notes(['Selected CAN traction-control path and spare I/O: sheet 15. Sources and pin/net schedule: README.md / Connections.tsv.',
'Verified manufacturer electrical limits are ceilings, not chosen fuse-trip settings. No fuse or wire purchase schedule is released.'],246.38);

// 13 - pin-accurate PD16 peripheral interface. All grounds shown individually.
p=new Page('13_PD16_Control','13 / HALTECH PD16 CONNECTIONS AND CONTROL','Owner uses HT-188000 flying-lead harness  |  PD16 diagram rev 1.5, October 2024  |  Peripheral Power Mode / Voltage Sense');
const pa=[V(1,'HBO1 / SPARE',null),V(2,'HBO2 / SPARE',null),V(3,'8A HCO1 / TAIL LIGHTS','TAIL_POS'),V(4,'8A HCO2 / BRAKE LIGHTS','BRAKE_POS'),V(5,'8A HCO3 / SPARE',null),V(6,'8A HCO4 / SPARE',null),V(7,'8A HCO5 / CAMERA','CAMERA_POS'),V(8,'8A HCO6 / BRAKE MARKER','MARKER_POS'),V(9,'8A HCO7 / SPARE',null),V(10,'8A HCO8 / SPARE',null),V(11,'SENSOR RETURN / OIL + TRANS','PD16_SG'),V(12,'5V REFERENCE / UNUSED',null),V(13,'IGN INPUT / UNUSED',null),V(14,'SPI1 / SPARE',null),V(15,'SPI2 / SPARE',null),V(16,'SPI3 / SPARE',null),V(17,'8A HCO9 / SPARE',null),V(18,'8A HCO10 / SPARE',null),V(19,'SPI4 / SPARE',null),V(20,'AVI1 / OIL TEMP','OIL_TEMP_SIG'),V(21,'AVI2 / TRANS TEMP','TRANS_TEMP_SIG'),V(22,'HALTECH CAN GROUND','R3_CAN_RETURN'),V(23,'HALTECH CAN HIGH','CAN1_H'),V(24,'HALTECH CAN LOW','CAN1_L'),V(25,'CAN +12V WAKE INPUT','PD16_WAKE'),V(26,'IGN SOURCE / UNUSED',null),V(27,'AVI3 / SPARE',null),V(28,'AVI4 / SPARE',null),V(29,'NO CONNECTION',null),V(30,'NO CONNECTION',null),V(31,'BATTERY GROUND 1','VEHICLE_RETURN'),V(32,'BATTERY GROUND 2','VEHICLE_RETURN'),V(33,'BATTERY GROUND 3','VEHICLE_RETURN'),V(34,'BATTERY GROUND 4','VEHICLE_RETURN')];
p.block('J40','PD16 A / AMP34 KEY1',104.14,50.8,pa,{step:5.08,w:86.36});
p.text('ONE MODULE - THREE DRAWING REFERENCES',218.44,60.96,1.52);
p.text('U20 = main positive; J41 = connector B; J40 = connector A.',218.44,70.12,1.2);
p.text('Peripheral mode: dedicated R3 HBO6/A25 -> PD16 A25.',218.44,80.28,1.2);
p.text('A13 and A26 are unused. Do not backfeed A25 as an output.',218.44,90.44,1.2);
p.text('Ground A31-A34 to VEHICLE_RETURN, not BT1 negative.',218.44,105.68,1.2);
p.text('Use four 18 AWG ground wires per Haltech guide.',218.44,115.84,1.2);
p.text('A22 is CAN cable ground; not a substitute for A31-A34.',218.44,126,1.2);
p.text('FAN CONFIGURATION - NO EXTERNAL PWM',218.44,146.32,1.52);
p.text('Assign PD16 25A HCO1 / HCO2 to separate thermofans.',218.44,156.48,1.2);
p.text('Use coolant-temperature on/off hysteresis and keypad override.',218.44,166.64,1.2);
p.text('Temperature thresholds must match the thermostat/cooling test.',218.44,176.8,1.2);
p.text('Verify power-up, CAN loss, sensor-fault and overcurrent behavior.',218.44,186.96,1.2);
p.text('Do not make fan-off on track unconditional; retain overheat demand.',218.44,197.12,1.2);
p.text('Measure hot-idle charging with both fans on; listed pair load 20 A.',218.44,207.28,1.2);
p.text('CAN hub branch: H/L/return only. Keep PD16 A25 power separate from cockpit +12V; no four-wire power bridge.',218.44,218.44,1.1);
p.notes(['Use the manufacturer connector-face view for cavity orientation. A/B prefixes identify connectors, not additional modules.',
'A3-A10/A17-A18 outputs are limited to 8 A each; B1-B4 to 25 A each. Main connector rating is not an aggregate thermal guarantee.',
'Configure Peripheral Power Mode, Haltech CAN 1 Mbit/s and PD16 end termination in NSP. Do not add another resistor at J30.',
'PD16 manufacturer baseline: main 4 AWG, B outputs 10 AWG, A high-side outputs 18 AWG. Final routing/derating/protection remain open.',
'HT-188000 supplies controller-side leads and CAN plug. Finish free ends; no cockpit-positive bridge into dedicated PD16 wake.']);


// 14 - HGT internally amplified load cell, selected by owner.
p=new Page('14_Shift_Control','14 / HGT SHIFT KNOB AND FLAT-SHIFT CONTROL','B31 senses driver shift force. B30 (sheet 10) senses actual gear. Both signals are read directly by the Nexus R3.');
p.block('B31','HGT STRAIN-GAUGED KNOB / DT STYLE',104.14,63.5,[
 V(1,'SENSOR GROUND','R3_SG'),
 V(2,'ANALOG SHIFT FORCE','SHIFT_FORCE_SIG'),
 V(3,'REGULATED +5V','R3_REF5')],{w:91.44,step:10.16});
p.text('R3 CONNECTIONS - CONNECTOR C / J11, SHEET 03',223.52,60.96,1.52);
[
 'Knob cavity 1 -> C26 / sensor signal ground.',
 'Knob cavity 2 -> C28 / AVI11; pull-up disabled.',
 'Knob cavity 3 -> C25 / regulated sensor +5 V.',
 'Internal amplifier: no external amplifier or cut relay.',
 'Shared 5 V load budget: 200 mA maximum at C25.',
 'HGT current demand is unlisted; verify before release.'
].forEach((t,i)=>p.text(t,223.52,71.12+i*7.62,1.2));
p.text('HARNESS AND INSTALLATION',17.78,129.54,1.52);
[
 'Proposed harness extension: three 22 AWG automotive wires; verify contact size and routing.',
 'Use the supplied DT-style cavity numbers; verify the actual mating shell and terminal view.',
 'Wire colors are unverified. Do not assign functions by color. Ground returns to C26 only.',
 'Retain lead strain relief and a flexible service loop through full lever travel.',
 'Mount for fore/aft force. M12 x 1.75 fitment; check adapter against the actual Weddle lever.'
].forEach((t,i)=>p.text(t,17.78,139.7+i*7.62,1.2));
p.text('NSP SETUP - REQUIRED BEFORE ENABLING SHIFT CUT',17.78,185.42,1.52);
[
 'Select Load Cell as flat-shift trigger; assign AVI11. Keep cut/blip disabled during initial checks.',
 'At the selected 5 V supply, HGT resting output is about 1.80 V. Measure rest, pull and push.',
 'Confirm actual signal direction; calibrate trigger voltages and hysteresis for driver force.',
 'Use B30 / AVI10 calibrated gear feedback for closed-loop shift setup; validate every gear.',
 'Tune RPM/TPS enable limits, cut/recovery, maximum cut time and retrigger blockout.',
 'Verify sensor-disconnect behavior. Auto-blip remains disabled until DBW/downshift tuning.'
].forEach((t,i)=>p.text(t,17.78,195.58+i*6.35,1.2));
p.notes([
 'Source: HGT installation guide 63800-IB-SCK-008, 12 July 2024, especially page 5; see README for links.',
 'Pinout applies to HGT pre-terminated DT-style units. Confirm supplied hardware before terminating the mating harness.',
 'HOLD S01: supply-current budget, mating connector, installed signal calibration and tuner validation. No NSP file programmed.'
],241.3);


// 15 - selected data path and expansion. Functional notes, no added sensor wiring.
p=new Page('15_Traction_IO','15 / TRACTION CONTROL AND SPARE I/O','Selected: Delta CAN wheel speeds to R3. Haltech support response supplied by owner; see README / Sources.');
function column(title,lines,x,y){p.text(title,x,y,1.52);lines.forEach((t,i)=>p.text(t,x,y+8.89+i*6.35,1.15));}
column('SELECTED WHEEL-SPEED PATH',[
 'Four wheel sensors -> Delta ABS (sheets 08-09).',
 'Delta public J22:3 CAN H / J22:2 CAN L -> R3 CAN2.',
 'R3 J11/C21 = CAN2 H; J11/C22 = CAN2 L (sheet 03).',
 'NSP: select the available Delta ABS vehicle-CAN profile.',
 'Assign FL, FR, RL and RR speed sources to CAN Input.',
 'R3 compares calibrated front/rear speeds for traction control.',
 'J22:7-10 pulse outputs stay NC; R3 SPI3-6 stay spare.',
 'Sensor signal/return pairs remain connected to Delta only.'
],17.78,55.88);
column('SUPPORT CONFIRMATION AND CHECKS',[
 'Haltech support: CAN is suitable; Delta profile is available.',
 'Gen 2 qualification: verify protocol against installed NSP.',
 'Confirm public-bus bitrate, termination and harness mapping.',
 'Published wheel-speed broadcast: 100Hz / nominal 10ms.',
 'Check wheel identity, units and calibration for all four wheels.',
 'Validate TC enable, slip tuning and sensor/CAN fault response.',
 'Do not infer receive/TC rate from ECU-to-dash broadcasts.',
 'This drawing does not configure NSP or validate live data.'
],218.44,55.88);
column('SPARE CHANNELS - REVISION J',[
 'R3: 1 dedicated AVI; 4 SPI; 6 DPO; 0 HBO; 0 HCO.',
 'R3 AVI9/C18 spare (onboard MAP); SPI3-6 remain spare.',
 'Fuel pressure AVI6/C15; intake air temperature AVI8/C17.',
 'PD16: 2 AVI; 4 SPI; 2 HBO; 6 x 8A HCO; 0 x 25A HCO.',
 'PD16 AVI1/A20 engine oil; AVI2/A21 trans; A11 return.',
 'iC-7: 3 spare legacy sensor AVI1-3; AVI4 = fuel level.',
 'NSP additionally exposes AVI5-9, 3 DPI and 4 DPO.',
 'Extended dash capacity is firmware-dependent; see README.'
],17.78,129.54);
p.block('S50','HT-010504 / 12-POSITION',307.34,139.7,[V('1','RED / +5V','R3_REF5'),V('2','WHITE / TC LEVEL SIGNAL','TC_TRIM_SIG'),V('3','BLACK / SIGNAL GROUND','R3_SG')],{w:76.2});
['S50:1 -> C25 5V; S50:2 -> C5/SPI1; S50:3 -> C26.',
 'SPI1 analog rotary input; input pull-up MUST be OFF.',
 'Use HT-010504 calibration matching the fitted decal.',
 'TC levels/slip/cut/fault behavior remain tuner setup.',
 'No wheel-sensor split; Delta CAN2 speed path unchanged.'].forEach((t,i)=>p.text(t,218.44,180.34+i*6.35,1.05));
p.notes([
 'NSP: PD16 AVI1 = Engine Oil Temperature; AVI2 = Transmission Oil Temperature. Separate HT-010306 calibrations.',
 'iC-7 fuel level: pin 21, sensor return pin 30. NSP sharing minimums: R3 1.26.4 / dash 2.26.3; verify installed versions.',
 'TMS-4 uses CAN1 via supplied adapter (sheet 16). CAN2 remains Delta only; keep two effective terminations per bus.',
 'HOLD T01: Delta Gen 2 profile/bitrate, wheel calibration and traction-control failure behavior before enabling TC.',
 'HOLD F02: combined R3 5V reference current, cockpit supply/return load and camera-kit variant/protection test.'
],231.14);

// 16 - two separate temperature inputs and wireless TPMS receiver.
p=new Page('16_TPMS_Oil_Temp','16 / TMS-4 TPMS, ENGINE AND TRANSMISSION OIL TEMP','Two HT-010306 high-range 150C sensors use separate PD16 AVIs. HT-011600 tyre sensors communicate wirelessly.');
p.block('B32','HT-010306 / ENGINE OIL',114.3,55.88,[V('A','SIGNAL GROUND','PD16_SG'),V('B','ENGINE OIL TEMP SIGNAL','OIL_TEMP_SIG')],{w:68.58});
p.text('Engine: PD16 A20 / AVI1 -> B32:B; A11 -> B32:A.',17.78,86.36,1.15);
p.block('B33','HT-010306 / TRANS OIL',114.3,109.22,[V('A','SIGNAL GROUND','PD16_SG'),V('B','TRANS OIL TEMP SIGNAL','TRANS_TEMP_SIG')],{w:68.58});
p.text('Transmission: PD16 A21 / AVI2 -> B33:B; A11 -> B33:A.',17.78,139.7,1.15);
p.text('Enable each AVI internal 1k pull-up; no external 5V wire.',17.78,149.86,1.15);
p.text('Both: load Haltech Oil 150C 1/8 NPT HT010306.cal.',17.78,157.48,1.15);
p.text('Separate engine/trans channels; verify curve and sharing.',17.78,165.1,1.15);
p.text('EV1 harness view: A return / B signal. A11: sensors only.',17.78,172.72,1.15);
p.block('U23','HT-011600 / TMS-4 MCON6',325.12,60.96,[V(1,'CAN LOW / WHITE','CAN1_L'),V(2,'CAN HIGH / GREEN','CAN1_H'),V(3,'UNUSED',null),V(4,'UNUSED',null),V(5,'+12V / RED','COCKPIT_12V'),V(6,'GROUND / BLACK','R3_CAN_RETURN')],{w:73.66});
p.text('Supplied DTM4 -> MCON6 adapter:',218.44,123.19,1.3);
p.text('DTM1 +12V -> MCON5; DTM2 GND -> MCON6.',218.44,133.35,1.15);
p.text('DTM3 CAN H -> MCON2; DTM4 CAN L -> MCON1.',218.44,140.97,1.15);
p.text('Receiver: 12-32V; 50mA ambient operating current.',218.44,153.67,1.15);
p.text('Use supplied adapter; do not infer plug viewing direction.',218.44,161.29,1.15);
p.text('FOUR WHEEL SENSORS / WIRELESS',17.78,186.69,1.52);
p.text('Fit internal sensors to FL / FR / RL / RR; batteries are inside the sensors. No wires run out to the wheels.',17.78,196.85,1.2);
p.text('NSP: Connections > CAN > Haltech CAN System > Tyre Monitoring / TMS-4 Enable; assign IDs to actual corners.',17.78,207.01,1.2);
p.notes([
 'TMS-4: verify corner identity, pressure/temperature units, alarm thresholds and lost-sensor response. Mount receiver high in vehicle.',
 'Manufacturer typical in-motion refresh: 60 seconds. TPMS is for tyre monitoring; it is NOT a wheel-speed source for traction control.',
 'PD16 engine/trans temp: separate open/short diagnostics, valid range, alarms and stale-CAN behavior. Thresholds remain unset.',
 'Confirm trans mounting/immersion, thread clearance, 150C range and calibration against a reference; no mechanical location specified.',
 'Sources: Haltech TMS-4 QSG; HT-010306 info sheet rev 4.2; PD16 diagram rev 1.5. See Sources/ and README.'
],231.14);

// 17 - vendor power converter and unmodified vendor cable assemblies.
p=new Page('17_Wolfbox_Camera','17 / WOLFBOX G900 PRO CAMERA POWER','Keypad request -> R3 CAN control -> PD16 A7 HCO5. Complete power removal when commanded OFF; no parking supply.');
p.block('U24','G900 PRO HARDWIRE KIT',114.3,60.96,[P('YL','BATT +12V / YELLOW','CAMERA_POS','Manufacturer wire function; verify kit'),P('RD','ACC +12V / RED','CAMERA_POS','Manufacturer wire function; verify kit'),P('BK','GROUND / BLACK','VEHICLE_RETURN','Manufacturer wire function; verify kit'),P('USB','SUPPLIED USB-C CABLE','WOLFBOX_USB_CABLE','Vendor multi-conductor cable assembly')],{w:68.58});
p.block('U21','G900 PRO MIRROR / FRONT CAM',325.12,60.96,[P('USB','5V USB-C POWER IN','WOLFBOX_USB_CABLE','Vendor multi-conductor cable assembly'),P('REAR','SUPPLIED REAR CABLE','WOLFBOX_REAR_CABLE','Vendor multi-conductor cable assembly'),P('GPS','GPS / NOT FITTED',null,'Unused optional vendor interface')],{w:73.66});
p.block('U25','WOLFBOX REAR CAMERA',325.12,124.46,[P('CAM','POWER + VIDEO CABLE','WOLFBOX_REAR_CABLE','Vendor multi-conductor cable assembly'),P('REV','REVERSE TRIGGER / UNUSED',null,'Insulate unused vendor lead')],{w:73.66});
p.text('SWITCHED-ONLY DESIGN / VERIFY KIT ON RECEIPT',17.78,117.36,1.4);
p.text('Yellow BATT AND red ACC take the same camera-switched',17.78,127.52,1.15);
p.text('12V feed from PD16 A7. Black returns to vehicle return.',17.78,135.14,1.15);
p.text('This deliberately removes all camera power when OFF.',17.78,145.3,1.15);
p.text('Retain the WolfBox converter and its supplied USB-C cable.',17.78,152.92,1.15);
p.text('Use a kit matching the mirror version/input-current label.',17.78,160.54,1.15);
p.text('No separate 12V or USB supply goes to the rear camera.',218.44,153.67,1.15);
p.text('Select normal rear view; disable screen auto-off as needed.',218.44,163.83,1.15);
p.text('CONTROL AND PROTECTION',17.78,181.61,1.52);
p.text('Camera button toggles PD16 A7; proposed keypad position 10, initial OFF. R3 / PD16 / keypad must already be awake.',17.78,191.77,1.2);
p.text('Use high-side ON/OFF, full supply when ON; do not PWM the converter supply. Verify orderly recording on power loss.',17.78,201.93,1.2);
p.text('USB and rear-cable W labels denote complete vendor cable assemblies, NOT single wires or USB cavity numbers.',17.78,212.09,1.2);
p.notes([
 'HOLD C01: confirm purchased kit labels/variant and switched-only operation with both BATT/ACC on A7 before installation.',
 '3A/4A at 5V are mirror supply ratings, not measured continuous draw. At 12V / 90% efficiency: about 1.4A / 1.9A input.',
 'Select PD16 trip/inrush/retry settings to protect actual kit leads; retain vendor inline protection if fitted. Do not use 8A blindly.',
 'No raw-battery parking feed; camera stays downstream of master isolation. GPS and reverse lead omitted as the simple rear-view basis.',
 'Insulate unused reverse lead. Verify boot time, rear view, CAN-loss OFF, cranking and master-stop behavior on actual hardware.'
],231.14);


// 18 - manufacturer-documented CARTEK connector and hardwired emergency controls.
p=new Page('18_Master_Stop','18 / CARTEK GT, STOP SWITCH AND POSITIVE BLOCKS','GT manual rev1.0 / 07Nov2025, method 1 ECU/PDM input. ONE internal stop switch; no external switch. Blocks are proposed parts.');
p.block('U2','CARTEK GT / VERIFY s OR x',101.6,55.88,[P('M8','BATTERY NEGATIVE STUD','BATT_NEG','Documented M8 stud'),P('M6_BAT','BATTERY POSITIVE M6','ISOLATOR_POS','Documented M6 stud; functional identity'),P('CASE','CONDUCTIVE CASE / MOUNTS','CHASSIS_GND','Documented chassis bond'),P('BLACK','INTERNAL SWITCH BLACK','ISOLATOR_INTERNAL_BLACK','Documented flying lead color'),P('RED','INTERNAL SWITCH RED','ISOLATOR_INTERNAL_RED','Documented flying lead color'),P('M6_IGN','ENGINE STOP OUTPUT M6','WAKE_SOURCE','Documented M6 stud; functional identity'),P('BLUE_A','EXTERNAL LOOP BLUE LEAD A','GT_EXTERNAL_BLUE_LOOP','Documented blue lead; A is drawing identity'),P('BLUE_B','EXTERNAL LOOP BLUE LEAD B','GT_EXTERNAL_BLUE_LOOP','Documented blue lead; B is drawing identity')],{w:88.9,step:7.62});
p.pair('F4','GT CONTROL / 5A PROPOSED',340.36,66.04,'BATT_RAW','ISOLATOR_POS');
p.block('TB1','FS46540 / RAW + / PROPOSED',302.26,96.52,[P('BAT','BATTERY LUG / COMMON M10','BATT_RAW','Functional lug identity; not separate stud'),P('F0','MAIN FEED LUG / COMMON M10','BATT_RAW','Functional lug identity; not separate stud'),P('F2','START CABLE LUG / COMMON M10','BATT_RAW','Functional lug identity; not separate stud'),P('F4','GT FEED LUG / COMMON M10','BATT_RAW','Functional lug identity; not separate stud')],{w:88.9,step:5.08});
p.block('TB2','SUM-900533 / FUSED + / PROPOSED',302.26,149.86,[P('IN','F0 OUT INCOMING LUG','MAIN_FUSED_BUS','Functional lug identity; stud assignment TBD'),P('F1','R3 FEED LUG','MAIN_FUSED_BUS','Functional lug identity; stud assignment TBD'),P('F50','PD16 FEED LUG','MAIN_FUSED_BUS','Functional lug identity; stud assignment TBD'),P('F41','ABS PUMP FEED LUG','MAIN_FUSED_BUS','Functional lug identity; stud assignment TBD'),P('F42','ABS MAIN FEED LUG','MAIN_FUSED_BUS','Functional lug identity; stud assignment TBD'),P('F5','START DRIVER FEED LUG','MAIN_FUSED_BUS','Functional lug identity; stud assignment TBD')],{w:88.9,step:5.08});
p.pair('S40','B00NTT91Y0 / LATCHING NC',101.6,154.94,'ISOLATOR_INTERNAL_RED','ISOLATOR_INTERNAL_BLACK','switch_nc');
p.text('S40: one cockpit stop button, reachable inside/outside.',17.78,177.8,1.15);
p.text('Reset/released = NC closed / ON; pressed = latched open / OFF.',17.78,185.42,1.1);
p.text('Verify actual NC pair. Pins 1/2 are functional, NOT cavity IDs.',17.78,193.04,1.1);
p.text('Join BLUE_A to BLUE_B permanently; no chassis connection. S41 removed. No battery voltage on switch leads.',17.78,207.01,1.15);
p.text('GT M6_IGN -> S1 -> R3 A13 only. K1 removed; F0 -> TB2 direct. GT output is fixed 40A protected.',17.78,215.9,1.15);
p.text('TB1: four lugs / common M10 post, stack and covers TBD. TB2: six lugs / four 3/8 studs; allocation TBD.',17.78,224.79,1.15);
p.text('TB2 listing conflicts: specific 250A vs family 150A. Confirm actual rating, thermal duty and permitted lug stacks.',17.78,233.68,1.15);
p.notes(['GT: 7-18V; 600A cranking / 2000A surge. Confirm received GT-s/GT-x, terminal labels and actual starter current.',
'Install in manual order: chassis bond, switch/blue loop, engine-stop, M6 battery positive, then M8 negative. Limit temp to +85C pending source conflict.',
'F4 5A remains PROPOSED for the GT/control feed. Size wiring/protection for actual GT + R3 A13 load, not a contactor coil.',
'K1 deleted by owner. Verify R3 A13 OFF stops engine/fuel and PD16 outputs promptly before GT battery isolation.',
'Twist reset may re-arm power; require a fresh start command. Charger/booster cables both at battery posts; no negative bypass.'],246.38);

// 19 - retained stock engine loom boundaries; reference cavities are not
// inspection evidence for the owner's actual donor harness.
p=new Page('19_Stock_Engine_Harnesses','19 / STOCK L94 COIL LOOMS AND LS3 INJECTORS','Retained donor wiring / 7 populated bank ways / related-year GM cavity reference; confirm actual donor continuity and orientation.');
for(const [index,bank] of stockHarness.coil_banks.entries()){
 const pins=['A','B','C','D','E','F','G','H'].map(letter=>{
  let func,n;
  if(letter==='A'){func='SHARED COIL POWER RETURN';n='ENGINE_GND';}
  else if(letter==='H'){func='SHARED COIL +12V';n='COIL_SUPPLY';}
  else if(letter==='E'){func='SHARED LOW REF / HOLD';n='R3_SG';}
  else if(letter==='D'){func='UNPOPULATED POSITION';n=null;}
  else {func='COIL '+bank.trigger_pins[letter]+' CONTROL';n='IGN_'+bank.trigger_pins[letter];}
  return P(letter,func,n,'GM reference cavity; verify actual donor');
 });
 p.block(bank.ref,'OEM L94 / '+bank.bank+' / 7-WAY',83.82+index*177.8,60.96,pins,{w:101.6,step:7.62});
}
p.text('OEM COIL BANK LOOMS - RETAIN THEIR INTERNAL SPLICES',17.78,152.4,1.5);
p.text('Each bank: four triggers plus common +12V, power ground and low reference. D is unavailable, not an eighth live wire.',17.78,161.29,1.15);
p.text('Reference coil plug: A=power ground, B=low reference, C=trigger, D=+12V. Device IDs on sheet 04 stay functional.',17.78,170.18,1.15);
p.text('S paths in the continuous views are RETAINED STOCK wiring. C paths are new integration wires; no new coil-branch cuts assumed.',17.78,179.07,1.15);
p.text('DONOR INJECTOR WIRING - REUSE WITH LS3 EV6 / USCAR INJECTORS',17.78,194.31,1.5);
p.text('Retain eight individual driver legs and separate odd/even +12V branches. No factory injector bulkhead plug is assumed.',17.78,203.2,1.15);
p.text('CUT-INJ labels mark functional donor cut/termination boundaries, NOT connector cavities; locations/join hardware TBD.',17.78,212.09,1.15);
p.text('Factory feed circuits may also serve coils: isolate retained injector feeds before HCO1. NEVER connect HCO1 to HCO2.',17.78,220.98,1.15);
p.notes(['HOLD: verify LS3 injector PN, plug key/latch, connector orientation, harness reach, condition, continuity and calibration.',
'GROUND HOLD: bank A -> engine; bank E -> R3 C26 is retained pending exact coil evidence. No W009/W062 bridge permitted.',
'GM separates low reference; Haltech generic Gen IV guide also advises both coil grounds at the head. Resolve with exact coil/R3 guidance.',
'Reference: Stock_Engine_Harnesses.json and OEM_Harness_Interfaces.tsv. Source cavities/colors are not inspected donor measurements.',
'No downstream bank fuses restored. HCO1 injector / HCO2 coil trip coordination with every OEM branch and contact remains OPEN.'],238.76);

// Root sheet with native hierarchical navigation.
const ri=[];const rt=(t,x,y,s=1.27)=>ri.push(`(text ${q(t)} (at ${x} ${y} 0) ${fx(s,'(justify left)')} (uuid ${uuid()}))`);
rt("DANNY'S RACE CAR",20.32,22.86,4);rt('ELECTRICAL HARNESS / REV J',20.32,33.02,2.54);rt('L94 / LS3    |    Nexus R3    |    Delta ABS Gen 2    |    IC-7    |    15-button CAN keypad',20.32,43.18,1.52);
rt('DESIGN REVIEW DRAFT - OPEN THIS ROOT FILE IN KICAD',20.32,55.88,1.52);
pages.forEach((pg,i)=>{const x=25.4+(i%2)*195.58,y=62.23+Math.floor(i/2)*19.05;ri.push(`(sheet (at ${x} ${y}) (size 170.18 12.7) (stroke (width 0.254) (type default)) (fill (color 0 0 0 0)) (uuid ${pg.sheetId}) (property "Sheetname" ${q(pg.title)} (at ${x} ${y-1.27} 0) ${fx(1.27,'(justify left bottom)')}) (property "Sheetfile" ${q(pg.file+'.kicad_sch')} (at ${x} ${y+13.97} 0) ${fx(1.05,'(justify left top)')}) (instances (project "${project}" (path "/${root}" (page "${pg.number}")))))`);});
rt('WHAT IS VERIFIED',20.32,241.3,1.52);rt('R3 and PD16 connector functions; Delta supplied pin allocations; owner equipment choices. Circuit assignments are a draft.',20.32,248.92,1.2);
rt('WHAT REMAINS OPEN',20.32,256.54,1.52);rt('TBD devices, selected ratings, sensor cavity mapping, ABS compatibility, isolation, CAN configuration and physical harness routing.',20.32,264.16,1.2);
fs.writeFileSync(path.join(dir,project+'.kicad_sch'),`(kicad_sch (version 20230121) (generator racecar_draft) (uuid ${root}) (paper "A3") (title_block (title "Race car electrical harness - system index") (date "2026-10-27") (rev "J - REVIEW") (company "Danny's Race Car") (comment 1 "DRAFT - NOT A BUILD RELEASE")) (lib_symbols) ${ri.join('\n')} (sheet_instances (path "/" (page "1"))))`);
pages.forEach(pg=>pg.save());
fs.writeFileSync(path.join(dir,project+'.kicad_pro'),JSON.stringify({meta:{filename:project+'.kicad_pro',version:1}},null,2));
// Project library makes the embedded custom blocks editable without global library dependencies.
fs.writeFileSync(path.join(dir,'RaceCar.kicad_sym'),`(kicad_symbol_lib (version 20220914) (generator racecar_draft) ${pages.flatMap(pg=>pg.libs).join('\n').replaceAll('(symbol "RaceCar:','(symbol "')})`);
fs.writeFileSync(path.join(dir,'sym-lib-table'),'(sym_lib_table\n (lib (name "RaceCar")(type "KiCad")(uri "${KIPRJMOD}/RaceCar.kicad_sym")(options "")(descr "Race car draft harness symbols"))\n)');
const rows=['Net_ID\tNet_Name\tReference\tPin_or_Function_ID\tFunction\tSheet\tPin_Status'];
for(const n of nets.values())for(const e of n.endpoints)rows.push([n.id,n.name,e.ref,e.pin,e.function,e.page,e.status].join('\t'));
fs.writeFileSync(path.join(dir,'Connections.tsv'),rows.join('\n'));
fs.writeFileSync(path.join(dir,'Design_Data.json'),JSON.stringify({project,root,pages:pages.map(p=>({file:p.file,title:p.title,number:p.number})),parts,nets:[...nets.values()]},null,2));
console.log(JSON.stringify({sheets:pages.length+1,components:parts.length,nets:nets.size,output:dir},null,2));

