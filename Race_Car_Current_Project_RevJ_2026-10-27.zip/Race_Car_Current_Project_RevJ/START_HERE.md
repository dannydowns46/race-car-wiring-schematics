
## 27 October 2026 - current HT-010504 TC selector / online-first delivery

Owner selects Haltech HT-010504 as S50, a 12-position traction-control level selector.
Module DTM3 pin1/red -> R3 C25 regulated5V via SP061/W061; pin2/white ->
R3 C5/SPI1 on new W137 TC_TRIM_SIG; pin3/black -> R3 C26 via SP062/W062.
Pull-up MUST be OFF. Use the manufacturer HT-010504 calibration matching the
fitted decal; verify molded numbering using the harness-side view. Colours refer
to module leads. Reference/return current, reach/materials and actual hardware
remain to verify. S2 remains absent; W046/C076/C123 stay retired; no start interlock.
This latest C5 allocation supersedes earlier spare/unconnected statements.

Four wheel sensors still feed Delta only; public CAN2 wheel speeds feed R3 TC.
No raw-sensor split, CAN node, extra PDM or output allocation is added. Use rotary
position as the TC Desired Slip and/or Cut Percentage table axis; level direction,
slip/cut values, any OFF detent and invalid-input/CAN response remain tuner choices.
See Traction_Control_Selector.json and C21. No installed NSP setup or powered test.
R3 retains AVI9/C18 and four SPIs C7/C8/C19/C20; PD16 retains two spare AVIs.

New physical paths C215/C216/C217 preserve every retained record and measurement;
C216 uses the supplied R3 flying lead; reference/return branches require grouped
tail/reach inspection. 96 parts /417 pins /358 connected /59NC /116nets;
287 full physical paths, unchanged145 power paths. Source/model checks are retained
to support the interactive view. The owner requests the interactive ONLINE schematic
as the deliverable from here forward; no separate PDF delivery is required.

# Race car wiring project - Revision J

> **LATEST: U3 is Cole Hersee 24059 with local D60 coil suppression. S2 clutch/neutral switch is removed; R3 C5/SPI1 is spare/unconnected, no jumper. C076/C123 and W046 are retired.** See the U3 and S2 sections below; actual NSP and powered tests remain open.

> **CURRENT OWNER UPDATE - 25 October: K1 REMOVED.** CARTEK GT alone provides engine-stop control and battery-negative isolation. GT M6_IGN -> S1 -> R3 A13; F0/2 now feeds TB2/IN directly on W003 **MAIN_FUSED_BUS** (same W003 ID). W128 and C063/C064/C178/C179 are retired; do not reuse them. Positive feeders remain connected when the battery is attached. All physical fuses remain drawn, and the owner explicitly retains **Delta supplied fuses**. Prove engine/fuel/PD16 output shutdown and GT timing before use. Prior passages describing retained K1 or a switched TB2 are superseded by this amendment; historical snapshots are in Change_Records.

Current totals: 19 native sheets, 95 components, 414 pins, 354 connected endpoints, 60 NC, 115 nets. Full physical view 284 connections; power 145/43 nets. Construction tags are independent of stable IDs: **MAKE** additional branch/integration, **LEAD** supplied controller/kit wire needing end work, **LOOM** existing wiring, **CABLE** intact cable, **HOLD** unresolved supplier path. The 176 C IDs are not a count of wires to buy:81 paths use supplied leads; C158 is supplier-routing HOLD. See Harness_Construction.json and the four TSV work lists. Actual grouped branch leads, reach and mating/extension hardware remain to inspect.

Owner uses complete Delta harnesses and R3/PD16 flying-lead harnesses (catalog HT-183200/HT-188000 references). Delta sensor/control/IMU wiring and fused feed assembly stay intact. No fabricated pressure return or private CAN tap. Current Delta OFF-switch wording conflicts with the older pin35 model; C158 is explicitly **not a wire to fabricate**. IMU cavities/public-private HCU pairing remain supplier holds. U3 is selected as Cole Hersee 24059 with external D60 suppression; actual current, F5 coordination and powered release tests remain OPEN. See the current U3 selection section below.

> **25 October update - GT integrated in current drawings:** CARTEK GT replaces X-Pro; one BAOMAIN B00NTT91Y0 internal latching NC stop, no separate external switch, GT blue/blue loop joined. K1 physical positive cutoff retained. TB1 Sierra FS46540 and TB2 Summit SUM-900533 added as PROPOSED parts. Received GT-s/GT-x, actual switch contacts, block ratings/stacking, F4 coordination and powered shutdown still require verification. F2/F3 remain drawn; no removal instructed. See `Race_Car_RevJ/Distribution_Blocks.json` and P06/P07.

**Current: J, updated 25 October 2026.** Extract the complete ZIP before opening files. Read CODEX_HANDOFF.md, Vehicle_Wiring_Design_Basis.md, Race_Car_RevJ/README.md and OPEN_ITEMS.tsv.

New separate power-only continuous sheet: `Race_Car_RevJ_Power_Only/Race_Car_RevJ_Power_Only_Physical_Wiring.pdf`, derived from the updated GT/single-stop/proposed-block model. Keep its adjacent full-set PDF for links. It omits non-power pins/signals; use the complete schematic for sensor/CAN/driver wiring. Updated generators/validators are included in `rebuild_current.py`.

Open `Race_Car_RevJ/Race_Car_RevJ.kicad_pro` in KiCad. Review the19-sheet `Race_Car_RevJ/Race_Car_RevJ.pdf` or the zoomable `Race_Car_RevJ_Single_Page/Race_Car_RevJ_Continuous_Wiring.pdf`. Keep its companion flagged PDF beside it for links. The current continuous view is marked PHYSICAL CONDUCTOR VIEW 01 / 25 OCT 2026.

J specifies one onboard wideband and adds a second HT-010306 on PD16 AVI2 for transmission oil. It retains I, which adds CARTEK negative isolation and K1 physical main-power cutoff, separate lift-pump channels, independent critical wake supplies, the identified cam/crank and supporting protection/control/commissioning specifications. I/H and the H audit are historical; read current Audit_Disposition.tsv for their status.

Suggested message to shop Codex:

> Read AGENTS.md, CODEX_HANDOFF.md, Vehicle_Wiring_Design_Basis.md, Race_Car_RevJ/README.md and OPEN_ITEMS.tsv. Revision J is current. Preserve owner choices and net IDs. Review Protection_Schedule.tsv, Branch_Coordination.tsv, Control_Specification.json and Commissioning.tsv. Continue resolving measured cable/contact/current data and actual NSP setup without treating draft settings or historic findings as completed tests.

Use `python rebuild_current.py --help`. Node/Python/KiCad dependencies are needed only to rebuild; PDFs/notes are readable without them. PACKAGE_MANIFEST.json and TRANSFER_VERIFICATION.json record package integrity and isolated rebuild evidence. This is a design-review draft, not a fabrication release. No installed NSP calibration exists in the package.

24 October power-analysis supplement: read `Power_Analysis_2026-10-24/output/pdf/Power_Analysis_Report.pdf` and the new section in CODEX_HANDOFF.md. It records current owner pulley/RPM/load choices and an unresolved alternator overspeed finding. The analysis predates the subsequent starter/alternator routing update below; its load estimates remain applicable, but its original cable-route discussion is superseded. The older whole-project ZIP predates both updates.

24 October routing update: one shared battery-block-to-starter cable, plus a separately fused alternator lead on the same starter BATTERY B+ stud. Read `Race_Car_RevJ/Starter_Alternator_Routing.json` and the updated handoff. Native and continuous PDFs include this update; old ZIPs/manifests remain their dated snapshots.


## 25 October - individual physical conductors

Both continuous views now show individual proposed physical conductors and explicit joints, replacing the earlier net-wide logical buses. Native parts, cavities, electrical nets and retained W IDs are unchanged. Full view: `Race_Car_RevJ_Single_Page/Race_Car_RevJ_Continuous_Wiring.pdf`. Power-only: `Race_Car_RevJ_Power_Only/Race_Car_RevJ_Power_Only_Physical_Wiring.pdf`. The older power-only Continuous PDF is the superseded logical-bus snapshot, not the current physical view.

`Race_Car_RevJ/Physical_Topology.json` is the maintained proposed connection topology; `Physical_Connections.tsv` lists individual ID/from/to/net/kind/pair and material/measurement fields; `Physical_Junctions.tsv` lists explicit splice/ground-point intent. C IDs identify 180 proposed individual integration/field conductors (87 in the power-only view); S identifies 85 supplied/retained-loom conductor paths (41 power); V identifies two intact vendor cables. I internal continuity, B metal/lug/bond continuity and U unresolved supplier paths are distinct and are not additional cut wires. W IDs still identify electrical nets, not cuts. J2/J3/J21 are existing ground cable/ground assemblies whose bodies join their own ends.

TB1 has four external branch wires, TB2 six, with their common metal explicitly shown inside the blocks. The shared starter B+ stud has two wire ends. Multiway feeds/returns/reference branches now land at named proposed joints. Proposed CAN1 linear trunk order is R3 -> dash tap -> keypad tap -> TMS4 tap -> PD16, with paired H/L paths and internal PD16 termination represented without an extra field resistor. Exact packaging, tap lengths and all physical joint locations remain open. GP129 front/control/rear ground-point distribution is proposed, with metal/bond paths kept separate from cut-wire records; sensor/CAN returns stay isolated from it.

No final wire gauge/color/cut length/terminal/splice hardware or physical vehicle route is established. Measure and approve these before fabrication. Preserve supplied Delta pressure returns and intact WolfBox USB/rear cables; unresolved supplier construction is not turned into a fabricated splice/cavity map. No extra ground bypass or electrical reassignment was made.

`physical_topology_j.py` audits the maintained model and refreshes derived schedules during normal builds. Its `--initialize` option refuses to overwrite an existing topology: do not delete/reinitialize it after entering measurements. `render_physical_j.py` renders both views; `validate_physical_j.py` independently recovers the actual PDF conductors and explicit internal bars/dots and matches the native net endpoint sets. Existing build/validate entry-point names call these modules, so `rebuild_current.py` remains the portable command. Prior build reports/ZIPs/change records remain their dated snapshots.


## Interactive wire tracing - 25 October

Open `Race_Car_RevJ_Interactive/Race_Car_RevJ_Interactive.html` in a modern browser,
or transfer `Race_Car_RevJ_Interactive/Race_Car_RevJ_Interactive_Viewer.zip` and
extract it first. The standalone file embeds both physical-conductor drawings
and all tracing data; it needs no server/install/internet. The local browser
preview is for review only; the standalone file/ZIP is the portable deliverable.

Click a wire to highlight its path and endpoints. Wire/Net chooses one conductor
or every branch of the same electrical net. Dim others, Fit selection, Overview,
scroll zoom, drag pan, endpoint zoom buttons and ID/name/terminal search are
included. The initial example is C023, the shared starter cable. Full-harness-only
search results switch scope automatically. The URL hash can bookmark a selection.

This read-only derived view changes no native or physical topology assignments.
It retains all 117 full-harness nets (44 power-only) and 288 selectable connection
records (147 power), including explicit internal block metal. Internal/bond/
unresolved paths and intact cable assemblies remain distinct from cut wires.
Existing material, physical location, rating, hardware and fabrication holds apply.

Maintain `interactive_viewer_j.html` and `build_interactive_j.py`; generated HTML
and Viewer_Data.json must not be hand-edited. `validate_interactive_j.py` checks
embedded metadata and drawing paths against the current model and validated PDF
manifests. Both are integrated into `rebuild_current.py`; read Viewer Validation
and Browser_QA.json alongside the native/physical validation reports. Regenerate
after a changed physical drawing so the viewer cannot silently become stale.

Ctrl-click (Command-click on Mac) now adds/removes individual wires without clearing the others; normal click replaces the selection. This also works on wire search results and connection-list entries. Fit selection and Net mode apply to all selected wires; different nets remain separate. Clear/Escape removes all selections and bookmarked URLs preserve multiple IDs.


## Chassis-ground display update - 25 October

Both current continuous PDFs and the interactive viewer show chassis returns as
short wire stubs ending in labelled ground symbols. W129/GP129-F, -C and -R retain
the proposed front/control/rear physical landing points. B005/B006 chassis metal
continuity is represented by those W129 references, not extra field wires.
W015 case/chassis bonds retain their own labels. Match W IDs when tracing.

This is a drawing simplification only: no native pin/net, physical connection,
measurement, material or protection assignment changes. Short graphic stubs do
not prescribe cut lengths or eliminate required physical return wires/bonds.
Sensor/CAN returns, W009 engine returns and W002 battery negative through the
CARTEK remain explicit. Temperature sensors must use their controller's sensor
return: R3 C26 for intake air/coolant; PD16 A11 for both oil-temperature sensors.
Ground-point endpoint buttons zoom to the selected wire's local symbol.
Ctrl-click multi-selection and Wire/Net highlighting remain supported.

The updated full sheet uses its usual Continuous_Wiring filename. Native sheets
remain the unchanged source design.


## Retained stock engine harnesses - 25 October

Owner confirms stock L94 coils and coil-bank looms, with LS3 injectors using the
retained L94 donor injector wiring if actual connector fit and reach permit.
Current J now has 19 sheets, 96 components, 418 modeled pins, 359 connected
endpoints, 59 NC/unavailable positions and the same 117 named nets. X111/X113 on
new sheet 19 represent the odd/even OEM coil-bank interfaces. All existing device
assignments, R3/PD16 output allocations and retained W IDs are unchanged.

Read Race_Car_RevJ/Stock_Engine_Harnesses.json and OEM_Harness_Interfaces.tsv.
Reference bank positions are A power ground, E low reference, H +12V; four trigger
positions differ by bank, and D is unavailable. These are GM service reference
cavities, not an inspection claim for the donor. Functional coil/injector device
pin IDs remain distinct from source cavity references. Catalog references include
square12570616/service12611424 and round12573190/service12699382; actual version
is unverified. No supplier PN, wire color or gauge is asserted as inspected.

Both continuous PDFs and the viewer now distinguish 56 retained OEM S conductor
paths (38 coil, 18 injector) from new C integration wires. The complete topology
has 180 C, 85 S, 2 V, 11 I, 9 B and 1 U records: 288 selectable connections full,
147 power-only. The power view retains 44 nets, 70 component interfaces and 167
native endpoints; it omits low-reference and trigger signals. Shared stock-loom
nodes represent functional continuity; exact joint counts/type/locations remain
unverified. CUT-INJ nodes are functional cut/termination boundaries, not invented
factory bulkhead plugs. Thirty-two old generic direct-branch C records are retired
and archived; other record IDs/material fields are preserved. Do not reinitialize
the topology or rerun the one-time migration under Change_Records.

Factory feeds can serve injectors and coils together. Separate donor injector-only
feed branches from coil/other loads so R3 E1/HCO1 cannot be connected to E2/HCO2.
No removed bank fuses are restored. Coordinate electronic trip curves with every
retained branch wire, splice, bank feed and connector contact.

Coil low-reference grounding remains HOLD: the drawing retains bank E to R3 C26,
separate from bank A to engine ground. GM OEM evidence separates these circuits;
Haltech's generic Gen IV guide also advises both coil grounds at the head. Resolve
that difference with the exact coil/R3 installation evidence before power. Do not
bridge W009 to W062 or add a chassis bond to sensor ground from this drawing.
Temperature sensor returns and the CARTEK isolated-negative path are unchanged.

stock_engine_harness_j.py audits the maintained donor assembly paths and is called
by the normal topology audit. Normal rebuild_current.py regenerates native sheets,
schedules, both continuous PDFs and the viewer/ZIP. Fresh export and actual PDF
path/symbol equivalence are checked; physical fit and powered behavior remain C18
commissioning work. Earlier numerical counts in dated sections are snapshots.

## Current component explanation viewer

Click a component box/header or choose **Explain a component** in the sidebar to highlight it and read what it is, what it does and its project-specific notes. All 95 native component references have descriptions in Component_Guide.json. They distinguish connector views of the same R3/PD16 from extra devices and identify selected U3 hardware and unresolved interface details. Endpoint traces also include Explain buttons. The construction filter is preserved for incident paths; component search can switch to full harness automatically. Read Browser_QA.json and the current build reports. The portable viewer ZIP includes the four construction work lists.


## Current U3 starter relay selection — 25 Oct 2026

U3 is now the owner-selected **Cole Hersee 24059** base part: 12V, 17.5-ohm isolated coil, 85A normally-open contacts, bulkhead bracket, two large 5/16-24 and two small #10-32 studs. PWR/OUT/CMD/GND are installer functional tags, not claimed stamped terminal numbers or fixed left/right positions. See `Race_Car_RevJ/Starter_Relay.json` (or `Starter_Relay.json` inside that folder).

Large PWR takes F5/2 via C026/W013; the other large OUT goes to the starter's **small SOL terminal** via C025/W012. Small CMD takes R3 A18/HBO5 via C027/W014; the other small GND returns to GP129-C vehicle return via C180/W129, not the isolated battery negative or the relay case. The starter motor's heavy B+ trunk is separate.

D60 is an external Vishay 1N5408-E3/54 suppression diode across the small coil studs: **banded cathode K to CMD, unbanded anode A to GND**. C213/C214 identify its local insulated leads, not two new long harness wires or a second remote ground landing. Confirm actual received part and polarity before powering. The diode affects release timing; verify prompt starter disengagement and abort/master-OFF behavior under C19. Calculated coil draw is about 0.69A at12V; the owner's approximately30A solenoid pull-in estimate is unmeasured. F5 remains present, rating and wire/contact coordination unselected. No installed NSP settings or powered test is claimed.

Current model after S2 removal: 95 parts, 414 pins, 354 connected endpoints, 60 NC and115 W nets. Physical views have284 full /145 power paths, with26 chassis-return glyphs under existing display policy. Construction totals:94 MAKE,81 LEAD,85 LOOM,2 CABLE,11 internal,9 structure and2 HOLD. C213/C214 and D60 are added; C076/C123 and W046 are retired with S2. Retained conductor identifiers/endpoints/measurement fields remain. The interactive viewer includes a four-stud wiring table and suppression polarity for U3 and an explanation for D60. Earlier dated numerical snapshots are historical.

## S2 removal — latest owner update, 25 Oct 2026

S2 clutch/neutral start switch is removed, including C076 and C123. W046 START_PERMIT is retired and must never be reused. **R3 C5/SPI1 is now spare and unconnected**; insulate the unused supplied lead individually. No replacement neutral switch or jumper is inferred. Starter-control intent no longer requires a clutch/neutral input; fresh request, GT/R3 run permission, engine-not-running inhibition, bounded crank and release on running/request end/timeout/abort/master OFF remain to implement and verify. See Control_Specification.json, Starter_Relay.json and commissioning C20. Native sheets3/6, schedules, continuous views and viewer are updated together.

## Public schematic website — 26 October 2026

The current public library is https://dannydowns46.github.io/race-car-wiring-schematics/ . Repository: https://github.com/dannydowns46/race-car-wiring-schematics . GitHub Pages publishes main / (root); upload the CONTENTS of Public_Site/dist, keeping .nojekyll and .gitattributes. Public access was explicitly approved by the owner. Preserve this repository and URL for future requested updates.

Read Public_Site/HOSTING.md and publishing.json. After an authorized design update, rebuild/validate/inspect the maintained schematics, then run Public_Site/prepare_release.py with a new date/release ID and publish the refreshed assets to the same site. Preserve dated archive ZIPs; never silently replace released bytes. The current project download is a validated maintained working set, not every historical CAD/transfer archive. No background job is installed; requests trigger future rebuild/publication. Authentication must use the owner's GitHub session or a later explicitly configured integration; no token is stored.
