"""Build a self-contained offline viewer from the validated physical drawing data.

Does not change native or proposed physical connectivity. Drawing geometry comes
from the same manifests as the PDFs; the visible background is their vector art.
"""
from pathlib import Path
from collections import defaultdict
import base64,json,hashlib,zipfile,re,shutil
import pymupdf as fitz
from physical_topology_j import R,D,load_and_audit
from wiring_work_j import WORK_CLASSES,work_info,CONSTRUCTION,write_work_lists

OUT=R/'Race_Car_RevJ_Interactive'
def build():
 data,top=load_and_audit();OUT.mkdir(exist_ok=True)
 payload={'revision':'J','date':'2026-10-27','views':{},'connections':top['connections'],'nodes':top['nodes'],'assemblies':top['assemblies'],'workClasses':WORK_CLASSES,
          'construction':json.loads(CONSTRUCTION.read_text(encoding='utf-8')),
          'componentGuide':json.loads((D/'Component_Guide.json').read_text(encoding='utf-8')),
          'starterRelay':json.loads((D/'Starter_Relay.json').read_text(encoding='utf-8')),
          'stockHarness':json.loads((D/'Stock_Engine_Harnesses.json').read_text()),
          'nets':data['nets'],'parts':data['parts'],'holds':top['holds']}
 provenance={}
 for mode,folder in [('full','Race_Car_RevJ_Single_Page'),('power','Race_Car_RevJ_Power_Only')]:
  source=R/folder;m=json.loads((source/'Drawing_Manifest.json').read_text())
  assert m['schema']=='physical-conductors-v1'
  report=json.loads((source/'Match_Validation.json').read_text());assert report['result']=='PASS'
  for name,digest in m['source_hashes'].items():assert hashlib.sha256((R/name).read_bytes()).hexdigest()==digest,name
  width,height=m['page_size_points'];bottom=max(p['y']+244 for p in m['placements'].values())+55
  bounds=[0,150,width,bottom-150]
  # Crop only an in-memory copy; source PDFs remain untouched. No notes or
  # electrical content is modified. Scope/holds live in the viewer inspector.
  doc=fitz.open(source/m['pdf']);doc[0].set_cropbox(fitz.Rect(0,150,width,bottom))
  svg=doc[0].get_svg_image(text_as_path=True)
  assert '<svg' in svg
  assert all(ref.startswith(('#','data:')) for ref in re.findall(r'(?:href|src)="([^"]*)"',svg)), 'External SVG resource'
  # Reconstruct explicit inside-box joins, and verify each is actually drawn.
  key=lambda a,b:tuple(sorted([tuple(a),tuple(b)]))
  actual={key(s['start'],s['end']) for s in m['inside_joint_segments']}
  joins=[];endpoint_positions=defaultdict(list)
  for ref,p in m['placements'].items():
   slots=p['slots']
   for s in slots:endpoint_positions[s['endpoint']].append([s['x'],s['y']])
   by=defaultdict(list)
   for s in slots:by[s['endpoint']].append(s)
   groups=[slots] if p['virtual'] or ref in ['TB1','TB2'] else [v for v in by.values() if len(v)>1]
   yy=p['y']+244-18 if p['side']=='top' else p['y']+18
   for group in groups:
    points=[];xs=[s['x'] for s in group]
    if len(xs)>1:points.append([[min(xs),yy],[max(xs),yy]])
    points += [[[s['x'],s['y']],[s['x'],yy]] for s in group]
    assert all(key(*points_) in actual for points_ in points)
    assert len({s['net'] for s in group})==1
    joins.append({'ref':ref,'net':group[0]['net'],'points':points})
  routes=[{**{k:e[k] for k in ['id','a','b','net','net_id','kind','points','color','paths','display','work']},'assembly_id':e.get('assembly_id')} for e in m['routes']]
  for g in m['ground_symbols']:
   if '/' not in g['remote_endpoint']:endpoint_positions[g['remote_endpoint']].append(g['point'])
  for e in m['internal_block_links']:
   ref=e['a'].split('/')[0];p=m['placements'][ref];yy=p['y']+244-18 if p['side']=='top' else p['y']+18
   a=endpoint_positions[e['a']][0];b=endpoint_positions[e['b']][0]
   points=[a,[a[0],yy],[b[0],yy],b]
   routes.append({**{k:e[k] for k in ['id','a','b','net','net_id','kind']},'points':points,'paths':[points],'display':'continuous','color':'#49515B','work':work_info(e)})
  assert {e['id'] for e in routes}=={e['id'] for e in top['connections'] if e['net'] in m['selected_net_names']}
  places={ref:{'x':p['x'],'y':p['y'],'w':p['width'],'h':244,'label':p['label'],'technical':p['technical'],
              'virtual':p['virtual'],'kind':p.get('kind'),'page':p['page']} for ref,p in m['placements'].items()}
  for n in top['nodes']:
   if n['id'] in places or n['id'] not in endpoint_positions:continue
   x,y=endpoint_positions[n['id']][0]
   places[n['id']]={'x':x-10,'y':y-12,'w':20,'h':24,'label':n['label'],'technical':n['status'],
                    'virtual':True,'kind':n['kind'],'page':None,'symbolOnly':True}
  payload['views'][mode]={'bounds':bounds,'imageBox':bounds,'svg64':base64.b64encode(svg.encode()).decode(),
                       'routes':routes,'joins':joins,'placements':places,'endpointPositions':dict(endpoint_positions),
                       'groundSymbols':m['ground_symbols'],
                       'nets':m['selected_net_names'],'counts':m['counts_by_kind']}
  provenance[mode]={str((source/name).relative_to(R)):hashlib.sha256((source/name).read_bytes()).hexdigest() for name in ['Drawing_Manifest.json','Match_Validation.json',m['pdf']]}
 template=(R/'interactive_viewer_j.html').read_text(encoding='utf-8')
 assert template.count('/*__WIRING_DATA__*/')==1
 compact=json.dumps(payload,separators=(',',':'),ensure_ascii=True).replace('<','\\u003c')
 html=template.replace('/*__WIRING_DATA__*/',compact)
 path=OUT/'Race_Car_RevJ_Interactive.html';path.write_text(html,encoding='utf-8')
 (OUT/'Viewer_Data.json').write_text(json.dumps({**payload,'views':{mode:{k:v for k,v in view.items() if k!='svg64'} for mode,view in payload['views'].items()}},indent=2))
 (OUT/'Source_Manifest.json').write_text(json.dumps({'schema':'interactive-wire-viewer-v1','source_revision':'J','source_hashes':provenance,
  'topology_sha256':hashlib.sha256((D/'Physical_Topology.json').read_bytes()).hexdigest(),'html_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
  'native_electrical_change':False,'offline':True,'network_dependencies':[]},indent=2))
 readme='''# Revision J interactive wiring viewer

Open Race_Car_RevJ_Interactive.html in Chrome, Edge or Firefox. It is a standalone
offline file with both full-harness and power-only drawings embedded. No install,
server, account, internet connection or external library is needed.

The viewer opens with C023, the shared starter cable, selected as an example.
Click a wire to highlight its complete path and endpoints. Switch Wire / Net to
trace all branches on that electrical net. Ctrl-click (Command-click on Mac) adds
or removes wires from a multiple
selection. Normal click replaces the selection. Ctrl-click also works on wire
search results and connection-list entries. Net mode traces each selected wire's
net separately; it does not join different nets. Fit selection includes all of
the selected wires; Clear or Escape removes the complete selection. Bookmarked
URLs preserve multiple selected IDs. Switching to power-only retains only
selected wires in that scope. Dim others makes the selected paths
stand out. Wheel to zoom around the pointer; drag to pan. Fit selection includes
the selected paths and their endpoint components. Endpoint buttons jump to the
actual component or joint. Search by conductor C023, net W001, component M1,
splice SP062, device name or terminal (for example M1/B+). Search also finds full
harness items while in power-only view and switches scope when needed.

Click a component box to inspect its connections. A splice box selects its net.
Net highlighting stops at device terminals; it does not cross fuses/contactors,
join CAN H/L, or treat crossing lines as connected. Internal terminal-block metal
and shared-stud connections are explicit. I/B/U continuity and V intact vendor
cables remain distinct from individual C wires and supplied-loom S paths.

Chassis returns are short stubs ending in labelled ground symbols. W IDs retain
electrical identity; GP129-F/C/R identify proposed front/control/rear landing
points. Symbolic B005/B006 chassis-structure bonds are selectable references,
not extra wires drawn between those points. Ground-point endpoint zoom chooses
the symbol for the selected wire. Stub lengths are graphic, not measured cuts.
Sensor/CAN returns, engine returns and isolated battery negative stay explicit.

The retained L94 coil looms are shown through X111 (odd cylinders) and X113
(even cylinders), with their existing internal shared feeds and returns. OEM
bank cavities are reference information pending actual donor verification.
S paths with A-OEM assembly identities are retained stock wiring, not new cut
wires. Injector CUT-INJ nodes are functional cut/termination boundaries, not
factory connectors. Keep the donor injector-only feeds isolated from coil feeds:
never bridge the R3 HCO1 and HCO2 outputs. Final coil low-reference grounding
remains a documented hold; the viewer does not approve a W009/W062 bond.

Escape clears the selection (or closes search first). The address hash records
the selected wire/net/component so a bookmarked file URL can reopen that trace.
The file is read-only with respect to the engineering model and does not modify
native schematics, proposed topology, PDF files or NSP settings.

This is a proposed physical connection topology, not a fabrication release.
Splice/ground locations, materials, cut lengths, hardware and all existing design
holds remain open. The geometry illustrates connectivity, not measured routes.

Rebuild with build_interactive_j.py after the current physical PDFs validate;
validate_interactive_j.py verifies route/native equivalence and embedded data.
Normal rebuild_current.py also includes these steps. Do not hand-edit the
generated HTML or Viewer_Data.json; change the maintained template/builder or
authoritative engineering sources and rebuild.
'''
 readme+='''\n## Component explanations\n\nClick a component box or choose Explain a component in the sidebar. Each of the 96 native component references has a plain-language description, function and project-specific note. The selected box and its incident paths highlight; the Construction filter applies to those paths. Endpoint traces also offer Explain buttons. Selecting a full-harness component from power-only switches scope automatically. K1 and S2 are removed. R3 C5/SPI1 reads S50 HT-010504 TC trim with pull-up OFF; no clutch/neutral input or jumper. U3 is the selected Cole Hersee 24059 starter relay; its explanation lists the four threaded studs and the D60 coil-diode polarity. PWR/OUT/CMD/GND are installer tags, not stamped factory numbers. Actual starter current, F5 coordination and disengagement tests remain open.\n\n## What you need to build\n\nRead the MAKE / LEAD / LOOM / CABLE / HOLD tag on each path, rather than its ID prefix. IDs are retained for traceability. Use the Construction filter to inspect added wiring, supplied lead end work, existing looms or intact cables. Net mode respects that filter; choose All construction to trace the entire net. Searching a hidden wire restores All construction.\n\nLEAD means supplied controller/kit-side wire, still requiring routing and end work, and possibly an extension, adapter or mating pigtail. R3 HT-183200 and PD16 HT-188000 catalog references are recorded; inspect actual harness labels/revisions and reach. Do not assume every displayed end-to-end span is a finished supplied cable. Main heavy feeders are separate. Factory CAN connectors require the dedicated PD16 wake-positive isolation: no cockpit-positive bridge.\n\nThe complete Delta sensor/control loom, supplied fuses, pressure returns and IMU/private CAN stay intact. C158 is a held supplier-routing reference, not a wire to fabricate. Its old ground-enable representation conflicts with current hardware-OFF wording; verify the received loom. IMU cavities and public/private HCU pair mapping remain unconfirmed.\n\nFour TSV work lists are packaged with this viewer. They contain connection references, not measured cut lengths. Additional-wire entries beyond shared joints may use suitable supplied branch leads after inspection. No new wire is automatically required solely because a proposed splice is drawn.\n'''
 (OUT/'README.md').write_text(readme)
 write_work_lists(top,D)
 lists=['Wires_To_Provide.tsv','Supplied_Leads_To_Finish.tsv','Existing_Loom_And_Cable_Paths.tsv','Other_Connection_References.tsv']
 for name in lists:shutil.copy2(D/name,OUT/name)
 with zipfile.ZipFile(OUT/'Race_Car_RevJ_Interactive_Viewer.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
  for f in [path,OUT/'README.md']+[OUT/name for name in lists]:z.write(f,f.name)
 print(json.dumps({'html':str(path),'bytes':path.stat().st_size,'selectable_connections':{mode:len(v['routes']) for mode,v in payload['views'].items()},'offline':True},indent=2))

if __name__=='__main__':build()
