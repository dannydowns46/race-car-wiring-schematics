
## 27 October 2026 - current HT-010504 TC selector / online-first delivery

Owner selects Haltech HT-010504 as S50, a 12-position traction-control level selector.
Module DTM3 pin1/red -> R3 C25 regulated5V via SP061/W061; pin2/white ->
R3 C5/SPI1 on new W137 TC_TRIM_SIG; pin3/black -> R3 C26 via SP062/W062.
Pull-up MUST be OFF. Use the manufacturer HT-010504 calibration matching the
fitted decal; verify molded numbering using the harness-side view. Colours refer
to module leads. Reference/return current, reach/materials and actual hardware
remain to verify. S2 remains absent; W046/C076/C123 stay retired; no start interlock.
This latest C5 allocation supersedes earlier spare/unconnected statements.

Four wheel sensors still feed Delta only; public CAN2 wheel speeds feed R3 TC.
No raw-sensor split, CAN node, extra PDM or output allocation is added. Use rotary
position as the TC Desired Slip and/or Cut Percentage table axis; level direction,
slip/cut values, any OFF detent and invalid-input/CAN response remain tuner choices.
See Traction_Control_Selector.json and C21. No installed NSP setup or powered test.
R3 retains AVI9/C18 and four SPIs C7/C8/C19/C20; PD16 retains two spare AVIs.

New physical paths C215/C216/C217 preserve every retained record and measurement;
C216 uses the supplied R3 flying lead; reference/return branches require grouped
tail/reach inspection. 96 parts /417 pins /358 connected /59NC /116nets;
287 full physical paths, unchanged145 power paths. Source/model checks are retained
to support the interactive view. The owner requests the interactive ONLINE schematic
as the deliverable from here forward; no separate PDF delivery is required.

# Codex briefing - current Revision J

> **LATEST: U3 is Cole Hersee 24059 with local D60 coil suppression. S2 clutch/neutral switch is removed; R3 C5/SPI1 is spare/unconnected, no jumper. C076/C123 and W046 are retired.** See the U3 and S2 sections below; actual NSP and powered tests remain open.

> **CURRENT OWNER UPDATE - 25 October: K1 REMOVED.** CARTEK GT alone provides engine-stop control and battery-negative isolation. GT M6_IGN -> S1 -> R3 A13; F0/2 now feeds TB2/IN directly on W003 **MAIN_FUSED_BUS** (same W003 ID). W128 and C063/C064/C178/C179 are retired; do not reuse them. Positive feeders remain connected when the battery is attached. All physical fuses remain drawn, and the owner explicitly retains **Delta supplied fuses**. Prove engine/fuel/PD16 output shutdown and GT timing before use. Prior passages describing retained K1 or a switched TB2 are superseded by this amendment; historical snapshots are in Change_Records.

Current totals: 19 native sheets, 95 components, 414 pins, 354 connected endpoints, 60 NC, 115 nets. Full physical view 284 connections; power 145/43 nets. Construction tags are independent of stable IDs: **MAKE** additional branch/integration, **LEAD** supplied controller/kit wire needing end work, **LOOM** existing wiring, **CABLE** intact cable, **HOLD** unresolved supplier path. The 176 C IDs are not a count of wires to buy:81 paths use supplied leads; C158 is supplier-routing HOLD. See Harness_Construction.json and the four TSV work lists. Actual grouped branch leads, reach and mating/extension hardware remain to inspect.

Owner uses complete Delta harnesses and R3/PD16 flying-lead harnesses (catalog HT-183200/HT-188000 references). Delta sensor/control/IMU wiring and fused feed assembly stay intact. No fabricated pressure return or private CAN tap. Current Delta OFF-switch wording conflicts with the older pin35 model; C158 is explicitly **not a wire to fabricate**. IMU cavities/public-private HCU pairing remain supplier holds. U3 is selected as Cole Hersee 24059 with external D60 suppression; actual current, F5 coordination and powered release tests remain OPEN. See the current U3 selection section below.

> **25 October update - GT integrated in current drawings:** CARTEK GT replaces X-Pro; one BAOMAIN B00NTT91Y0 internal latching NC stop, no separate external switch, GT blue/blue loop joined. K1 physical positive cutoff retained. TB1 Sierra FS46540 and TB2 Summit SUM-900533 added as PROPOSED parts. Received GT-s/GT-x, actual switch contacts, block ratings/stacking, F4 coordination and powered shutdown still require verification. F2/F3 remain drawn; no removal instructed. See `Race_Car_RevJ/Distribution_Blocks.json` and P06/P07.

The updated power-only continuous sheet is under `Race_Car_RevJ_Power_Only/`. It includes 44 complete native power/control/vendor-link nets and 167 endpoints on 70 component interfaces. Sensor/CAN data and other pins are omitted, not NC. `rebuild_current.py` now rebuilds/checks both continuous views against the same native export. Current J has96 components/418 pins/359 connected endpoints/59NC/117 named nets; retained IDs stay unchanged, old W004 is retired and blue loop is W136. The older dated ZIP/package manifests remain historical snapshots; transfer the updated workspace or regenerate a package before relying on them.

## 24 October 2026 - shared starter and alternator cable

Owner selects one heavy cable from the positive block next to the battery to the starter, with a separate alternator cable attached to the same starter **battery-side B+ stud**. The maintained drawing includes F2 near the battery block and F3 near the starter branch. F3/1 moves from W001/BATT_RAW to W011/STARTER_FEED; W008/ALT_BPLUS remains F3/2 to G1/B+. All W identifiers are retained. Neither the small solenoid trigger nor the motor-side stud is this junction.

The raw positive block now has four electrical connections: battery positive, F0 main distribution, F2 shared starter/charging trunk and F4 CARTEK control. The switched block still has six: F0/2 incoming (K1 removed), F1 R3, F50 PD16, F41/F42 ABS and F5 starter driver. TB1 Sierra FS46540 and TB2 Summit SUM-900533 are now proposed parts; these connection counts do not establish actual stud allocation or permitted lug stacking.

See `Race_Car_RevJ/Starter_Alternator_Routing.json` for the physical routing intent, current paths, source and unresolved checks. F2 must accommodate cranking and charging; F3 protects the alternator branch from battery-fed faults, with alternator-fed faults assessed separately. Actual cable gauges, fuse types/ratings, starter stud/stack/torque/cover limits, voltage drop and cutoff tests remain release holds. CARTEK/K1, all downstream main supplies and negative returns are unchanged. This update does not restore any removed injector/coil/lift fuse.

The earlier 24 October power-analysis report and ZIP remain historical snapshots. Load totals are unchanged by this routing choice; their former separate alternator-to-battery route discussion is superseded. Recalculate cable losses from the installed shared path and measure hot charging voltage/current. Change records and the pre-change model are under `Change_Records/2026-10-24_Starter_Alternator/`. Existing package manifests describe their original packages, not this later workspace update.


Updated24October2026. Owner: Daniel (Danny) Downs. Read START_HERE.md, this file, Vehicle_Wiring_Design_Basis.md, Race_Car_RevJ/README.md and OPEN_ITEMS.tsv. J supersedes I for single-wideband/second-temperature-sensor selection. I superseded H following the owner's instruction "Make all changes" to the proposed master-cutoff and branch-protection work. H/audit files remain historical evidence. No installed NSP tune or completed physical harness is supplied.

## Revision J - wideband and transmission temperature

- Owner selects exactly ONE wideband O2 sensor, directly controlled by the R3 onboard WBI1. B9 and its six WBO nets are retained: C29 HTR+, C30 INPUT, C31 PUMP, C32 NERNST, C33 HTR-, C34 CAL. Revision I already modeled a single sensor, so no second sensor/controller circuit existed to delete. No WB1/WB2, extra CAN branch, AVI or external heater feed is added.
- Exact wideband sensor/adapter is not selected. R3 supports Bosch LSU4.9 or NTK; use the matching hardware/adapter and NSP sensor selection. B9 terminals are functional labels, not confirmed sensor connector cavities. Confirm exhaust location and the tuner's single-sensor strategy; do not treat one measured exhaust stream as independent two-bank feedback. Keep supplied sensor calibration components/connector intact.
- B32 remains the engine-oil HT-010306 high-range 150C sensor: EV1 B signal -> PD16 A20/AVI1; A return -> PD16 A11.
- Added B33, a second HT-010306 high-range 150C sensor for transmission oil: EV1 B signal -> PD16 A21/AVI2, new W135/TRANS_TEMP_SIG; EV1 A -> existing W124/PD16_SG and PD16 A11.
- Configure independent Engine Oil Temperature and Transmission Oil Temperature channels. Each AVI uses its internal 1k pull-up and the full manufacturer `Temperature - Haltech Oil 150C 1/8 NPT HT010306.cal` calibration. No external 5V lead or accessory ground is added. Verify PD16-to-R3 sharing and actual installed firmware/configuration; no tune was supplied or edited.
- R3 spare capacity stays one AVI, four SPI and six DPO. PD16 now has TWO spare AVIs (AVI3/A27, AVI4/A28); all output reserves remain unchanged. No I/O expander is needed for this addition.
- Transmission sensor mounting/thread/immersion and mechanical clearance, operating-temperature range, reference-temperature verification, separate alarms/open/short diagnosis and stale-CAN behavior remain commissioning work. No temperature thresholds or protection actions are invented.
- All Revision I power, cutoff, split-pump and isolated CAN-power construction requirements remain in force. No change to installed-hardware or fabrication-release status.

## Retained Revision I electrical changes

- U2 is now CARTEK GT per manual rev1.0 (07Nov2025). Confirm received GT-s/GT-x variant. M8 is the only vehicle cable on BT1 negative; case bonds chassis. All loads return on the vehicle side, not BT1 negative. GT limit is 600A cranking/2000A surge, subject to actual starter checks.
- GT has two distinct M6 studs: M6_BAT is permanent positive through F4; M6_IGN is the fixed 40A protected engine-stop output. These labels are drawing functional identities, not connector cavities. Red/black flying leads connect to S40's verified NC pair; released/reset closed ON, pressed/latched open OFF. Two blue leads are permanently joined as new W136, never to chassis. S41 and old W004 external-to-chassis loop are retired. S40 pins 1/2 are functional terminals, not verified markings. The button is owner-ordered BAOMAIN B00NTT91Y0, cockpit mounted and reachable inside/outside; no separate external switch.
- K1 TE EV200AAANA remains the normally-open main positive contactor. A1 from F0; A2 to switched W003/TB2 and F1 R3, F50 PD16, F41/F42 ABS and F5 starter driver. GT M6_IGN powers K1 red coil and S1 -> R3 A13. R3 A26 remains NC. GT output carries control current only; no entire fuse box or R3/PD16 main load through its 40A output.
- F4 5A and 18AWG control wiring remain proposed; verify actual fuse curve with K1 3.8A/130ms pull-in, 0.13A hold and A13 load. GT has no selectable 5A engine-stop setting. K1 has internal economizer/suppression; no extra diode. Verify pickup/hold/cranking and release timing. Reset may re-arm power; require fresh start command.
- BT1+ / TB1 -> F2 near block -> shared heavy trunk -> M1 battery B+ stud -> F3 near starter -> alternator G1. F0 main and F4 GT are other TB1 branches. TB1 FS46540 raw post and TB2 SUM-900533 switched bus are proposed, not purchased/released. Four raw / six switched branch connections; functional TB port IDs are not stud numbers. Resolve TB2 listing 250A vs family150A and all stack/torque/cover/thermal details before fabrication. F0/F1/F2/F3/F5/F50 values remain holds. Assess both-source charging faults; positive start/charge cables remain connected to battery with GT OFF.
- Lift1 M3 retains R3 E4/W073 LIFT_SUPPLY; lift2 M4 moves to PD16 B4/W132 LIFT2_SUPPLY. Each has independent electronic protection and command/diagnostics. Injector and coil positive banks remain on R3 E1/E2, conditional on protection coordination with every branch/pigtail/contact. No removed injector/coil/lift fuses are restored; no outputs are paralleled.
- Moving a fuel pump to PD16 makes its wake/CAN behavior important. PD16 A25 now has dedicated R3 HBO6/A25/W131. ABS ignition uses R3 HBO3/A21/W130 through retained F43. Cockpit HBO4 no longer powers either critical wake feed. Programme PD16 pump CAN-loss default OFF and inhibit engine operation on a critical fuel-channel trip or invalid PD16 communication; exact available status channels/timeouts must be confirmed in the installed NSP version.
- Owner-confirmed crank GM12703627 remains A->R3 C1, B->C26, C->C25. Cam GM12591720 is now explicitly A->C25 regulated5V, B->C26, C->C3 Home+. The old W079 cam-supply placeholder is retired; W078 remains retired. Source differences between OEM5V application and other ECU12V applications remain documented. Confirm physical mating orientation, current and Hall configuration before power.
- Pressure sensors retain labelled supplied Delta loom connections. W112 depicts supplier-internal return continuity with unknown internal cavity; it is not an instruction to add a chassis ground or a Haltech wire. The supplier assembly boundary supersedes A02's literal new-harness interpretation. The published wheel-speed broadcast is corrected to100Hz, separate from unmeasured end-to-end traction-control latency.


## Vehicle and owner decisions

- Custom race car, L94 engine donated by a 2011 Yukon Denali, with LS3 cam/intake/throttle-body changes. It is not a production Corvette wiring conversion. Reuse suitable donor wires/pigtails in a new Haltech-oriented harness; the owner explicitly does not intend to plug the OEM harness into the Haltech.
- Nexus R3 ECU/integrated PDM plus Haltech PD16 HT-198100. iC-7 replaces the earlier uC-10 choice. Owner reports purchase of the HT-011502 15-button CAN keypad (seller reference HTH-HT-011502) and WOLFBOX G900 Pro mirror system. iC-7 purchase was not expressly confirmed.
- Owner plans to buy the matching WolfBox G900 Pro hardwire kit for its converter and wiring; receipt/version is not confirmed. Earlier generic 5A buck-converter suggestions are superseded.
- Added equipment: HT-011600 TMS-4 TPMS, two HT-010306 high-range sensors (engine oil and transmission oil), HT-010206 intake-air-temperature sensor, HT-010910 150 PSI motorsport fuel-pressure sensor. These were selected/requested; do not equate that with confirmed delivery.
- Braille G30H LFP battery (12.8V, 30Ah/384Wh, listed 9lb), in the tunnel. Owner confirms tunnel is fully separate from cockpit. Tuff Stuff 79376G one-wire 120A alternator. CARTEK/K1 cutoff is the selected drawing design; hardware receipt, completed installation and charging/isolation tests remain unverified.
- Aftermarket high-torque VW starter/VW-bus transaxle installation; exact starter/driver details unresolved. C6 accelerator pedal GM 19417903; matching connector still needed and cavity mapping not verified. CPP-LSAPP was only a connector candidate, not a confirmed purchase.
- PROFORM 67049 twin-fan kit, two 67048 brushless puller fans, listed 10A each. Front GT40 radiator face 24x12in; rear fan clearance owner-confirmed. Basic full-voltage ON/OFF control selected; no variable-speed signal or power PWM selected.
- Mechanically cable-operated fire system; no electrical release circuit. No horn or wipers requested. Rain light, driver communications and transponder are not confirmed additions. Brake-marker electronics U22 are their own device, not WolfBox GPS or a driver radio.
- Owner is targeting NASA general rules without choosing a particular class. NASA CCR 2026.3 was the earlier design reference, not a certification or a guarantee of current class legality. Recheck the applicable current rules when finalizing installation.


## Preserved allocations and operating intent

PD16's CAN branch shares H/L/return only with the cockpit network. Its A25 positive power is exclusively R3 HBO6; do not install a standard four-wire hub branch that joins this to cockpit HBO4. Document the isolated power leg in the physical harness and verify no cross-feed before powering the units.

Engine: R3 E1 injectors, E2 coils, E3 DW200, E4 lift1. PD16 B1/B2 independent fans, B3 both headlights, B4 lift2. PD16 A3 both tails, A4 both brake bulbs, A7 WolfBox converter, A8 brake-marker electronics. R3 HBO1/2 DBW; HBO3 ABS ignition; HBO4 cockpit; HBO5 starter command; HBO6 PD16 wake. R3 A26 unused. Physical emergency control is through CARTEK, not the CAN keypad.

Rear lights: H31/H35 tail bulbs, H34/H36 brake bulbs. Hazards flash both headlights AND both tails together, overriding steady requests. Brake bulbs stay steady on valid brake request. No separate hazard bulbs. Preserve this logic. A01's separate question about brake lamps during Delta/R3/CAN failure is still open; separating wake supplies does not create independent brake-lamp hardware.

R3 sensor assignments remain: APP1/2 C10/C11; TPS1/2 C12/C13; oil pressure C14; HT010910 fuel C15; coolant C16; HT010206 IAT C17; C18 AVI9 spare; Novotechnik RSC-2841-634-211-202 gear C27; HGT force C28. Crank C1, cam C3. C25 shared200mA5V reference; C26 shared500mA sensor return, including coil signal returns subject to actual coil requirements. DBW motor wiring/pedal19417903 pigtail cavities remain unverified. No software calibration is inferred from the physical assignments.

HT010910 A ground/B5V/C signal, pull-upOFF, exact150PSI calibration; remote mount per Haltech. HT010206 pin1 signal/2 return with correct temperature pull-up/calibration. HT010306 engine oil is PD16 AVI1/A20 and transmission oil is PD16 AVI2/A21; both use sensor ground A11, EV1 sensor A return/B signal, internal1k pull-up and exact oil calibration. Never merge R3, PD16 or dash sensor returns in the harness.

Haltech CAN1 is1Mbit/s linking R3, PD16, iC-7, keypad,TMS4. Intended end resistors R3 and PD16; J30 represents the PD16 end, not an added third resistor. Delta public CAN goes separately to R3 CAN2 C21/C22 from auxiliary J22 pins3/2. Its actual bitrate, firmware/DBC compatibility and stale-data behavior remain commissioning work. Four raw wheel sensors connect only to Delta. Public wheel-pulse pins7-10 remain NC. Delta brake sink feeds R3 SPI2/C6: specify correct bias/polarity and use validated brake state for lamps and DBW override. Supplied IMU/private bus stays internal. Front GM22742183 compatibility is not yet established.

iC-7: pins1/2 CANH/L,3 cockpit positive,4 low-current CAN return,21 AVI4 fuel level,30 sensor return. SN38T10 is0-90ohm; confirm hardware-supported240ohm pull-up and calibration. Gear display comes via CAN. uC10 CAD is historical. Firmware compatibility, input/output ownership and PD16 safe states must be set in the actual installed configuration; do not treat the older minimum sharing versions as a complete multi-master setup.

TMS4 HT011600 receiver MCON1CANL/2CANH/5positive/6return; supplied adapter DTM1positive/2ground/3CANH/4CANL. Four wheel sensors are wireless and provide tyre pressure/temperature, not traction wheel speed. Enable valid vehicle speed for lost-sensor diagnostics. Receiver adds published50mA; whole cockpit/return current remains to check.

WolfBox G900Pro: PD16 A7 powers vendor converter yellow BATT and red ACC together for switched-only use; black to VEHICLE_RETURN. Preserve vendor USB-C and rear-camera cable assemblies. Mirror receives regulated5V, not vehicle12V. Confirm received kit/version and same-switched-feed boot behavior. GPS/reverse lead omitted/insulated. Enable rear view and disable screen saver; protect non-waterproof cable joints. Camera toggle is owner-confirmed; button position10/defaultOFF remain proposals, not confirmed choices. If sole useful rear view, default/boot delay is safety-significant.

Keypad positions remain proposals:1run/stop,2momentary start,3headlights,4tails,5hazards,6fan override,7bounded prime,8dash next,9acknowledge,10camera,11-15spare. Normal keypad run control cannot override physical master stop or wake an unpowered ECU.

Current spare capacity: R3 one dedicated AVI, four SPI, six DPO, no HBO or HCO. PD16 two AVI, four SPI, two HBO and six8A HCO, no25A HCO. Dash extended capacity remains hardware/firmware dependent and is not needed for these allocations. Physical I/O count does not prove installed ownership/configuration.

## Build, release status and next work

Current revision J. Current source build-racecar-revj.js; current model Race_Car_RevJ/Design_Data.json; continuous source build_single_page_j.py. Use rebuild_current.py, then inspect current native/continuous validations and changed-page renders. Preserve IDs and historical I/H sources. Read the full current README, Protection_Schedule.tsv, Branch_Coordination.tsv, Control_Specification.json, Commissioning.tsv and Audit_Disposition.tsv. Unknown fuse/gauge/current data remain explicit UNRELEASED fields. Do not run create_revision_i.py or Revision_I_Work/Revision_J_Work migration scripts as the normal rebuild.

The user authorized design edits, not invented measurements. No hardware faults, currents, settings or checkout results may be marked confirmed without evidence. Do not automatically restore removed bank/lift fuses or claim all safety findings closed. Next work is physical cable/contact data, load measurements, K1/CARTEK shutdown/cranking tests, actual NSP control/protection configuration and remaining DBW/ABS/brake-light commissioning. Existing A14/A03 architecture is drawn, but numeric protection and real operation are not certified. Prior detailed handoff is History/RevH_Root_Documents/CODEX_HANDOFF.md.

## Battery packaging CAD

Owner-requested Braille G30H STEP models are in `CAD/G30H/`: a colored exterior model and a plain envelope, both 174 x 132 x 177mm. These are the explicit metric dimensions from Braille's own shop, which differ slightly from converting its rounded 6.8 x 5.2 x 6.9in listing. Terminal positions, bores, lid details and radii are photo-based estimates; no toleranced manufacturer CAD was supplied. Read MODEL_NOTES.txt, Model_Parameters.json and Validation.json before using the model for packaging or fabrication. Base origin at footprint centre; front faces -Y; positive terminal is +X. Bolts, lugs, optional studs and service clearance are omitted. `Braille_G30H_CAD_Package.zip` is the standalone transfer bundle; future whole-project packages should retain the uncompressed CAD source/model files. This CAD addition does not change Revision J electrical connectivity or release status.

## Power analysis and owner clarifications - 24 October 2026

- `Power_Analysis_2026-10-24/` contains the power report, reproducible calculations, component coverage, source archives, unresolved evidence and review records. It supplements J without changing its connectivity or releasing fuse/wire/NSP settings. Any older transfer ZIP predating this folder does not include the analysis.
- Owner confirms stock L94 ignition coils, LS3 injectors, ATI damper **917289**, alternator pulley measured **2.186in outside diameter at the rib crests**, and maximum engine speed **6600RPM**. ATI lists the damper at6.78in,10% underdrive. Do not apply the10% factor again.
- Pulley-speed hold: OD screening gives3.1016:1 and20,470 alternatorRPM at6600 engineRPM, above Tuff Stuff's general18,000RPM limit. Confirm effective belt diameters and applicable79376G limit; correct ratio/fitment before high-RPM operation. A larger alternator pulley also requires rechecking hot-idle charging. No pulley purchase/installation is claimed.
- Fans normally remain OFF on track, operating only as needed in pits/cooldown. Engine-off fan run may be zero. Camera is ON whenever the engine runs. Lift pumps see low pressure; both assumed running continuously. Owner will connect a charger in the pits; charger model/current/profile and actual restored SOC are unconfirmed. Headlight wattage/use, actual fan current and unmodeled accessories remain open.
- Expected/conservative planning cases: track fan-OFF/headlight-OFF42/67A; headlights-ON50/79A; fans/headlights-ON70/105A. Full ABS actuation plus fans/lights gives an estimated99/129A active-load envelope before unmeasured startup peaks. These are estimates, not measured circuit currents or protection settings. No model-specific hot alternator output curve was found.
- Fan evidence conflict: historical J labels say10A per67048. Search-indexed PROFORM2026 catalog says13A per67048/26A per67049pair. Full catalog returned406 and live product page a challenge; do not silently change native labels to13A as a confirmed hardware measurement. Measure installed fans and resolve source/hardware revision before protection release.
- G30H manufacturer datasheet rev05-23 was successfully recovered this time and archived in the analysis folder. Confirms30Ah/384Wh,300A continuous DISCHARGE,14.4-14.6V recharge/13.8V maintenance,0-50C charging/-20 to+60C discharge. G30H-specific maximum CHARGING current remains unknown; do not substitute its discharge rating. Braille general FAQ says noBMS; no automatic low-voltage cutoff is credited. Verify tunnel temperature, cold/hot regulator voltage, charge current and battery health/SOC.
- Conclusion is conditional:120A is plausible for normal30-minute stints with fans OFF and pit recharge, provided actual hot output covers measured loads and charging is compatible. Do not rely on a full30-minute alternator-failure stint; reserve calculations and commissioning tests are in the report.


## 25 October - individual physical conductors

Both continuous views now show individual proposed physical conductors and explicit joints, replacing the earlier net-wide logical buses. Native parts, cavities, electrical nets and retained W IDs are unchanged. Full view: `Race_Car_RevJ_Single_Page/Race_Car_RevJ_Continuous_Wiring.pdf`. Power-only: `Race_Car_RevJ_Power_Only/Race_Car_RevJ_Power_Only_Physical_Wiring.pdf`. The older power-only Continuous PDF is the superseded logical-bus snapshot, not the current physical view.

`Race_Car_RevJ/Physical_Topology.json` is the maintained proposed connection topology; `Physical_Connections.tsv` lists individual ID/from/to/net/kind/pair and material/measurement fields; `Physical_Junctions.tsv` lists explicit splice/ground-point intent. C IDs identify 180 proposed individual integration/field conductors (87 in the power-only view); S identifies 85 supplied/retained-loom conductor paths (41 power); V identifies two intact vendor cables. I internal continuity, B metal/lug/bond continuity and U unresolved supplier paths are distinct and are not additional cut wires. W IDs still identify electrical nets, not cuts. J2/J3/J21 are existing ground cable/ground assemblies whose bodies join their own ends.

TB1 has four external branch wires, TB2 six, with their common metal explicitly shown inside the blocks. The shared starter B+ stud has two wire ends. Multiway feeds/returns/reference branches now land at named proposed joints. Proposed CAN1 linear trunk order is R3 -> dash tap -> keypad tap -> TMS4 tap -> PD16, with paired H/L paths and internal PD16 termination represented without an extra field resistor. Exact packaging, tap lengths and all physical joint locations remain open. GP129 front/control/rear ground-point distribution is proposed, with metal/bond paths kept separate from cut-wire records; sensor/CAN returns stay isolated from it.

No final wire gauge/color/cut length/terminal/splice hardware or physical vehicle route is established. Measure and approve these before fabrication. Preserve supplied Delta pressure returns and intact WolfBox USB/rear cables; unresolved supplier construction is not turned into a fabricated splice/cavity map. No extra ground bypass or electrical reassignment was made.

`physical_topology_j.py` audits the maintained model and refreshes derived schedules during normal builds. Its `--initialize` option refuses to overwrite an existing topology: do not delete/reinitialize it after entering measurements. `render_physical_j.py` renders both views; `validate_physical_j.py` independently recovers the actual PDF conductors and explicit internal bars/dots and matches the native net endpoint sets. Existing build/validate entry-point names call these modules, so `rebuild_current.py` remains the portable command. Prior build reports/ZIPs/change records remain their dated snapshots.


## Interactive wire tracing - 25 October

Open `Race_Car_RevJ_Interactive/Race_Car_RevJ_Interactive.html` in a modern browser,
or transfer `Race_Car_RevJ_Interactive/Race_Car_RevJ_Interactive_Viewer.zip` and
extract it first. The standalone file embeds both physical-conductor drawings
and all tracing data; it needs no server/install/internet. The local browser
preview is for review only; the standalone file/ZIP is the portable deliverable.

Click a wire to highlight its path and endpoints. Wire/Net chooses one conductor
or every branch of the same electrical net. Dim others, Fit selection, Overview,
scroll zoom, drag pan, endpoint zoom buttons and ID/name/terminal search are
included. The initial example is C023, the shared starter cable. Full-harness-only
search results switch scope automatically. The URL hash can bookmark a selection.

This read-only derived view changes no native or physical topology assignments.
It retains all 117 full-harness nets (44 power-only) and 288 selectable connection
records (147 power), including explicit internal block metal. Internal/bond/
unresolved paths and intact cable assemblies remain distinct from cut wires.
Existing material, physical location, rating, hardware and fabrication holds apply.

Maintain `interactive_viewer_j.html` and `build_interactive_j.py`; generated HTML
and Viewer_Data.json must not be hand-edited. `validate_interactive_j.py` checks
embedded metadata and drawing paths against the current model and validated PDF
manifests. Both are integrated into `rebuild_current.py`; read Viewer Validation
and Browser_QA.json alongside the native/physical validation reports. Regenerate
after a changed physical drawing so the viewer cannot silently become stale.

Ctrl-click (Command-click on Mac) now adds/removes individual wires without clearing the others; normal click replaces the selection. This also works on wire search results and connection-list entries. Fit selection and Net mode apply to all selected wires; different nets remain separate. Clear/Escape removes all selections and bookmarked URLs preserve multiple IDs.


## Chassis-ground display update - 25 October

Both current continuous PDFs and the interactive viewer show chassis returns as
short wire stubs ending in labelled ground symbols. W129/GP129-F, -C and -R retain
the proposed front/control/rear physical landing points. B005/B006 chassis metal
continuity is represented by those W129 references, not extra field wires.
W015 case/chassis bonds retain their own labels. Match W IDs when tracing.

This is a drawing simplification only: no native pin/net, physical connection,
measurement, material or protection assignment changes. Short graphic stubs do
not prescribe cut lengths or eliminate required physical return wires/bonds.
Sensor/CAN returns, W009 engine returns and W002 battery negative through the
CARTEK remain explicit. Temperature sensors must use their controller's sensor
return: R3 C26 for intake air/coolant; PD16 A11 for both oil-temperature sensors.
Ground-point endpoint buttons zoom to the selected wire's local symbol.
Ctrl-click multi-selection and Wire/Net highlighting remain supported.

The updated full sheet uses its usual Continuous_Wiring filename. Native sheets
remain the unchanged source design.


## Retained stock engine harnesses - 25 October

Owner confirms stock L94 coils and coil-bank looms, with LS3 injectors using the
retained L94 donor injector wiring if actual connector fit and reach permit.
Current J now has 19 sheets, 96 components, 418 modeled pins, 359 connected
endpoints, 59 NC/unavailable positions and the same 117 named nets. X111/X113 on
new sheet 19 represent the odd/even OEM coil-bank interfaces. All existing device
assignments, R3/PD16 output allocations and retained W IDs are unchanged.

Read Race_Car_RevJ/Stock_Engine_Harnesses.json and OEM_Harness_Interfaces.tsv.
Reference bank positions are A power ground, E low reference, H +12V; four trigger
positions differ by bank, and D is unavailable. These are GM service reference
cavities, not an inspection claim for the donor. Functional coil/injector device
pin IDs remain distinct from source cavity references. Catalog references include
square12570616/service12611424 and round12573190/service12699382; actual version
is unverified. No supplier PN, wire color or gauge is asserted as inspected.

Both continuous PDFs and the viewer now distinguish 56 retained OEM S conductor
paths (38 coil, 18 injector) from new C integration wires. The complete topology
has 180 C, 85 S, 2 V, 11 I, 9 B and 1 U records: 288 selectable connections full,
147 power-only. The power view retains 44 nets, 70 component interfaces and 167
native endpoints; it omits low-reference and trigger signals. Shared stock-loom
nodes represent functional continuity; exact joint counts/type/locations remain
unverified. CUT-INJ nodes are functional cut/termination boundaries, not invented
factory bulkhead plugs. Thirty-two old generic direct-branch C records are retired
and archived; other record IDs/material fields are preserved. Do not reinitialize
the topology or rerun the one-time migration under Change_Records.

Factory feeds can serve injectors and coils together. Separate donor injector-only
feed branches from coil/other loads so R3 E1/HCO1 cannot be connected to E2/HCO2.
No removed bank fuses are restored. Coordinate electronic trip curves with every
retained branch wire, splice, bank feed and connector contact.

Coil low-reference grounding remains HOLD: the drawing retains bank E to R3 C26,
separate from bank A to engine ground. GM OEM evidence separates these circuits;
Haltech's generic Gen IV guide also advises both coil grounds at the head. Resolve
that difference with the exact coil/R3 installation evidence before power. Do not
bridge W009 to W062 or add a chassis bond to sensor ground from this drawing.
Temperature sensor returns and the CARTEK isolated-negative path are unchanged.

stock_engine_harness_j.py audits the maintained donor assembly paths and is called
by the normal topology audit. Normal rebuild_current.py regenerates native sheets,
schedules, both continuous PDFs and the viewer/ZIP. Fresh export and actual PDF
path/symbol equivalence are checked; physical fit and powered behavior remain C18
commissioning work. Earlier numerical counts in dated sections are snapshots.

## Current component explanation viewer

Click a component box/header or choose **Explain a component** in the sidebar to highlight it and read what it is, what it does and its project-specific notes. All 95 native component references have descriptions in Component_Guide.json. They distinguish connector views of the same R3/PD16 from extra devices and identify selected U3 hardware and unresolved interface details. Endpoint traces also include Explain buttons. The construction filter is preserved for incident paths; component search can switch to full harness automatically. Read Browser_QA.json and the current build reports. The portable viewer ZIP includes the four construction work lists.


## Current U3 starter relay selection — 25 Oct 2026

U3 is now the owner-selected **Cole Hersee 24059** base part: 12V, 17.5-ohm isolated coil, 85A normally-open contacts, bulkhead bracket, two large 5/16-24 and two small #10-32 studs. PWR/OUT/CMD/GND are installer functional tags, not claimed stamped terminal numbers or fixed left/right positions. See `Race_Car_RevJ/Starter_Relay.json` (or `Starter_Relay.json` inside that folder).

Large PWR takes F5/2 via C026/W013; the other large OUT goes to the starter's **small SOL terminal** via C025/W012. Small CMD takes R3 A18/HBO5 via C027/W014; the other small GND returns to GP129-C vehicle return via C180/W129, not the isolated battery negative or the relay case. The starter motor's heavy B+ trunk is separate.

D60 is an external Vishay 1N5408-E3/54 suppression diode across the small coil studs: **banded cathode K to CMD, unbanded anode A to GND**. C213/C214 identify its local insulated leads, not two new long harness wires or a second remote ground landing. Confirm actual received part and polarity before powering. The diode affects release timing; verify prompt starter disengagement and abort/master-OFF behavior under C19. Calculated coil draw is about 0.69A at12V; the owner's approximately30A solenoid pull-in estimate is unmeasured. F5 remains present, rating and wire/contact coordination unselected. No installed NSP settings or powered test is claimed.

Current model after S2 removal: 95 parts, 414 pins, 354 connected endpoints, 60 NC and115 W nets. Physical views have284 full /145 power paths, with26 chassis-return glyphs under existing display policy. Construction totals:94 MAKE,81 LEAD,85 LOOM,2 CABLE,11 internal,9 structure and2 HOLD. C213/C214 and D60 are added; C076/C123 and W046 are retired with S2. Retained conductor identifiers/endpoints/measurement fields remain. The interactive viewer includes a four-stud wiring table and suppression polarity for U3 and an explanation for D60. Earlier dated numerical snapshots are historical.

## S2 removal — latest owner update, 25 Oct 2026

S2 clutch/neutral start switch is removed, including C076 and C123. W046 START_PERMIT is retired and must never be reused. **R3 C5/SPI1 is now spare and unconnected**; insulate the unused supplied lead individually. No replacement neutral switch or jumper is inferred. Starter-control intent no longer requires a clutch/neutral input; fresh request, GT/R3 run permission, engine-not-running inhibition, bounded crank and release on running/request end/timeout/abort/master OFF remain to implement and verify. See Control_Specification.json, Starter_Relay.json and commissioning C20. Native sheets3/6, schedules, continuous views and viewer are updated together.

## Public schematic website — 26 October 2026

The current public library is https://dannydowns46.github.io/race-car-wiring-schematics/ . Repository: https://github.com/dannydowns46/race-car-wiring-schematics . GitHub Pages publishes main / (root); upload the CONTENTS of Public_Site/dist, keeping .nojekyll and .gitattributes. Public access was explicitly approved by the owner. Preserve this repository and URL for future requested updates.

Read Public_Site/HOSTING.md and publishing.json. After an authorized design update, rebuild/validate/inspect the maintained schematics, then run Public_Site/prepare_release.py with a new date/release ID and publish the refreshed assets to the same site. Preserve dated archive ZIPs; never silently replace released bytes. The current project download is a validated maintained working set, not every historical CAD/transfer archive. No background job is installed; requests trigger future rebuild/publication. Authentication must use the owner's GitHub session or a later explicitly configured integration; no token is stored.
