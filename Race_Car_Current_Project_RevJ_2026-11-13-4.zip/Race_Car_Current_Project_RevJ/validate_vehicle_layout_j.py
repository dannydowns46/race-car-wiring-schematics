"""Validate the vehicle presentation independently of the retained PDF row layout."""
from pathlib import Path
from collections import Counter
import json,base64,hashlib,xml.etree.ElementTree as ET
from physical_topology_j import R,D,load_and_audit
from vehicle_layout_j import LAYOUT,segment_hits
from ground_display_j import CHASSIS_NODES,is_structure_reference

def validate(embedded):
    native,top=load_and_audit();layout=json.loads(LAYOUT.read_text());byid={e['id']:e for e in top['connections']}
    assert embedded['vehicleLayout']==layout
    report={'result':'PASS','native_electrical_change':False,'physical_topology_change':False,'views':{}}
    fullplaces=embedded['vehicleViews']['full']['placements']
    bodies={ref:[p['x'],p['y'],p['w'],p['h']] for ref,p in fullplaces.items() if not p['virtual']}
    for ref,a in bodies.items():
        for other,b in bodies.items():
            if ref>=other:continue
            assert not(max(a[0],b[0])<min(a[0]+a[2],b[0]+b[2]) and max(a[1],b[1])<min(a[1]+a[3],b[1]+b[3])),('Component overlap',ref,other)
    nodes={ref:[p['center'][0]-17,p['center'][1]-17,34,34] for ref,p in fullplaces.items() if p['virtual'] and not p.get('symbolOnly')}
    for mode,v in embedded['vehicleViews'].items():
        selected={n['name'] for n in native['nets']} if mode=='full' else set(top['power_net_names'])
        expect={e['id'] for e in top['connections'] if e['net'] in selected}
        assert {e['id'] for e in v['routes']}==expect and len(v['routes'])==len(expect)
        assert set(v['nets'])==selected and v['layout']=='vehicle'
        svg=base64.b64decode(v['svg64']).decode();root=ET.fromstring(svg)
        assert (R/'Race_Car_RevJ_Interactive'/f'Vehicle_{mode}.svg').read_text(encoding='utf-8')==svg
        assert not any(attr.startswith(('http:','https:','//')) for el in root.iter() for key,attr in el.attrib.items() if key.endswith(('href','src')))
        shown={el.attrib['data-component'] for el in root.iter() if 'data-component' in el.attrib}
        assert shown=={ref for ref,p in v['placements'].items() if not p.get('symbolOnly')}
        assert sum(el.tag.endswith('text') and (el.text or '').endswith('  NC') for el in root.iter())==(59 if mode=='full' else 0),'NC markings missing from actual SVG'
        for e in v['routes']:
            original=byid[e['id']]
            assert all(e[k]==original[k] for k in ['id','a','b','kind','net','net_id'])
            if is_structure_reference(original):assert e['paths']==[];continue
            for end,point in [('a',e['points'][0]),('b',e['points'][-1])]:assert point in v['endpointPositions'][e[end]],(mode,e['id'],end)
            own={e[k].split('/')[0] for k in ['a','b']}
            for path in e['paths']:
                for a,b in zip(path,path[1:]):
                    assert a[0]==b[0] or a[1]==b[1],('Nonorthogonal conductor',e['id'],a,b)
                    for ref,box in {**bodies,**nodes}.items():
                        if ref not in own:assert not segment_hits(a,b,box),('Path crosses unrelated component/joint',e['id'],ref,a,b)
            if e['kind'] in ['I','B','U']:assert not e['branch_ids'],('Non-cut continuity counted as loom wire',e['id'])
        for ref,p in v['placements'].items():
            assert p==fullplaces[ref],('Position moves when changing power/full scope',ref)
        rows=[row for group in v['pinRows'].values() for row in group]
        expectedpins={p['ref']+'/'+pin['num'] for p in native['parts'] for pin in p['pins'] if mode=='full' or pin['net'] in selected}
        assert {r['endpoint'] for r in rows}==expectedpins
        assert sum(r['net'] is None for r in rows)==(59 if mode=='full' else 0)
        assert len(v['groundSymbols'])==26
        assert {g['connection']+'-'+g['endpoint'] for g in v['groundSymbols']}=={g['connection']+'-'+g['endpoint'] for g in embedded['views'][mode]['groundSymbols']}
        for branch in v['branches']:
            assert set(branch['connections'])=={e['id'] for e in v['routes'] if branch['id'] in e['branch_ids']}
        report['views'][mode]={'connections':len(v['routes']),'native_components':len(bodies) if mode=='full' else sum(not p['virtual'] for p in v['placements'].values()),
            'pins':len(rows),'NC':sum(r['net'] is None for r in rows),'branches':{b['id']:len(b['connections']) for b in v['branches']},
            'actual_svg_component_glyphs':len(shown),'ground_symbols':len(v['groundSymbols'])}
    report['checks']=['Every retained ID/endpoint/kind/net is identical in vehicle and circuit presentations.',
        'Every native cavity/function and59 NC positions retained; power-only omits other pins without declaring them NC.',
        'No wire path crosses an unrelated component body or splice dot; overlapping loom lines do not create electrical joins.',
        'Native component rectangles do not overlap; full/power share identical positions.',
        'Trunk membership lists actual route records; internal metal/bonds/unresolved continuity are not counted as loom conductors.',
        'All26 ground references retain their source endpoint/net identities.']
    (R/'Race_Car_RevJ_Interactive/Vehicle_Validation.json').write_text(json.dumps(report,indent=2)+'\n')
    return report

if __name__=='__main__':
    # HTML embedding is the released source of both presentations.
    import re
    html=(R/'Race_Car_RevJ_Interactive/Race_Car_RevJ_Interactive.html').read_text(encoding='utf-8')
    data=json.loads(re.search(r'<script id="wiring-data" type="application/json">(.*?)</script>',html,re.S).group(1))
    print(json.dumps(validate(data),indent=2))
