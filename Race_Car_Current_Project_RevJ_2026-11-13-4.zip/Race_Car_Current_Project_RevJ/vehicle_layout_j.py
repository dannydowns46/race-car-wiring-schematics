"""Derived bird's-eye view: same physical records, loose positions, selectable looms."""
from pathlib import Path
from collections import defaultdict
import json,math,heapq,base64,hashlib,html
from physical_topology_j import R,D,load_and_audit
from ground_display_j import CHASSIS_NODES,is_chassis_edge,is_structure_reference
from wiring_work_j import work_info,route_label
from render_physical_j import category,COLORS

LAYOUT=D/'Vehicle_Layout.json'
OUT=R/'Race_Car_RevJ_Interactive'
STEP=80

def compress(points):
    out=[]
    for p in points:
        p=list(p)
        if out and p==out[-1]:continue
        if len(out)>1 and ((out[-2][0]==out[-1][0]==p[0]) or (out[-2][1]==out[-1][1]==p[1])):out[-1]=p
        else:out.append(p)
    return out

def segment_hits(a,b,box,pad=0):
    x,y,w,h=box;x-=pad;y-=pad;w+=pad*2;h+=pad*2
    if a[0]==b[0]:return x<a[0]<x+w and max(min(a[1],b[1]),y)<min(max(a[1],b[1]),y+h)
    if a[1]==b[1]:return y<a[1]<y+h and max(min(a[0],b[0]),x)<min(max(a[0],b[0]),x+w)
    return False

def road_overlap(points,road,band=170):
    length=0
    for a,b in zip(points,points[1:]):
        for c,d in zip(road,road[1:]):
            if a[1]==b[1] and c[1]==d[1] and abs(a[1]-c[1])<band:
                length+=max(0,min(max(a[0],b[0]),max(c[0],d[0]))-max(min(a[0],b[0]),min(c[0],d[0])))
            if a[0]==b[0] and c[0]==d[0] and abs(a[0]-c[0])<band:
                length+=max(0,min(max(a[1],b[1]),max(c[1],d[1]))-max(min(a[1],b[1]),min(c[1],d[1])))
    return length

def make_views(native,top):
    layout=json.loads(LAYOUT.read_text());pos=layout['positions'];W,H=layout['bounds'][2:]
    edges={e['id']:e for e in top['connections']};inc=defaultdict(list)
    for e in edges.values():
        inc[e['a']].append(e);inc[e['b']].append(e)
    placements={};ports={};endpositions=defaultdict(list);joins=[];pinrows={};bodies={}
    aliases={'J10':'R3 / connector A','J11':'R3 / connector C','J12':'R3 / power outputs','J1':'R3 / main power',
       'J40':'PD16 / connector A','J41':'PD16 / 25A outputs','U20':'PD16 / main power','J20':'Delta ABS / main plug',
       'J22':'Delta ABS / vehicle CAN','J30':'PD16 internal terminator','J31':'Public CAN2 terminator'}
    for part in native['parts']:
        ref=part['ref'];cx,cy=pos[ref];count=len(part['pins']);cols=2 if count>12 else 1
        w=760 if cols==2 else 400;h=110+math.ceil(count/cols)*26
        x,y=cx-w/2,cy-h/2;face=-1 if cy>=4500 else 1;py=y if face==-1 else y+h
        placements[ref]={'x':x,'y':y,'w':w,'h':h,'label':aliases.get(ref,part['value']),'technical':part.get('technical_label',''),
            'virtual':False,'kind':'component','page':part['page'],'hitBounds':[x,y,w,h]}
        bodies[ref]=[x,y,w,h];rows=[]
        for i,pin in enumerate(part['pins']):
            endpoint=ref+'/'+pin['num'];px=x+24+(i+.5)*(w-48)/count
            es=inc[endpoint]
            if es:
                points=[]
                for j,e in enumerate(es):
                    p=[round(px+(j-(len(es)-1)/2)*8,2),round(py,2)]
                    ports[(e['id'],endpoint)]=(p,[0,face]);endpositions[endpoint].append(p);points.append(p)
                if len(points)>1:
                    jy=py-face*14;segments=[[[min(p[0] for p in points),jy],[max(p[0] for p in points),jy]]]+[[p,[p[0],jy]] for p in points]
                    joins.append({'ref':ref,'net':pin['net'],'points':segments})
            rows.append({'endpoint':endpoint,'pin':pin['num'],'func':pin['func'],'net':pin['net'],'status':pin['status'],
                'port':[round(px,2),round(py,2)],'row':i//cols,'col':i%cols})
        pinrows[ref]=rows
    for node in top['nodes']:
        ref=node['id'];cx,cy=pos[ref]
        if ref in CHASSIS_NODES:continue
        placements[ref]={'x':cx-30,'y':cy-30,'w':270,'h':90,'label':node['label'],'technical':node['status'],
            'virtual':True,'kind':node['kind'],'page':None,'hitBounds':[cx-35,cy-35,70,70],'center':[cx,cy]}
        points=[];used=defaultdict(int)
        for i,e in enumerate(inc[ref]):
            for side in [(i+j)%4 for j in range(4)]:
                extra=used[side]*7;v=[[-1,0],[1,0],[0,-1],[0,1]][side]
                p=[cx+v[0]*26+(extra if v[0]==0 else 0),cy+v[1]*26+(extra if v[1]==0 else 0)]
                stub=[p[0]+v[0]*55,p[1]+v[1]*55]
                if not any(segment_hits(p,stub,b,4) for b in bodies.values()):break
            else:raise AssertionError(('Joint has no clear exit',ref))
            used[side]+=1
            ports[(e['id'],ref)]=(p,v);endpositions[ref].append(p)
            points.append([p,[cx,p[1]],[cx,cy]])
        joins.append({'ref':ref,'net':node['net'],'points':[compress(p) for p in points]})
    nx=int(W/STEP)+1;ny=int(H/STEP)+1;blocked=set();blocked_edges=set()
    obstacles=dict(bodies)
    for ref,p in placements.items():
        if p['virtual']:
            cx,cy=pos[ref];obstacles[ref]=[cx-19,cy-19,38,38]
    for box in obstacles.values():
        x,y,w,h=box
        for gx in range(max(0,math.floor((x-12)/STEP)),min(nx,math.ceil((x+w+12)/STEP)+1)):
            for gy in range(max(0,math.floor((y-12)/STEP)),min(ny,math.ceil((y+h+12)/STEP)+1)):
                if x-12<=gx*STEP<=x+w+12 and y-12<=gy*STEP<=y+h+12:blocked.add((gx,gy))
                for dx,dy in [(1,0),(0,1)]:
                    a=(gx,gy);b=(gx+dx,gy+dy)
                    if segment_hits([a[0]*STEP,a[1]*STEP],[b[0]*STEP,b[1]*STEP],box,4):
                        blocked_edges.add((a,b));blocked_edges.add((b,a))
    # Routing corridors attract paths without adding any electrical continuity.
    costs={}
    roadsegments=[(a,b) for r in layout['branches'] for a,b in zip(r['points'],r['points'][1:])]
    for gx in range(nx):
        for gy in range(ny):
            x,y=gx*STEP,gy*STEP
            dist=min(math.hypot(x-(a[0]+max(0,min(1,((x-a[0])*(b[0]-a[0])+(y-a[1])*(b[1]-a[1]))/((b[0]-a[0])**2+(b[1]-a[1])**2 or 1)))*(b[0]-a[0])),
                 y-(a[1]+max(0,min(1,((x-a[0])*(b[0]-a[0])+(y-a[1])*(b[1]-a[1]))/((b[0]-a[0])**2+(b[1]-a[1])**2 or 1)))*(b[1]-a[1]))) for a,b in roadsegments)
            costs[(gx,gy)]=1+min(.6,dist/1200)
    def portal(point,vec,owner):
        x,y=point;vx,vy=vec;stub=[x+vx*55,y+vy*55];best=None
        for radius in [1,2,3,4,7]:
            choices=[]
            for dx in range(-radius,radius+1):
                for dy in range(-radius,radius+1):
                    g=(round(stub[0]/STEP)+dx,round(stub[1]/STEP)+dy)
                    if g in blocked or not(0<g[0]<nx-1 and 0<g[1]<ny-1):continue
                    target=[g[0]*STEP,g[1]*STEP]
                    if vx==0 and (target[1]-y)*vy<30:continue
                    if vy==0 and (target[0]-x)*vx<30:continue
                    elbow=[target[0],stub[1]] if vx==0 else [stub[0],target[1]]
                    lead=compress([point,stub,elbow,target])
                    if any(segment_hits(a,b,box,3) for ref,box in obstacles.items() if ref!=owner for a,b in zip(lead,lead[1:])):continue
                    choices.append((sum(math.dist(a,b) for a,b in zip(lead,lead[1:])),g,lead))
            if choices:
                _,g,lead=min(choices);return g,lead
        raise AssertionError(('No clear portal',owner,point,vec))
    cache={}
    def route(a,b):
        if (a,b) in cache:return cache[(a,b)]
        heuristic=lambda p:abs(p[0]-b[0])+abs(p[1]-b[1])
        todo=[(heuristic(a),0,a)];dist={a:0};parent={}
        while todo:
            _,g,u=heapq.heappop(todo)
            if g!=dist.get(u):continue
            if u==b:break
            for dx,dy in [(1,0),(-1,0),(0,1),(0,-1)]:
                v=(u[0]+dx,u[1]+dy)
                if v in blocked or (u,v) in blocked_edges or not (0<=v[0]<nx and 0<=v[1]<ny):continue
                n=g+(costs[u]+costs[v])/2
                if n<dist.get(v,1e30):dist[v]=n;parent[v]=u;heapq.heappush(todo,(n+heuristic(v),n,v))
        assert b in dist,('No vehicle display route',a,b)
        p=[b]
        while p[-1]!=a:p.append(parent[p[-1]])
        result=compress([[x*STEP,y*STEP] for x,y in reversed(p)]);cache[(a,b)]=result;return result
    routes=[];groundsymbols=[]
    for e in top['connections']:
        refa=e['a'].split('/')[0];refb=e['b'].split('/')[0]
        entry={**{k:e[k] for k in ['id','a','b','net','net_id','kind']},'work':work_info(e),'assembly_id':e.get('assembly_id'),
            'color':COLORS['hold'] if e['kind']=='U' else COLORS[category(e['net'])]}
        if is_structure_reference(e):
            entry.update(points=[pos[refa],pos[refb]],paths=[],display='chassis-structure-reference')
        elif is_chassis_edge(e):
            paths=[];ends={}
            for end in ['a','b']:
                ep=e[end]
                if ep in CHASSIS_NODES:continue
                point,vec=ports[(e['id'],ep)];anchor=[point[0]+vec[0]*55,point[1]+vec[1]*55]
                remote=e['b'] if end=='a' else e['a'];gp=remote if remote in CHASSIS_NODES else 'CHASSIS'
                bars=[[[anchor[0]-half,anchor[1]+vec[1]*off],[anchor[0]+half,anchor[1]+vec[1]*off]] for half,off in [(14,0),(9,8),(4,16)]]
                groundsymbols.append({'id':e['id']+'-'+end,'connection':e['id'],'net':e['net'],'net_id':e['net_id'],
                    'endpoint':ep,'remote_endpoint':remote,'ground_point':gp,'point':anchor,'direction':vec[1],
                    'segments':bars,'label':e['net_id']+' / '+gp,'bounds':[anchor[0]-22,anchor[1]-95,44,190]})
                path=[point,anchor] if end=='a' else [anchor,point];paths.append(path);ends[end]=point
                if remote in CHASSIS_NODES:ends['b' if end=='a' else 'a']=anchor;endpositions[remote].append(anchor)
            entry.update(paths=paths,points=[ends['a']]+[p for path in paths for p in path]+[ends['b']],display='chassis-ground-stub')
        elif e['kind']=='I' and refa==refb and refa in ['TB1','TB2']:
            pa,_=ports[(e['id'],e['a'])];pb,_=ports[(e['id'],e['b'])];p=placements[refa];jy=p['y']+p['h']/2
            points=[pa,[pa[0],jy],[pb[0],jy],pb];entry.update(points=points,paths=[points],display='continuous')
        else:
            pa,va=ports[(e['id'],e['a'])];pb,vb=ports[(e['id'],e['b'])]
            a,la=portal(pa,va,refa);b,lb=portal(pb,vb,refb)
            # The owner explicitly prefers the tunnel for front/rear spans.
            # Keep local engine/bank/short front connections local instead of
            # attracting them into a longer loop simply because a corridor exists.
            xa,xb=pos[refa][0],pos[refb][0]
            if min(xa,xb)<8500<=max(xa,xb):
                qa=(round(max(2450,min(10900,xa))/STEP),round(4500/STEP))
                qb=(round(max(2450,min(10900,xb))/STEP),round(4500/STEP))
                middle=route(a,qa)+route(qa,qb)+route(qb,b)
            else:middle=route(a,b)
            points=compress(la+middle+list(reversed(lb)))
            entry.update(points=points,paths=[points],display='continuous')
        entry['branch_ids']=[road['id'] for road in layout['branches'] if e['kind'] in ['C','S','V'] and work_info(e)['code']!='U' and sum(road_overlap(p,road['points']) for p in entry['paths'])>180]
        routes.append(entry)
    # Freeze one set of display geometry, then omit other circuits in power scope.
    views={}
    for mode in ['full','power']:
        selected={n['name'] for n in native['nets']} if mode=='full' else set(top['power_net_names'])
        ee=[e for e in routes if e['net'] in selected]
        refs={e[k].split('/')[0] for e in ee for k in ['a','b']}
        if mode=='full':refs|={p['ref'] for p in native['parts']}
        places={k:p for k,p in placements.items() if k in refs}
        for ref in CHASSIS_NODES:
            if ref in refs:
                cx,cy=pos[ref];places[ref]={'x':cx-30,'y':cy-30,'w':60,'h':60,'label':ref,'technical':'Proposed chassis landing','virtual':True,'kind':'ground_point','page':None,'symbolOnly':True}
        ep={k:v for k,v in endpositions.items() if any(e['a']==k or e['b']==k for e in ee)}
        gg=[g for g in groundsymbols if g['net'] in selected]
        branches=[{**b,'connections':[e['id'] for e in ee if b['id'] in e['branch_ids']]} for b in layout['branches']]
        data={'bounds':layout['bounds'],'imageBox':layout['bounds'],'routes':ee,'joins':[j for j in joins if j['net'] in selected],
            'placements':places,'endpointPositions':ep,'groundSymbols':gg,'nets':sorted(selected),'branches':branches,
            'counts':{k:sum(e['kind']==k for e in ee) for k in ['C','S','V','I','B','U']},
            'pinRows':{ref:[r for r in rows if mode=='full' or r['net'] in selected] for ref,rows in pinrows.items() if ref in places},
            'layout':'vehicle','orientation':layout['orientation'],'status':layout['status']}
        svg=draw_svg(data,native,top,layout)
        (OUT/f'Vehicle_{mode}.svg').write_text(svg,encoding='utf-8')
        data['svg64']=base64.b64encode(svg.encode()).decode();views[mode]=data
    (OUT/'Vehicle_View_Data.json').write_text(json.dumps({mode:{k:v for k,v in view.items() if k!='svg64'} for mode,view in views.items()},indent=2)+'\n')
    return views

def draw_svg(view,native,top,layout):
    W,H=layout['bounds'][2:];parts={p['ref']:p for p in native['parts']};nodes={n['id']:n for n in top['nodes']};out=[]
    esc=lambda s:html.escape(str(s),quote=True)
    def add(s):out.append(s)
    def rect(x,y,w,h,fill,stroke='#d7e1eb',radius=18,extra=''):add(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{radius}" fill="{fill}" stroke="{stroke}" stroke-width="4" {extra}/>')
    def text(x,y,t,size=25,color='#18364b',weight=400,extra=''):add(f'<text x="{x}" y="{y}" font-size="{size}" font-weight="{weight}" fill="{color}" {extra}>{esc(t)}</text>')
    def line(points,color,width=5,extra=''):add(f'<polyline points="{" ".join(str(x)+","+str(y) for x,y in points)}" fill="none" stroke="{color}" stroke-width="{width}" stroke-linejoin="round" stroke-linecap="round" {extra}/>')
    add(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" font-family="sans-serif">')
    rect(0,0,W,H,'#f6f9fc','none',0)
    text(900,580,'RACE CAR / HARNESS PLAN',210,weight=650)
    text(900,900,'BIRD’S-EYE VIEW  ·  FRONT LEFT  ·  DRIVER SIDE BOTTOM',105,'#526b81',600)
    text(900,1130,'Loose component positions and proposed loom corridors — not to scale; no cut lengths.',68,'#657d91')
    # Neutral plan silhouette: a wiring orientation aid, not an exported body model.
    add('<path d="M1700 1900 Q800 2300 850 4400 L900 5900 Q1050 7900 2200 8100 L15700 8250 Q18100 8000 18100 5900 L18100 3600 Q17800 1700 15700 1650 Z" fill="#edf2f6" stroke="#aebfce" stroke-width="18"/>')
    for x in [2900,14300]:
        rect(x-450,1300,900,580,'#253a4a','#253a4a',80);rect(x-450,8000,900,580,'#253a4a','#253a4a',80)
    rect(4650,2150,6400,5550,'#e3ebf1','#c4d3de',230)
    line([[11100,2250],[11100,7700]],'#aebdca',22,'stroke-dasharray="50 35"')
    rect(11250,2700,3100,4600,'#e8eff0','#b5c5ca',160)
    rect(14600,3550,1400,2600,'#e4ecee','#b5c5ca',140)
    rect(10900,1700,1600,950,'#f4efde','#d8cda8',90);rect(10650,7720,1850,950,'#f4efde','#d8cda8',90)
    # Seat footprints stay faint behind component/interface cards.
    for y in [2750,6000]:
        rect(7200,y,1400,1200,'#d3dfe8','#bfceda',230);rect(8100,y+100,380,1000,'#becfdd','#bfceda',120)
    rect(1100,3400,1000,2500,'#d6e5eb','#adc5d1',55)
    for x in range(1180,2050,90):line([[x,3480],[x,5810]],'#bdd2db',12)
    text(1250,3270,'RADIATOR',96,'#607c8e',650)
    text(7050,2500,'PASSENGER',108,'#8195a5',600)
    text(7100,7590,'DRIVER',125,'#718a9d',650)
    text(12800,5750,'ENGINE',135,'#819a9c',650)
    text(14800,3500,'TRANSAXLE',90,'#819a9c',650)
    text(10850,1550,'PASSENGER TANK',90,'#9b8d63',650)
    text(10400,8990,'DRIVER TANK + SURGE',90,'#9b8d63',650)
    for road in layout['branches']:
        line(road['points'],'#b6cbd5' if road['id']=='T01' else '#d0dfe5',220 if road['id']=='T01' else 145,f'data-bundle="{road["id"]}"')
        line(road['points'],'#edf4f7',180 if road['id']=='T01' else 112)
    # Branch names have their own clear spaces; these bands do not join nets.
    for road in layout['branches']:
        x,y=road['label_position'];size=92 if road['id']=='T01' else 57
        text(x,y,road['id']+' / '+road['label'],size,'#42667a',650,extra='text-anchor="middle"')
    text(800,4700,'FRONT',100,'#33566d',650,extra='transform="rotate(-90 800 4700)" text-anchor="middle"')
    text(18400,4700,'REAR',100,'#33566d',650,extra='transform="rotate(90 18400 4700)" text-anchor="middle"')
    rect(2450,9020,1900,620,'#fffaf0','#d5c395',30)
    text(2500,9150,'LOCATION NOT CONFIRMED',70,'#876d35',650)
    text(2500,9700,'Delta pressure-sensor locations shown here are placeholders.',35,'#876d35')
    for ref,p in view['placements'].items():
        if p.get('symbolOnly'):continue
        x,y,w,h=p['x'],p['y'],p['w'],p['h']
        if not p['virtual']:
            rect(x,y,w,h,'#ffffff','#9eb3c3',12,extra=f'data-component="{ref}"')
            rect(x,y,w,82,'#e9f0f6' if ref not in ['J10','J11','J12','J40','J41','U20'] else '#d5e8ef','#9eb3c3',12)
            text(x+14,y+27,ref,22,'#41667c',650)
            label=p['label'];words=label.split();lines=['']
            for word in words:
                if len(lines[-1])+len(word)>int((w-30)/13):lines.append('')
                lines[-1]+=(' ' if lines[-1] else '')+word
            for i,t in enumerate(lines[:2]):text(x+14,y+51+i*23,t,22,weight=650)
            rows=view['pinRows'][ref];cols=2 if len(parts[ref]['pins'])>12 else 1
            for row in rows:
                xx=x+16+row['col']*w/cols;yy=y+103+row['row']*26
                label=row['pin']+'  '+('NC' if row['net'] is None else row['func'].replace('_',' '))
                text(xx,yy,label[:46 if cols==2 else 42],13,'#61788a' if row['net'] is None else '#27485f')
                px,py=row['port'];line([[px,py],[px,py+(-12 if py==y else 12)]],'#45657a',4)
                if row['net'] is None:
                    line([[px-5,py-5],[px+5,py+5]],'#677f91',3);line([[px-5,py+5],[px+5,py-5]],'#677f91',3)
            if ref in ['TB1','TB2']:
                jy=y+h/2;ports=[r['port'] for r in rows]
                line([[min(v[0] for v in ports),jy],[max(v[0] for v in ports),jy]],'#7c6250',9)
        else:
            cx,cy=p['center'];kind=p['kind'];fill='#fff3dc' if kind in ['splice','can_splice'] else '#edf1f5'
            if kind in ['supplier_junction','integration_boundary']:
                add(f'<path d="M{cx-19},{cy} L{cx},{cy-19} L{cx+19},{cy} L{cx},{cy+19} Z" fill="{fill}" stroke="#8d7d66" stroke-width="5" data-component="{ref}"/>')
            else:add(f'<circle cx="{cx}" cy="{cy}" r="17" fill="{fill}" stroke="#805c25" stroke-width="5" data-component="{ref}"/>')
            text(cx+31,cy+9,ref,23,'#72542e',650)
    for j in view['joins']:
        for points in j['points']:line(points,'#5a6873',4,'data-join="'+esc(j['ref'])+'"')
    for g in view['groundSymbols']:
        for points in g['segments']:line(points,'#526a7c',4,'data-ground="'+esc(g['id'])+'"')
        x,y=g['point'];dy=g['direction'];angle=-90 if dy<0 else 90
        text(x+5,y+dy*28,g['label'],11,'#486276',600,extra=f'transform="rotate({angle} {x+5} {y+dy*28})"')
    # Keep missing location evidence separate from established positions.
    text(900,9890,'BANDS = PHYSICAL LOOM GROUPS · ONLY EXPLICIT SPLICES JOIN WIRES · ALL LENGTHS / MOUNTS REMAIN PROPOSED',57,'#61788b',600)
    add('</svg>');return '\n'.join(out)

if __name__=='__main__':
    native,top=load_and_audit();views=make_views(native,top)
    print(json.dumps({'result':'PASS','views':{m:len(v['routes']) for m,v in views.items()}},indent=2))
