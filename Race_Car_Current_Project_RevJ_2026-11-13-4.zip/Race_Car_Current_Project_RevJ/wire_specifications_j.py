"""Read maintained gauge proposals without overwriting installed/material evidence."""
from pathlib import Path
from functools import lru_cache
import json

SPECIFICATIONS = Path(__file__).resolve().parent / 'Race_Car_RevJ/Wire_Specifications.json'

@lru_cache(maxsize=1)
def specifications():
    return json.loads(SPECIFICATIONS.read_text(encoding='utf-8'))

def wire_spec(edge):
    proposal = dict(specifications()['connections'][edge['id']])
    # Existing entered material data always wins. A planning recommendation is
    # deliberately a separate field and is never written into gauge_AWG.
    if edge.get('gauge_AWG') is not None:
        proposal.update(awg=edge['gauge_AWG'], status='ENTERED', label=f"{edge['gauge_AWG']} AWG (entered)",
                        note='Entered physical-topology material field; verify its associated evidence/release status.')
    return proposal

def gauge_tag(edge):
    spec = wire_spec(edge)
    return str(spec['awg'])+'AWG*' if spec.get('awg') is not None else spec['tag']

def audit(topology):
    records = specifications()['connections']
    assert set(records) == {e['id'] for e in topology['connections']}, 'Gauge proposals must cover every path'
    for e in topology['connections']:
        s = wire_spec(e)
        assert s['note'] and s['label'] and s['status']
        if e['kind'] in ['I','B','U','V']:
            assert s['awg'] is None, (e['id'], 'Not an individual fabricated conductor')
        if e.get('assembly_id','').startswith('A-OEM'):
            assert s['awg'] is None or e.get('gauge_AWG') is not None, 'Do not invent stock-loom wire gauges'
        if s['awg'] is not None:
            assert s['awg'] in [0,1,2,4,6,8,10,12,14,16,18,20,22,24]
    return {'result':'PASS','numeric_gauge_annotations':sum(wire_spec(e)['awg'] is not None for e in topology['connections']),
            'installed_wire_sizes_verified':False,'native_electrical_change':False}
