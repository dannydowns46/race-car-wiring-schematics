# Portable current-revision build

Reading the supplied files needs no build. To regenerate them, install Python3.10+, Node18+ and KiCad7 or later. The handoff was exported with KiCad7.0.10; run the validators after using a newer version. These are baseline requirements, not a claim that every future version has been tested.

From the extracted project folder:

```powershell
python -m pip install -r requirements-current.txt
python rebuild_current.py --kicad-cli "C:/Program Files/KiCad/7.0/bin/kicad-cli.exe"
```

Use your actual KiCad install path. `--node` accepts a Node executable path if Node is not on PATH. Omit `--kicad-cli` if it is on PATH; the script also searches standard Windows KiCad installs. The Python interpreter running the script is used for all Python stages. Do not put the original user's desktop/runtime paths into the shop-computer setup.

Validate the included outputs without installing Node or KiCad:

```powershell
python rebuild_current.py --check-only
```

This still requires the listed Python packages. Validation writes fresh reports and preview images; it does not modify connectivity. It checks the supplied XML, not a new KiCad export. The full build makes fresh native exports first.

The full build runs build-racecar-revj.js, fresh KiCad XML/PDF exports, finish-revj.py, validate-revj.py, build_single_page_j.py and validate_single_page_j.py. It records CURRENT_BUILD_LOG.json. It needs no network, private chat, clipboard image, original computer or legacy absolute paths. Keep Race_Car_RevI/Design_Data.json and Race_Car_Readable/Readable_Names.json because the J builder uses them to preserve net IDs and names.

Edit build-racecar-revj.js for native design changes, and coordinate documentation, schedules and validator expectations when assignments change. finish-revj.py preserves the maintained J README, control specification and measurement worksheets. Normal rebuild does not run create_revision_i.py, Revision_I_Work migration scripts, build_handoff_docs.py or historical revision scripts; those may overwrite later work and are retained only as records.

Native schematic edits made only in the KiCad UI would be overwritten by the Node builder; carry those changes back into its source before rebuilding. Generated UUIDs may change, so compare connectivity and meaningful design values rather than expecting byte-identical regenerated PDFs/native files.

After meaningful drawing edits, visually inspect the full affected PDF pages and continuous component details in addition to running the validators. The geometry check verifies electrical equivalence, not physical packaging, harness construction, real sensor applicability or installed control logic.

J source needs retained I Design_Data.json for ID continuity. Do not run create_revision_i.py as a normal rebuild. finish-revj.py refreshes derived metadata/schedules only and preserves current README, measured-data worksheets and control specifications.

`Revision_J_Work/` scripts are one-time migration records, not a normal build step. Keep I as the fixed regression baseline. J rebuild must never regenerate that baseline.
