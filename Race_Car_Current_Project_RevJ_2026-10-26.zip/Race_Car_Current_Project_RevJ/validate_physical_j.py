"""Recover rendered physical conductors, explicit joints and exact native net endpoints."""
from pathlib import Path
from collections import defaultdict,Counter
import json,hashlib,xml.etree.ElementTree as ET,re
import pymupdf as fitz
from physical_topology_j import R,D,load_and_audit
from ground_display_j import CHASSIS_NETS,CHASSIS_NODES,is_chassis_edge,is_structure_reference,glyph_segments
from wiring_work_j import WORK_CLASSES,route_label,work_info

def validate(mode='full'):
 data,top=load_and_audit();full=mode=='full'
 out=R/('Race_Car_RevJ_Single_Page' if full else 'Race_Car_RevJ_Power_Only')
 m=json.loads((out/'Drawing_Manifest.json').read_text());assert m['schema']=='physical-conductors-v1' and m['mode']==mode
 pdf=fitz.open(out/m['pdf']);assert len(pdf)==1;page=pdf[0]
 assert tuple(round(v,2) for v in page.rect[2:])==tuple(round(v,2) for v in m['page_size_points'])
 selected=set(m['selected_net_names']);expected={n['id']+'_'+n['name']:{e['ref']+'/'+e['pin'] for e in n['endpoints']} for n in data['nets'] if n['name'] in selected}
 native={p['ref']+'/'+x['num']:x for p in data['parts'] for x in p['pins']}
 actual={n.attrib['name']:{e.attrib['ref']+'/'+e.attrib['pin'] for e in n.findall('node')} for n in ET.parse(D/'preview/netlist.xml').getroot().findall('nets/net')}
 for key,endpoints in expected.items():assert actual[key]==endpoints,key
 for path,digest in m['source_hashes'].items():assert hashlib.sha256((R/path).read_bytes()).hexdigest()==digest,path
 assert hashlib.sha256((D/'preview/netlist.xml').read_bytes()).digest()==hashlib.sha256((out/'Source_Netlist.xml').read_bytes()).digest()
 assert hashlib.sha256((D/'Race_Car_RevJ.pdf').read_bytes()).digest()==hashlib.sha256((out/'Race_Car_RevJ_Flagged.pdf').read_bytes()).digest()
 def pt(a):return tuple(round(float(v),2) for v in a)
 def seg(a,b):return tuple(sorted([pt(a),pt(b)]))
 # Conductor and joint widths are reserved by the renderer, independent from
 # component borders, underlays, text boxes, assembly glyphs and the legend.
 drawn=defaultdict(list);dots=set()
 for d in page.get_drawings():
  if d['type'] in ['s','fs']:
   for item in d['items']:
    if item[0]=='l':drawn[seg(item[1],item[2])].append(d)
  if d['type']=='fs':
   b=d['rect']
   if abs(b.width-3.6)<.02 and abs(b.height-3.6)<.02:dots.add(pt(((b.x0+b.x1)/2,(b.y0+b.y1)/2)))
 def verify_segment(s):
  matches=[d for d in drawn[seg(s['start'],s['end'])] if abs(d['width']-s['width'])<.01]
  rgb=tuple(int(s['color'][i:i+2],16)/255 for i in [1,3,5])
  matches=[d for d in matches if max(abs(a-b) for a,b in zip(rgb,d['color']))<.002]
  assert matches,('Missing PDF path',s)
  if s['dash']:assert any('[' in d['dashes'] and d['dashes']!='[] 0' for d in matches)
 for s in m['conductor_segments']+m['inside_joint_segments']+m['ground_symbol_segments']:verify_segment(s)
 assert {pt(p) for p in m['joint_dots']}==dots
 # Independently collect all actual matching-width conductor segments in the
 # route area. This rejects extra field paths or omitted/merged routes.
 first_y=min(p['y']+244 for p in m['placements'].values() if p['side']=='top')
 last_y=max(p['y'] for p in m['placements'].values() if p['side']=='bottom')
 widths={1.1,2.1,.85,1.4,.95}
 physical_segments=set()
 for key,dd in drawn.items():
  if all(first_y-.1<=p[1]<=last_y+.1 for p in key) and any(any(abs(d['width']-w)<.01 for w in widths) for d in dd):physical_segments.add(key)
 assert physical_segments=={seg(s['start'],s['end']) for s in m['conductor_segments']},'Unexpected or missing routed line'
 parent={}
 def find(p):
  parent.setdefault(p,p)
  if parent[p]!=p:parent[p]=find(parent[p])
  return parent[p]
 def union(a,b):parent[find(a)]=find(b)
 # Only endpoints and actual drawn joint dots connect paths. White-gap
 # crossings are never joined merely because their coordinates intersect.
 for key in physical_segments|{seg(s['start'],s['end']) for s in m['inside_joint_segments']}:
  a,b=key;splits=[a,b]
  for p in dots:
   if a[0]==b[0] and abs(p[0]-a[0])<.01 and min(a[1],b[1])<=p[1]<=max(a[1],b[1]):splits.append(p)
   if a[1]==b[1] and abs(p[1]-a[1])<.01 and min(a[0],b[0])<=p[0]<=max(a[0],b[0]):splits.append(p)
  for p in splits:union(a,p)
 # Ground references are electrical notation, not drawn spanning wires. Verify
 # each actual glyph/label and native stub before joining matching W IDs only.
 topo_edges={e['id']:e for e in top['connections'] if e['net'] in selected}
 text=re.sub(r'\s+',' ',page.get_text())
 assert m['work_classes']==WORK_CLASSES
 symbols=m['ground_symbols'];symbol_nets=defaultdict(list)
 expected_symbols={(e['id'],endpoint) for e in topo_edges.values() if is_chassis_edge(e)
                   for endpoint in [e['a'],e['b']] if endpoint not in CHASSIS_NODES}
 assert {(g['connection'],g['endpoint']) for g in symbols}==expected_symbols
 for g in symbols:
  orig=topo_edges[g['connection']]
  assert g['net'] in CHASSIS_NETS and g['net_id']==CHASSIS_NETS[g['net']]
  assert g['net']==orig['net'] and g['endpoint'] in [orig['a'],orig['b']]
  other=orig['b'] if g['endpoint']==orig['a'] else orig['a']
  assert g['remote_endpoint']==other and g['ground_point']==(other if other in CHASSIS_NODES else 'CHASSIS')
  p=m['placements'][g['endpoint'].split('/')[0]]
  slot=next(s for s in p['slots'] if s['connection']==g['connection'] and s['endpoint']==g['endpoint'])
  direction=1 if p['side']=='top' else -1
  assert g['direction']==direction and g['point']==[slot['x'],slot['y']+direction*108]
  assert g['segments']==glyph_segments(g['point'],direction)
  assert g['label']==g['net_id']+' / '+g['ground_point'] and g['label'] in text
  assert seg([slot['x'],slot['y']],g['point']) in physical_segments
  for a,b in g['segments']:verify_segment({'start':a,'end':b,'width':.9,'color':'#49515B','dash':[]})
  symbol_nets[g['net']].append(pt(g['point']))
 assert len(m['ground_symbol_segments'])==3*len(symbols)
 actual_glyphs={key for key,dd in drawn.items() if all(first_y-.1<=p[1]<=last_y+.1 for p in key)
                and any(abs(d['width']-.9)<.01 for d in dd)}
 assert actual_glyphs=={seg(s['start'],s['end']) for s in m['ground_symbol_segments']}
 for points in symbol_nets.values():
  for point in points:union(points[0],point)
 assert m['chassis_structure_references']==[dict(e,work=work_info(e)) for e in topo_edges.values() if is_structure_reference(e)]
 recovered=defaultdict(set);nativepoints=defaultdict(list);routeports={}
 for ref,p in m['placements'].items():
  for slot in p['slots']:
   routeports[slot['port']]=slot
   if not p['virtual'] and slot['net'] is not None:
    point=pt([slot['x'],slot['y']]);recovered[find(point)].add(slot['endpoint']);nativepoints[slot['endpoint']].append(point)
    assert native[slot['endpoint']]['func']==slot['func'] and native[slot['endpoint']]['status']==slot['status']
 for endpoint,points in nativepoints.items():assert len({find(p) for p in points})==1,('Same stud split',endpoint)
 assert {frozenset(v) for v in recovered.values()}=={frozenset(v) for v in expected.values()},'Rendered net component mismatch'
 assert len(recovered)==len(expected)
 route_ids={e['id'] for e in m['routes']};inside_ids={e['id'] for e in m['internal_block_links']}
 assert route_ids|inside_ids==set(topo_edges) and not route_ids&inside_ids
 for e in m['routes']:
  orig=topo_edges[e['id']]
  assert all(e[k]==orig[k] for k in ['id','a','b','net','net_id','kind','pair_group'])
  for end,point in [('a',e['points'][0]),('b',e['points'][-1])]:
   if e['port_'+end] is not None:
    s=routeports[e['port_'+end]]
    assert s['endpoint']==e[end] and pt(point)==pt([s['x'],s['y']])
   else:
    assert e[end] in CHASSIS_NODES and any(g['ground_point']==e[end] and pt(g['point'])==pt(point) for g in symbols)
  assert find(pt(e['points'][0]))==find(pt(e['points'][-1]))
  if is_structure_reference(e):assert e['paths']==[] and e['display']=='chassis-structure-reference'
  elif is_chassis_edge(e):assert e['display']=='chassis-ground-stub' and len(e['paths'])==sum(e[end] not in CHASSIS_NODES for end in ['a','b'])
  else:assert e['display']=='continuous' and e['paths']==[e['points']]
  for path in e['paths']:
   for a,b in zip(path,path[1:]):assert seg(a,b) in physical_segments
  if e.get('length_mm') is not None:assert isinstance(e['length_mm'],(int,float)) and e['length_mm']>0
 for panel in m['annotations']:
  for note in panel['body']:assert re.sub(r'\s+',' ',note) in text,('Missing visible note',note)
 for e in m['routes']:assert e['id'] in text and e['net_id'] in text,('Missing wire ID',e['id'])
 for e in m['routes']:
  assert e['work']==work_info(e),('Wrong construction class',e['id'])
  if e['paths']:assert route_label(e) in text,('Missing build-action label',e['id'])
  if e['kind']=='S':
   assert all(s['dash']==[4,2] for s in m['conductor_segments'] if s['color']==e['color'] and any(seg(s['start'],s['end'])==seg(a,b) for path in e['paths'] for a,b in zip(path,path[1:])))
 assert 'NOT A FABRICATION RELEASE' in text
 assert len(m['native_parts'])==(95 if full else 70)
 nc=[s for p in m['placements'].values() if not p['virtual'] for s in p['slots'] if s['net'] is None]
 assert len(nc)==(60 if full else 0)
 # Boundary holds are not assigned field wires and do not become invented NCs.
 for opened in [o for o in top['open_ends'] if o['net'] in selected]:assert not any(opened['endpoint'] in [e['a'],e['b']] for e in topo_edges.values())
 links=[v for v in page.get_links() if v.get('file')=='Race_Car_RevJ_Flagged.pdf'];assert all(0<=v['page']<19 for v in links)
 report={'result':'PASS','schema':'physical-conductors-v1','mode':mode,'date':'2026-10-25','native_electrical_change':False,'pages':1,
  'native_components_shown':len(m['native_parts']),'native_nets':len(expected),'native_connected_endpoints':sum(len(v) for v in expected.values()),
  'native_NC_shown':len(nc),'counts_by_kind':m['counts_by_kind'],'rendered_individual_connection_paths':len(m['routes']),
  'verified_conductor_segments':len(m['conductor_segments']),'verified_internal_joint_segments':len(m['inside_joint_segments']),'recovered_native_net_components':len(recovered),
  'verified_chassis_ground_symbols':len(symbols),'symbolic_chassis_structure_records':len(m['chassis_structure_references']),
  'checks':['Every maintained conductor has two explicit endpoints; exact model/native net endpoints preserved.',
   'Actual PDF conductor segments, internal joint bars and dots recovered independently; no accidental crossing joins.',
   'Actual short chassis stubs, three-bar ground glyphs and W/GP labels verified; only matching labelled chassis nets joined symbolically. Sensor/CAN, engine and isolated battery returns remain explicit.',
   'TB1 has four external field wires and TB2 six; their common metal is not counted as wire.',
   'Shared starter B+ stud has exactly the F2 trunk and F3 branch wires.',
   'CAN trunk/tap H/L pairing, existing PD16 termination, ground/reference separation and GT negative-only battery connection checked.',
   'Supplier loom, vendor cable bundles, metal bonds and unresolved/internal paths remain distinct from new field wires.',
   'Native cavities/functions/status and all source notes retained for shown scope.'],
  'limits':top['holds']}
 (out/'Match_Validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
 preview=out/'preview';preview.mkdir(exist_ok=True)
 page.get_pixmap(matrix=fitz.Matrix(2500/page.rect.width,2500/page.rect.width),alpha=False).save(preview/'physical_overview.png')
 for ref in ['BT1','M1','TB1','TB2','U2','U3','D60','S40','J40','B32','B33','X111','X113','SP035','SP061','SP062','SP070','OEM111-PWR','OEM-INJ-ODD','CUT-INJ1','GP129-C','GP009','CAN1-1H','CAN1-1L','SP136','U24']:
  if ref not in m['placements']:continue
  p=m['placements'][ref];clip=fitz.Rect(p['x']-20,p['y']-(240 if p['side']=='bottom' else 45),p['x']+p['width']+22,p['y']+244+(240 if p['side']=='top' else 45))
  page.get_pixmap(matrix=fitz.Matrix(2,2),clip=clip,alpha=False).save(preview/('physical_'+ref+'.png'))
 return report

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--mode',choices=['full','power'],default='full');validate(p.parse_args().mode)
