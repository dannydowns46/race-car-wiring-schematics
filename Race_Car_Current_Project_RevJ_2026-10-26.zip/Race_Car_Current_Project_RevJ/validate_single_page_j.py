from validate_physical_j import validate
if __name__ == "__main__": validate("full")
