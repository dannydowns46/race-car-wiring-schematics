"""Refresh J schedules and continuous source export; preserve maintained documents."""
from pathlib import Path
import shutil,json,csv
r=Path(__file__).resolve().parent;d=r/'Race_Car_RevJ'
data=json.loads((d/'Design_Data.json').read_text());parts={p['ref']:p for p in data['parts']}
assert (len(parts),len(data['nets']))==(95,115)
pro=json.loads((r/'Race_Car_RevI/Race_Car_RevI.kicad_pro').read_text());pro['meta']['filename']='Race_Car_RevJ.kicad_pro'
(d/'Race_Car_RevJ.kicad_pro').write_text(json.dumps(pro,indent=2))
with (r/'Race_Car_RevI/IO_Audit.tsv').open(newline='',encoding='utf-8-sig') as f:rows=list(csv.DictReader(f,delimiter='\t'))
for row in rows:
    p=next(v for v in parts[row['Interface']]['pins'] if v['num']==row['Cavity'])
    row.update({'Channel / function':p['func'],'Net':p['net'] or 'SPARE','Allocation':'ASSIGNED' if p['net'] else 'UNASSIGNED'})
with (d/'IO_Audit.tsv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');w.writeheader();w.writerows(rows)
out=r/'Race_Car_RevJ_Single_Page';out.mkdir(exist_ok=True);shutil.copy2(d/'preview/netlist.xml',out/'Source_Netlist.xml')
(out/'READ_ME.txt').write_text('CURRENT REVISION J / PHYSICAL CONDUCTOR VIEW 01 / 25 OCT 2026. Open Race_Car_RevJ_Continuous_Wiring.pdf with its adjacent native PDF. Current continuous views show individual proposed field conductors and explicit joints; see Physical_Topology.json / Physical_Connections.tsv. Native electrical assignments are unchanged. Wire sizes, lengths, colors, terminal/splice hardware, all release holds and powered checkout remain unresolved.\n')
baseline=json.loads((r/'Race_Car_RevI/Design_Data.json').read_text());old={n['id'] for n in baseline['nets']}
record={'baseline':'I','current':'J','updated':'2026-10-25','renamed_retaining_ids':{},'retired_in_J':[{'id':'W004','name':'CUT_EXT_LOOP','reason':'X-Pro external-to-chassis circuit removed; GT uses isolated blue/blue W136 loop'}], 'inherited_retired_ids':['W006','W007','W024','W031','W078','W079'], 'new_nets':[{'id':n['id'],'name':n['name']} for n in data['nets'] if n['id'] not in old], 'baseline_record':'../Race_Car_RevI/Net_Revision_Record.json', 'retained_net_endpoint_changes':[{'date':'2026-10-24','ref':'F3','pin':'1','from':'W001 BATT_RAW','to':'W011 STARTER_FEED','reason':'Owner selects alternator branch at starter battery B+ stud; no separate alternator cable back to battery-side block.'}]}
(d/'Net_Revision_Record.json').write_text(json.dumps(record,indent=2))
record['GT_terminal_transition']={'M4':'M6_BAT','1':'BLACK','3':'M6_IGN','4':'RED','2':'retired; new BLUE_A/BLUE_B on W136'}
record['stock_harness_interfaces']={'date':'2026-10-25','added_parts':['X111','X113'],'net_ids_changed':False,'existing_device_pin_assignments_changed':False,'reason':'Model retained OEM coil-bank connectors; supplied-loom and donor injector cut-boundary topology detailed separately.'}
(d/'Net_Revision_Record.json').write_text(json.dumps(record,indent=2))
print('J metadata, I/O audit, net-ID record and continuous export refreshed.')

record['renamed_retaining_ids']['W003']={'from':'MAIN_ISOLATED','to':'MAIN_FUSED_BUS','reason':'Owner removes K1; F0 directly feeds TB2'}
record['retired_in_J'].append({'id':'W128','name':'FUSED_MAIN_BUS','reason':'K1 removed; F0 output joins retained W003 distribution bus'})
record['K1_removal']={'date':'2026-10-25','removed_part':'K1','retired_connections':['C063','C064','C178','C179'],'rewired':{'C006':'F0/2 -> TB2/IN','C065':'U2/M6_IGN -> S1/1'},'positive_master_cutoff':False,'GT_engine_stop':'S1 -> R3 A13; verify shutdown before GT isolation'}
record['starter_relay']={'date':'2026-10-25','selected':'U3 Cole Hersee 24059','added_part':'D60 Vishay 1N5408-E3/54 coil suppression','added_connections':['C213','C214'],'retained_U3_connections':['C025','C026','C027','C180'],'net_ids_changed':False,'new_IO_allocations':False,'detail':'Starter_Relay.json'}
record['retired_in_J'].append({'id':'W046','name':'START_PERMIT','reason':'Owner removes S2 clutch/neutral switch; R3 C5/SPI1 spare and unconnected'})
record['S2_removal']={'date':'2026-10-25','removed_part':'S2','retired_connections':['C076','C123'],'spare_input':'J11/5 R3 C5/SPI1','jumper':False,'replacement_neutral_switch':False}
(d/'Net_Revision_Record.json').write_text(json.dumps(record,indent=2))
