# Race car wiring - design basis

> **LATEST: U3 is Cole Hersee 24059 with local D60 coil suppression. S2 clutch/neutral switch is removed; R3 C5/SPI1 is spare/unconnected, no jumper. C076/C123 and W046 are retired.** See the U3 and S2 sections below; actual NSP and powered tests remain open.

> **CURRENT OWNER UPDATE - 25 October: K1 REMOVED.** CARTEK GT alone provides engine-stop control and battery-negative isolation. GT M6_IGN -> S1 -> R3 A13; F0/2 now feeds TB2/IN directly on W003 **MAIN_FUSED_BUS** (same W003 ID). W128 and C063/C064/C178/C179 are retired; do not reuse them. Positive feeders remain connected when the battery is attached. All physical fuses remain drawn, and the owner explicitly retains **Delta supplied fuses**. Prove engine/fuel/PD16 output shutdown and GT timing before use. Prior passages describing retained K1 or a switched TB2 are superseded by this amendment; historical snapshots are in Change_Records.

Current totals: 19 native sheets, 95 components, 414 pins, 354 connected endpoints, 60 NC, 115 nets. Full physical view 284 connections; power 145/43 nets. Construction tags are independent of stable IDs: **MAKE** additional branch/integration, **LEAD** supplied controller/kit wire needing end work, **LOOM** existing wiring, **CABLE** intact cable, **HOLD** unresolved supplier path. The 176 C IDs are not a count of wires to buy:81 paths use supplied leads; C158 is supplier-routing HOLD. See Harness_Construction.json and the four TSV work lists. Actual grouped branch leads, reach and mating/extension hardware remain to inspect.

Owner uses complete Delta harnesses and R3/PD16 flying-lead harnesses (catalog HT-183200/HT-188000 references). Delta sensor/control/IMU wiring and fused feed assembly stay intact. No fabricated pressure return or private CAN tap. Current Delta OFF-switch wording conflicts with the older pin35 model; C158 is explicitly **not a wire to fabricate**. IMU cavities/public-private HCU pairing remain supplier holds. U3 is selected as Cole Hersee 24059 with external D60 suppression; actual current, F5 coordination and powered release tests remain OPEN. See the current U3 selection section below.

> **25 October update - GT integrated in current drawings:** CARTEK GT replaces X-Pro; one BAOMAIN B00NTT91Y0 internal latching NC stop, no separate external switch, GT blue/blue loop joined. K1 physical positive cutoff retained. TB1 Sierra FS46540 and TB2 Summit SUM-900533 added as PROPOSED parts. Received GT-s/GT-x, actual switch contacts, block ratings/stacking, F4 coordination and powered shutdown still require verification. F2/F3 remain drawn; no removal instructed. See `Race_Car_RevJ/Distribution_Blocks.json` and P06/P07.

## 24 October 2026 - shared starter and alternator cable

Owner selects one heavy cable from the positive block next to the battery to the starter, with a separate alternator cable attached to the same starter **battery-side B+ stud**. The maintained drawing includes F2 near the battery block and F3 near the starter branch. F3/1 moves from W001/BATT_RAW to W011/STARTER_FEED; W008/ALT_BPLUS remains F3/2 to G1/B+. All W identifiers are retained. Neither the small solenoid trigger nor the motor-side stud is this junction.

The raw positive block now has four electrical connections: battery positive, F0 main distribution, F2 shared starter/charging trunk and F4 CARTEK control. The switched block still has six: F0/2 incoming (K1 removed), F1 R3, F50 PD16, F41/F42 ABS and F5 starter driver. TB1 Sierra FS46540 and TB2 Summit SUM-900533 are now proposed parts; these connection counts do not establish actual stud allocation or permitted lug stacking.

See `Race_Car_RevJ/Starter_Alternator_Routing.json` for the physical routing intent, current paths, source and unresolved checks. F2 must accommodate cranking and charging; F3 protects the alternator branch from battery-fed faults, with alternator-fed faults assessed separately. Actual cable gauges, fuse types/ratings, starter stud/stack/torque/cover limits, voltage drop and cutoff tests remain release holds. CARTEK/K1, all downstream main supplies and negative returns are unchanged. This update does not restore any removed injector/coil/lift fuse.

The earlier 24 October power-analysis report and ZIP remain historical snapshots. Load totals are unchanged by this routing choice; their former separate alternator-to-battery route discussion is superseded. Recalculate cable losses from the installed shared path and measure hot charging voltage/current. Change records and the pre-change model are under `Change_Records/2026-10-24_Starter_Alternator/`. Existing package manifests describe their original packages, not this later workspace update.


## Current revision - J, updated 25 October 2026

## Revision J - wideband and transmission temperature

- Owner selects exactly ONE wideband O2 sensor, directly controlled by the R3 onboard WBI1. B9 and its six WBO nets are retained: C29 HTR+, C30 INPUT, C31 PUMP, C32 NERNST, C33 HTR-, C34 CAL. Revision I already modeled a single sensor, so no second sensor/controller circuit existed to delete. No WB1/WB2, extra CAN branch, AVI or external heater feed is added.
- Exact wideband sensor/adapter is not selected. R3 supports Bosch LSU4.9 or NTK; use the matching hardware/adapter and NSP sensor selection. B9 terminals are functional labels, not confirmed sensor connector cavities. Confirm exhaust location and the tuner's single-sensor strategy; do not treat one measured exhaust stream as independent two-bank feedback. Keep supplied sensor calibration components/connector intact.
- B32 remains the engine-oil HT-010306 high-range 150C sensor: EV1 B signal -> PD16 A20/AVI1; A return -> PD16 A11.
- Added B33, a second HT-010306 high-range 150C sensor for transmission oil: EV1 B signal -> PD16 A21/AVI2, new W135/TRANS_TEMP_SIG; EV1 A -> existing W124/PD16_SG and PD16 A11.
- Configure independent Engine Oil Temperature and Transmission Oil Temperature channels. Each AVI uses its internal 1k pull-up and the full manufacturer `Temperature - Haltech Oil 150C 1/8 NPT HT010306.cal` calibration. No external 5V lead or accessory ground is added. Verify PD16-to-R3 sharing and actual installed firmware/configuration; no tune was supplied or edited.
- R3 spare capacity stays one AVI, four SPI and six DPO. PD16 now has TWO spare AVIs (AVI3/A27, AVI4/A28); all output reserves remain unchanged. No I/O expander is needed for this addition.
- Transmission sensor mounting/thread/immersion and mechanical clearance, operating-temperature range, reference-temperature verification, separate alarms/open/short diagnosis and stale-CAN behavior remain commissioning work. No temperature thresholds or protection actions are invented.
- All Revision I power, cutoff, split-pump and isolated CAN-power construction requirements remain in force. No change to installed-hardware or fabrication-release status.

Current files: `Race_Car_RevJ/` and `Race_Car_RevJ_Single_Page/`. I and earlier revisions remain historical.

## Previous revision - I, 23 October 2026

Owner-authorized master-stop/protection revision: CARTEK X-Pro negative isolation, dedicated NC external kill and internal latch switches, TE EV200AAANA K1 physical main-positive cutoff, complete feeder paths, separate DW100 outputs (R3 E4 / PD16 B4) and independent PD16/ABS wake feeds (R3 HBO6/HBO3). All load returns are downstream of negative isolation. Crank12703627 retains GM5V mapping; cam12591720 now has explicit A5V/Breturn/Csignal. No injector/coil/lift branch fuses restored. Numeric feeder/PDM protection, actual wire/contact ratings and powered checkout remain open. Current native/continuous files are under Race_Car_RevI and Race_Car_RevI_Single_Page. Current README and CODEX_HANDOFF.md take precedence over historical descriptions below.

## Previous revision - H, 22 October 2026

Current drawing: `Race_Car_RevH/`, with the matched continuous view in `Race_Car_RevH_Single_Page/`. Crank B1 now uses the selected GM Gen IV 5V basis: A=signal to R3 C1, B=return to C26, C=regulated 5V from C25. W078 is retired; W061 is the shared reference. The exact installed sensor and connector still require confirmation because general Haltech documentation lists 12V, while reviewed GM factory references specify 5V. See `Race_Car_RevH/Sources/Crank_Sensor_Research.md` and S02. Cam supply stays unresolved. The 200mA shared reference-current budget includes the crank sensor. All other G electrical assignments are retained. The complete transfer briefing is `CODEX_HANDOFF.md`.

## Previous revision - G, 22 October 2026

### Rear lamps and hazards - current owner selection

Two rear assemblies each have separate tail and brake LED bulbs. Hazards flash both headlights and both tail bulbs together; brake bulbs stay steady on brake request. Separate hazard lamps and their nets are removed; PD16 A5/A6 are spare. Hazard logic overrides steady head/tail requests while enabled and restores them when switched off. Actual NSP logic, lamp compatibility and flash period remain L01 commissioning checks.


Previous diagrams are in `Race_Car_RevG/` and its matched single-page folder. Revision G selects the R3 onboard 4-bar absolute MAP, removes B3 and its wires, and frees AVI9/C18. R3 HCO electronic protection replaces the six provisional injector/coil/lift branch fuses; every branch must be sized against the programmed trip curve (P02). Shared outputs remain shared. Main-feeder and ABS protection remain. See the Revision G README for validation and remaining build holds.

## Previous revision - F, 21 October 2026

Previous diagrams are in `Race_Car_RevF/`, with the matched continuous view in `Race_Car_RevF_Single_Page/`. Revision F incorporates iC-7, owner-planned WolfBox G900 Pro hardwire kit, purchased HT-011502 keypad/camera toggle, HT-011600 TMS-4, HT-010306 oil temperature, HT-010206 intake-air temperature and HT-010910 fuel pressure. The listed additions fit existing I/O: oil temperature uses PD16 AVI1/A20, air/fuel sensors replace existing R3 placeholders, TMS-4 uses CAN1 and camera retains PD16 A7. Fuel level moves to iC-7 AVI4/pin21. Full details, remaining capacity and power/reference-current/kit-version holds are in the Revision F README. Earlier revision descriptions below are historical and superseded where they conflict.

## Owner equipment update - 21 October 2026

- Selected dash is now the **Haltech iC-7**, replacing the previously selected uC-10. Purchase of the iC-7 has not been stated.
- Owner purchased the **WOLFBOX G900 Pro mirror dash cam**. Use this as the selected camera/mirror system in place of the generic rear camera + display placeholder, subject to confirming whether any separate camera is also intended.
- The preserved Revision E schematics, PDFs, connection schedules and CAD/UC10 model describe the earlier equipment. Revision F supersedes those electrical drawings; the CAD/UC10 model remains historical. The historical uC-10 pin assignments, spare-I/O counts and I/O-sharing instructions below and in Revision E must not be applied to the iC-7.
- Revision F checks the iC-7 connector functions and moves fuel level to pin 21; installed hardware/firmware and sender calibration remain commissioning checks. Haltech identifies iC-7 fuel level as AVI4; do not transfer the Revision E uC-10 AVI1 assignment by name. Gear display remains intended to receive the R3 gear channel over the Haltech CAN connection, with configuration to verify.
- Retain PD16 A7 / HCO5 / CAMERA_POS as the provisional camera branch reservation. Owner now selects the WolfBox G900 Pro hardwire kit for planned purchase. Revision F shows its converter and switched BATT/ACC leads; confirm the supplied variant, current limit and conductor protection before build. Do not interpret the existing generic supply symbol as approval to connect vehicle voltage directly to the camera power connector.
- Owner requests camera power on/off from one button on the Haltech keypad. Design intent: a latching toggle command over Haltech CAN through the Nexus R3 controls PD16 A7 / HCO5 / CAMERA_POS, which feeds the appropriate Wolfbox power adapter/converter. First press powers the camera; second press removes power. Physical button position remains unassigned. Proposed initial state is OFF after system power-up; verify configuration and behavior during commissioning.
- No always-on parking-mode feed is requested. Keep camera power downstream of master isolation. Confirm the purchased power adapter/kit and its required connections before final wiring; do not assume a three-wire parking kit can be wired identically to a two-wire converter. Set protection to suit the converter, wiring and measured startup demand. Camera operation requires the R3, keypad and PD16 awake; this button is not a system wake switch.
- Owner confirms purchase of Haltech 15-button keypad, supplied part reference **HTH-HT-011502** (Haltech manufacturer reference **HT-011502**, 3 x 5). This confirms purchase of the previously selected keypad.
- Manufacturer references: [Haltech standalone iC-7 installation](https://www.haltech.com/news-events/installing-a-stand-alone-ic-7-dash/), [Haltech fuel level calibration](https://support.haltech.com/portal/en/kb/articles/fuel-level-sensor-calibration), [WOLFBOX G900 Pro](https://wolfbox.com/products/wolfbox-2024-g900-pro-wifi-touch-screen-parking-monitoring-dash-cam-smart-mirror-with-starvis-678-sensor), [G900 Pro hardwire kit](https://wolfbox.com/products/wolfbox-dash-cam-hardwire-kit-for-g900pro).

The historical Revision E KiCad draft is in `Race_Car_RevE/`. Revision E selects Delta public CAN wheel speeds for R3 traction control per the owner-supplied Haltech support response, retains four spare R3 SPIs, and records uC-10/PD16 expansion capacity on sheet 15. Gen 2 CAN protocol compatibility, bitrate/termination, speed calibration and failure behavior remain commissioning holds. Revision D adds the owner-selected HGT strain-gauged shift knob on AVI11 (C28), with C25 regulated 5 V and C26 sensor ground. See sheet 14 and its README for connector verification, supply-current and calibration holds. Revision C connects the identified Novotechnik RSC-2841-634-211-202 gear sensor to the Nexus R3 for gear display on the uC-10. Revision B adds the owner-selected Haltech PD16 HT-198100 and PROFORM 67049 kit (two 67048 fans), with confirmed rear-radiator clearance. See its README for assignments, verification scope and release holds. Earlier fan/PDM placeholders below are historical and superseded by Revision B.

## Confirmed user decisions

### Safety reference

- No particular racing series or class targeted. User has aimed to meet NASA's general rules.
- Use NASA Club Codes and Regulations (CCR) as the electrical safety reference. Reviewed edition: 2026.3, accessed 2026-09-20: https://www.nasaproracing.com/rules/ccr.pdf . This records a design target, not a compliance determination.
- Section 15.8: provide an externally accessible, labelled master cutoff, with engine shutdown and power isolation subject to the listed fire-system, communications and life-support exceptions.
- Sections 18.5-18.6: secure battery, insulate positive terminal, place lithium-ion battery outside passenger area, protect energized wiring.
- Engineering follow-up: resolve one-wire alternator shutdown/isolation, battery/BMS specifications, cutoff model and location, and any separately powered fire system. Do not infer series-specific equipment restrictions.
- User specifies battery mounting inside the car's tunnel and confirms the tunnel is fully separate from the cockpit. Record separation as user-confirmed; detailed mounting, terminal protection and enclosure construction still belong in the installation review.
- Master cutoff unit has not been selected. Keep manufacturer/model, power connections, control wiring and mounting arrangement TBD pending battery, alternator and installation details.

### Battery

- User supplied Braille G30H GreenLite datasheet link as the battery reference: https://braillebattery.com/wp-content/uploads/2023/06/Braille-G30H-GreenLite-Data-Sheet.pdf . Direct PDF retrieval failed; specifications below were obtained from Braille's own product listings, not the unread PDF.
- Manufacturer product page: https://braillebattery.com/batteries/g30h-lithium-green-lite-motorsports-12-volt-battery/ (search-indexed specifications); store: https://shopbraille.com/products/braille-green-lite-g30h-lithium-battery .
- Listed chemistry LFP (LiFePO4); nominal voltage 12.8 V; capacity 30 Ah / 384 Wh.
- Listed discharge capability: 300 A continuous, 752 A for 5 seconds, 600 A for 10 seconds. These are battery capabilities, not measured vehicle demand or automatic cutoff/fuse ratings.
- Recharge voltage 14.4-14.6 V; charge temperature 0-50 C; discharge temperature -20 to +60 C.
- Dimensions 6.8 x 5.2 x 6.9 inches (L x W x H); mass 9 lb; right positive.
- Reviewed sources do not establish maximum permitted charging current or BMS disconnect/protection behavior. Confirm these before approving the 120 A alternator/isolator arrangement; alternator nameplate output alone does not establish actual battery charging current.
- Tunnel placement and separation from cockpit confirmed by user. Master cutoff remains TBD.

### Engine harness donor

- Complete engine harness available from a 2011 L94-equipped Yukon Denali.
- User explicitly does not want to plug this OEM harness into the Haltech.
- Build a new Haltech-oriented harness, reusing as much suitable donor wiring, sensor connectors and pigtails as practical.
- Treat donor harness connector identities, cavity assignments, wire condition and usable lengths as items to verify. Do not assume an OEM ECU pin assignment becomes a Haltech pin assignment.
- Retain connector cavity numbers and record any wire-color transitions at reused pigtails in the final wire schedule.

### Drive-by-wire accelerator

- User specifies C6 Corvette drive-by-wire throttle pedal GM 19417903. GM lists this assembly for 2005-2013 Corvette: https://parts.gmparts.com/product/gm-genuine-parts-accelerator-pedal-with-bracket-and-position-sensor-19417903 .
- Pedal connector cavity assignments are not yet verified.
- User still needs the mating pedal connector; a suitable donor connector may be present in the available Yukon wiring, but this has not been established by inspection.
- CPP lists its six-pin pigtail CPP-LSAPP explicitly for pedal 19417903: https://classicperform.com/shop/cpp-lsapp . Record as a candidate purchase if donor connector reuse is not possible. No purchase authorized or made.
- CPP lists Yukon among applications for this connector style, but this does not establish that the user's engine-only donor harness contains the pedal plug, or that donor wire colors/cavity functions match the Corvette pedal.
- Verify mechanical keying, latch, terminal condition and all six cavity functions before reusing a donor connector. Assign wires from the documented pedal pinout, not donor wire colors.
- User confirms stock LS3 intake and throttle body. Use that as the design basis; exact throttle-body part number and connector pinout remain to verify.
- Pedal and throttle-body electrical compatibility, redundant position-signal assignments, supply/return assignments, and Haltech setup require manufacturer documentation before final pin allocation.

### Front wheel speed sensors

- User identifies GM 22742183 for the front wheel speed sensors.
- See Delta_ABS_Integration_Notes.md for documented ABS requirements and remaining verification items.

### Chassis and packaging

- User identifies this as the custom race car represented in the Assetto Corsa project, not a production Corvette.
- Related task found: "Create Danny’s Race Car v1.8", ID 01a0745c-2c07-7752-bc25-d1d05e491577. Current simulator assets located at D:/SteamLibrary/steamapps/common/assettocorsa/content/cars/dannys_race_car_v1.12.
- The simulator's ui_car.json retains donor Corvette descriptive text; do not treat that text as real chassis specifications or electrical routing evidence.
- Front-mounted GT40 radiator confirmed. Actual R3, ABS, distribution hardware and pump mounting locations and cable-route lengths remain open, but do not block a functional schematic.

### Cooling fans

- Two brushless radiator fans; no models selected. User authorizes judgment for placeholders.
- Draft placeholder: two independently protected 12 V brushless fan assemblies with integrated controllers and separate speed-control inputs, preferably PWM. This is a provisional architecture, not a specified product.
- Diameter, airflow, shroud, steady/inrush current, control frequency/polarity and loss-of-command behavior remain TBD. Do not assume direct PWM switching of motor power is suitable.
- Keep each fan's power branch separate in the draft and reserve two control signals. Confirm fit and cooling duty before selecting parts or assigning final PDM channels.

### Cockpit controls, starter and fire system

- CAN keypad purchased: Haltech HT-011502, owner order reference HTH-HT-011502, 15 buttons (3 x 5). Manufacturer lists Nexus compatibility: https://www.haltech.com/product/ht-011502-haltech-can-keypad/ . Camera power toggle is owner-confirmed; physical button position and other button assignments remain draft choices.
- Starter is an aftermarket VW high-torque unit typically used with a VW bus transaxle. Exact model, main current and solenoid pull-in/hold current remain unknown.
- Starting interlock preference was not answered. Reserve a clutch/neutral interlock provision; logic and sensor availability remain TBD.
- Fire suppression is manually activated by mechanical cable, confirmed by user. No electrical release circuit or activation power supply is required in the current design. System model remains unspecified.
- No wipers and no horn.
- Rain light, driver communications radio and transponder are not confirmed. Keep separate from the already specified brake-marker radio, camera and display.

## Source context

User conversation and `Race Car Electronics info dump (1).pdf`. These notes distinguish user choices from unresolved technical details; they are not a completed wiring specification.


## 25 October - individual physical conductors

Both continuous views now show individual proposed physical conductors and explicit joints, replacing the earlier net-wide logical buses. Native parts, cavities, electrical nets and retained W IDs are unchanged. Full view: `Race_Car_RevJ_Single_Page/Race_Car_RevJ_Continuous_Wiring.pdf`. Power-only: `Race_Car_RevJ_Power_Only/Race_Car_RevJ_Power_Only_Physical_Wiring.pdf`. The older power-only Continuous PDF is the superseded logical-bus snapshot, not the current physical view.

`Race_Car_RevJ/Physical_Topology.json` is the maintained proposed connection topology; `Physical_Connections.tsv` lists individual ID/from/to/net/kind/pair and material/measurement fields; `Physical_Junctions.tsv` lists explicit splice/ground-point intent. C IDs identify 180 proposed individual integration/field conductors (87 in the power-only view); S identifies 85 supplied/retained-loom conductor paths (41 power); V identifies two intact vendor cables. I internal continuity, B metal/lug/bond continuity and U unresolved supplier paths are distinct and are not additional cut wires. W IDs still identify electrical nets, not cuts. J2/J3/J21 are existing ground cable/ground assemblies whose bodies join their own ends.

TB1 has four external branch wires, TB2 six, with their common metal explicitly shown inside the blocks. The shared starter B+ stud has two wire ends. Multiway feeds/returns/reference branches now land at named proposed joints. Proposed CAN1 linear trunk order is R3 -> dash tap -> keypad tap -> TMS4 tap -> PD16, with paired H/L paths and internal PD16 termination represented without an extra field resistor. Exact packaging, tap lengths and all physical joint locations remain open. GP129 front/control/rear ground-point distribution is proposed, with metal/bond paths kept separate from cut-wire records; sensor/CAN returns stay isolated from it.

No final wire gauge/color/cut length/terminal/splice hardware or physical vehicle route is established. Measure and approve these before fabrication. Preserve supplied Delta pressure returns and intact WolfBox USB/rear cables; unresolved supplier construction is not turned into a fabricated splice/cavity map. No extra ground bypass or electrical reassignment was made.

`physical_topology_j.py` audits the maintained model and refreshes derived schedules during normal builds. Its `--initialize` option refuses to overwrite an existing topology: do not delete/reinitialize it after entering measurements. `render_physical_j.py` renders both views; `validate_physical_j.py` independently recovers the actual PDF conductors and explicit internal bars/dots and matches the native net endpoint sets. Existing build/validate entry-point names call these modules, so `rebuild_current.py` remains the portable command. Prior build reports/ZIPs/change records remain their dated snapshots.


## Retained stock engine harnesses - 25 October

Owner confirms stock L94 coils and coil-bank looms, with LS3 injectors using the
retained L94 donor injector wiring if actual connector fit and reach permit.
Current J now has 19 sheets, 96 components, 418 modeled pins, 359 connected
endpoints, 59 NC/unavailable positions and the same 117 named nets. X111/X113 on
new sheet 19 represent the odd/even OEM coil-bank interfaces. All existing device
assignments, R3/PD16 output allocations and retained W IDs are unchanged.

Read Race_Car_RevJ/Stock_Engine_Harnesses.json and OEM_Harness_Interfaces.tsv.
Reference bank positions are A power ground, E low reference, H +12V; four trigger
positions differ by bank, and D is unavailable. These are GM service reference
cavities, not an inspection claim for the donor. Functional coil/injector device
pin IDs remain distinct from source cavity references. Catalog references include
square12570616/service12611424 and round12573190/service12699382; actual version
is unverified. No supplier PN, wire color or gauge is asserted as inspected.

Both continuous PDFs and the viewer now distinguish 56 retained OEM S conductor
paths (38 coil, 18 injector) from new C integration wires. The complete topology
has 180 C, 85 S, 2 V, 11 I, 9 B and 1 U records: 288 selectable connections full,
147 power-only. The power view retains 44 nets, 70 component interfaces and 167
native endpoints; it omits low-reference and trigger signals. Shared stock-loom
nodes represent functional continuity; exact joint counts/type/locations remain
unverified. CUT-INJ nodes are functional cut/termination boundaries, not invented
factory bulkhead plugs. Thirty-two old generic direct-branch C records are retired
and archived; other record IDs/material fields are preserved. Do not reinitialize
the topology or rerun the one-time migration under Change_Records.

Factory feeds can serve injectors and coils together. Separate donor injector-only
feed branches from coil/other loads so R3 E1/HCO1 cannot be connected to E2/HCO2.
No removed bank fuses are restored. Coordinate electronic trip curves with every
retained branch wire, splice, bank feed and connector contact.

Coil low-reference grounding remains HOLD: the drawing retains bank E to R3 C26,
separate from bank A to engine ground. GM OEM evidence separates these circuits;
Haltech's generic Gen IV guide also advises both coil grounds at the head. Resolve
that difference with the exact coil/R3 installation evidence before power. Do not
bridge W009 to W062 or add a chassis bond to sensor ground from this drawing.
Temperature sensor returns and the CARTEK isolated-negative path are unchanged.

stock_engine_harness_j.py audits the maintained donor assembly paths and is called
by the normal topology audit. Normal rebuild_current.py regenerates native sheets,
schedules, both continuous PDFs and the viewer/ZIP. Fresh export and actual PDF
path/symbol equivalence are checked; physical fit and powered behavior remain C18
commissioning work. Earlier numerical counts in dated sections are snapshots.


## Current U3 starter relay selection — 25 Oct 2026

U3 is now the owner-selected **Cole Hersee 24059** base part: 12V, 17.5-ohm isolated coil, 85A normally-open contacts, bulkhead bracket, two large 5/16-24 and two small #10-32 studs. PWR/OUT/CMD/GND are installer functional tags, not claimed stamped terminal numbers or fixed left/right positions. See `Race_Car_RevJ/Starter_Relay.json` (or `Starter_Relay.json` inside that folder).

Large PWR takes F5/2 via C026/W013; the other large OUT goes to the starter's **small SOL terminal** via C025/W012. Small CMD takes R3 A18/HBO5 via C027/W014; the other small GND returns to GP129-C vehicle return via C180/W129, not the isolated battery negative or the relay case. The starter motor's heavy B+ trunk is separate.

D60 is an external Vishay 1N5408-E3/54 suppression diode across the small coil studs: **banded cathode K to CMD, unbanded anode A to GND**. C213/C214 identify its local insulated leads, not two new long harness wires or a second remote ground landing. Confirm actual received part and polarity before powering. The diode affects release timing; verify prompt starter disengagement and abort/master-OFF behavior under C19. Calculated coil draw is about 0.69A at12V; the owner's approximately30A solenoid pull-in estimate is unmeasured. F5 remains present, rating and wire/contact coordination unselected. No installed NSP settings or powered test is claimed.

Current model after S2 removal: 95 parts, 414 pins, 354 connected endpoints, 60 NC and115 W nets. Physical views have284 full /145 power paths, with26 chassis-return glyphs under existing display policy. Construction totals:94 MAKE,81 LEAD,85 LOOM,2 CABLE,11 internal,9 structure and2 HOLD. C213/C214 and D60 are added; C076/C123 and W046 are retired with S2. Retained conductor identifiers/endpoints/measurement fields remain. The interactive viewer includes a four-stud wiring table and suppression polarity for U3 and an explanation for D60. Earlier dated numerical snapshots are historical.

## S2 removal — latest owner update, 25 Oct 2026

S2 clutch/neutral start switch is removed, including C076 and C123. W046 START_PERMIT is retired and must never be reused. **R3 C5/SPI1 is now spare and unconnected**; insulate the unused supplied lead individually. No replacement neutral switch or jumper is inferred. Starter-control intent no longer requires a clutch/neutral input; fresh request, GT/R3 run permission, engine-not-running inhibition, bounded crank and release on running/request end/timeout/abort/master OFF remain to implement and verify. See Control_Specification.json, Starter_Relay.json and commissioning C20. Native sheets3/6, schedules, continuous views and viewer are updated together.
