"""Maintained proposed conductor topology over current native Revision J nets.

Normal builds read/audit Physical_Topology.json. --initialize only creates a new
file and refuses to overwrite it, preserving future measurements and wire IDs.
"""
from pathlib import Path
import json,csv,hashlib,argparse
from collections import defaultdict
R=Path(__file__).resolve().parent;D=R/'Race_Car_RevJ';TARGET=D/'Physical_Topology.json'

def initial_model():
 data=json.loads((D/'Design_Data.json').read_text());parts={p['ref']:p for p in data['parts']}
 model={'revision':'J','view_revision':'physical conductors 01','updated':'2026-10-25',
  'status':'PROPOSED PHYSICAL CONNECTION TOPOLOGY - NOT A CUT/LENGTH OR FABRICATION RELEASE',
  'electrical_basis':'Design_Data.json; no native part/pin/net electrical change',
  'id_convention':'C = individual field conductor; S = supplied-loom conductor path; V = intact vendor cable assembly; I = internal continuity (not a field wire); B = bond/metal contact (not a cut wire); U = unresolved supplier continuity. W identifiers remain electrical nets.',
  'nodes':[],'connections':[],'open_ends':[],'assemblies':[],
  'power_net_names':json.loads((R/'Race_Car_RevJ_Power_Only/Drawing_Manifest.json').read_text())['selected_net_names'],
  'holds':['Every new splice/ground-point location, hardware, joining method and branch routing is proposed, not measured or installed.',
   'Length, gauge, insulation color, terminal part number, crimp/tool and protective sleeving are intentionally unselected.',
   'No parallel-output connection, additional chassis bond on a sensor return, or separate external kill switch is introduced.',
   'CAN1 station order R3 -> dash -> keypad -> TMS4 -> PD16 is proposed; confirm packaging/stub lengths and two effective end terminations.',
   'Supplied Delta internal construction and unselected interfaces stay explicitly unresolved; no pressure-return chassis wire is added.',
   'GP129 ground-point distribution is a proposed vehicle-side return arrangement. Confirm structural conductivity/bond paths; metal links are not additional cut wires.',
   'TB ports name branch/lug intent on common metal, not numbered physical studs. Stacking/rating/cover holds remain.',
   'Existing J2/J3 ground straps and J21 ABS-ground assembly are represented as assemblies with two ends; their bodies are not extra external wires.']}
 counters=defaultdict(int)
 def node(key,label,kind,net,note):
  if not any(n['id']==key for n in model['nodes']):model['nodes'].append({'id':key,'label':label,'kind':kind,'net':net,'status':'PROPOSED / physical location and hardware TBD','note':note})
  return key
 def edge(a,b,net,kind='C',basis='Proposed point-to-point conductor; physical route/terminations to verify',pair=None):
  counters[kind]+=1;key=f'{kind}{counters[kind]:03d}'
  model['connections'].append({'id':key,'a':a,'b':b,'net':net['name'],'net_id':net['id'],'kind':kind,'basis':basis,
   'pair_group':pair,'length_mm':None,'gauge_AWG':None,'insulation_color':None,'terminal_a_part':None,'terminal_b_part':None,
   'release':'HOLD - unmeasured/unreleased' if kind in ['C','S','V'] else 'Not a separate cut wire'})
 def splice(n,label=None,kind='splice'):
  return node('SP'+n['id'][1:],label or (n['name'].replace('_',' ')+' splice'),kind,n['name'],'Proposed wire-end splice; method, capacity and position TBD')
 for n in sorted(data['nets'],key=lambda n:int(n['id'][1:])):
  name=n['name'];ep=[e['ref']+'/'+e['pin'] for e in n['endpoints']]
  if name=='BATT_RAW':
   for a,b in [('BT1/+','TB1/BAT'),('TB1/F0','F0/1'),('TB1/F2','F2/1'),('TB1/F4','F4/1')]:edge(a,b,n,basis='Owner-selected raw-positive distribution; TB1 branch/lug labels are functional, actual stack TBD')
   for pin in ['F0','F2','F4']:edge('TB1/BAT','TB1/'+pin,n,'I','TB1 common conducting post; not an extra wire')
  elif name=='MAIN_FUSED_BUS':
   for a,b in [('F0/2','TB2/IN'),('TB2/F1','F1/1'),('TB2/F50','F50/1'),('TB2/F41','F41/1'),('TB2/F42','F42/1'),('TB2/F5','F5/1')]:edge(a,b,n,basis='Owner-selected switched distribution; TB2 branch/lug labels are functional, actual stud/stack assignment TBD')
   for pin in ['F1','F50','F41','F42','F5']:edge('TB2/IN','TB2/'+pin,n,'I','TB2 internal conducting bar; not an extra wire')
  elif name=='STARTER_FEED':
   edge('F2/2','M1/B+',n,basis='Owner-selected ONE shared start/charge cable from F2 at battery block to starter battery-side stud')
   edge('M1/B+','F3/1',n,basis='Separate alternator branch attaches to SAME starter battery B+ stud; F3 near starter. Verify two-lug stack')
  elif name=='VEHICLE_RETURN':
   for zone in ['F','C','R']:node('GP129-'+zone,'Vehicle return point '+zone,'ground_point',name,'Proposed front / control / rear vehicle-side ground point; exact hardware/metal return path TBD')
   edge('GP129-F','GP129-C',n,'B','Vehicle-side common return structure/bond continuity; not a specified extra cable')
   edge('GP129-C','GP129-R',n,'B','Vehicle-side common return structure/bond continuity; not a specified extra cable')
   front={'M6','M7','H30','H37','J21'};rear={'M3','M4','M5','H31','H35','H34','H36','U22'}
   for a in ep:
    ref=a.split('/')[0];zone='F' if ref in front else ('R' if ref in rear else 'C')
    kind='B' if ref in ['J2','J3','J21'] else 'C'
    edge(a,'GP129-'+zone,n,kind,'Ground-strap/assembly lug attachment, not another wire' if kind=='B' else 'Individual return conductor to proposed vehicle-side ground point; actual placement/size TBD')
  elif name=='ENGINE_GND':
   hub=node('GP009','Engine block / coil ground point','engine_metal',name,'Case bonds use engine metal; coil ground-wire landing locations TBD')
   for a in ep:edge(a,hub,n,'C' if a.startswith('IC') else 'B','Coil power-return conductor; verify actual coil requirements' if a.startswith('IC') else 'Engine case/strap-lug bolted continuity through engine metal, not an extra cut wire')
  elif name=='CHASSIS_GND':edge(ep[0],ep[1],n,'B','J3 chassis-side lug and U2 conductive case bond through chassis metal; not a new jumper wire')
  elif name in ['CAN1_H','CAN1_L']:
   suffix='H' if name.endswith('_H') else 'L';pin='23' if suffix=='H' else '24'
   taps=[node(f'CAN1-{i}{suffix}',f'CAN1 station {i} / {suffix}','can_splice',name,'Proposed short device tap on linear trunk; H/L paired station, physical order/lengths TBD') for i in [1,2,3]]
   edge('J10/'+pin,taps[0],n,pair='TP-CAN1-01')
   edge(taps[0],taps[1],n,pair='TP-CAN1-02');edge(taps[1],taps[2],n,pair='TP-CAN1-03')
   edge(taps[2],'J40/'+pin,n,pair='TP-CAN1-04')
   for i,device in enumerate(['U10/'+('1' if suffix=='H' else '2'),'U11/'+suffix,'U23/'+('2' if suffix=='H' else '1')]):edge(taps[i],device,n,pair='TP-CAN1-TAP'+str(i+1))
   edge('J40/'+pin,'J30/'+suffix,n,'I','J30 denotes PD16 end termination already represented; no third external resistor or extra harness wire')
  elif name in ['CAN2_H','CAN2_L']:
   suffix='H' if name.endswith('_H') else 'L';tap=node('CAN2-END'+suffix,'CAN2 far-end tap / '+suffix,'can_splice',name,'Proposed far-end termination tap; physical hardware/termination arrangement to verify')
   for a,pair in [('J11/'+('21' if suffix=='H' else '22'),'TP-CAN2-TRUNK'),('J22/'+('3' if suffix=='H' else '2'),'TP-CAN2-DEVICE'),('J31/'+suffix,'TP-CAN2-TERM')]:edge(a,tap,n,pair=pair)
  elif name=='BRAKE_REQUEST':
   edge('J20/15','J22/5',n,'I','Supplier assembly continuity from HCU brake sink to public auxiliary port; no added bypass wire')
   edge('J22/5','J11/6',n,basis='Public Delta auxiliary brake request to R3 SPI2; input bias/polarity remain open')
  elif name=='ABS_POWER_RETURN':
   hub=node('LOOM101','Delta supplied return junction','supplier_junction',name,'Existing supplier-internal return continuity; exact internal join location/construction unconfirmed, do not add a new splice')
   for a in ['J20/25','J20/38','J21/ABS','J22/1']:edge(a,hub,n,'S','Supplied Delta loom return path; preserve assembly, verify actual wire/connector continuity')
   edge('J22/1','S21/2',n,basis='Proposed auxiliary-return leg for physical ABS enable switch; verify supplied switch/loom arrangement')
  elif name=='ABS_PRESS_RET_TBD':edge(ep[0],ep[1],n,'U','Supplier-internal pressure-return continuity only; unknown internal cavity. NO chassis/R3 wire or new field cut wire')
  elif name in ['WOLFBOX_USB_CABLE','WOLFBOX_REAR_CABLE']:edge(ep[0],ep[1],n,'V','Preserve intact supplied vendor multi-conductor cable; not a single wire, no splice/cavity map invented')
  elif name=='GT_EXTERNAL_BLUE_LOOP':
   hub=splice(n,'GT blue / blue permanent joint')
   for a in ep:edge(a,hub,n,'S','Join supplied blue flying-lead ends permanently; no external switch or chassis connection')
  elif len(ep)==1:model['open_ends'].append({'endpoint':ep[0],'net':name,'net_id':n['id'],'basis':'Single-end unresolved/held interface; no conductor destination or cut wire invented'})
  else:
   supplied=all(parts[e['ref']]['page'] in [8,9] for e in n['endpoints'])
   kind='S' if supplied else 'C'
   basis='Supplied Delta loom conductor path; preserve actual assembly and verify cavities; not a new field splice' if supplied else 'Proposed individual conductor; route, material and terminations TBD'
   if len(ep)==2:edge(ep[0],ep[1],n,kind,basis)
   else:
    hub=splice(n,kind='supplier_junction' if supplied else 'splice')
    if supplied:
     model['nodes'][-1]['status']='SUPPLIER-INTERNAL JOIN - actual construction/location UNCONFIRMED'
     model['nodes'][-1]['note']='Depicts existing supplied-loom continuity; not an instruction to add a field splice'
    for a in ep:edge(a,hub,n,kind,basis)
 for ref in ['J2','J3','J21']:
  p=parts[ref];model['assemblies'].append({'id':'A-'+ref,'ref':ref,'kind':'existing ground strap / ground assembly','ends':[ref+'/'+x['num'] for x in p['pins']],'nets':[x['net'] for x in p['pins']],'note':'Assembly body joins its two ends; no additional external wire is implied by the component representation. Actual cable, lugs, route and rating remain TBD.'})
 return model

def load_and_audit():
 data=json.loads((D/'Design_Data.json').read_text());m=json.loads(TARGET.read_text())
 native={p['ref']+'/'+x['num']:x['net'] for p in data['parts'] for x in p['pins']}
 nodes={n['id']:n for n in m['nodes']};assert len(nodes)==len(m['nodes'])
 assert len({x['id'] for x in m['connections']})==len(m['connections'])
 ids={n['name']:n['id'] for n in data['nets']};seen=set();result={}
 for name in ids:
  parent={}
  def find(a):
   parent.setdefault(a,a)
   if parent[a]!=a:parent[a]=find(parent[a])
   return parent[a]
  for e in [e for e in m['connections'] if e['net']==name]:
   assert e['net_id']==ids[name]
   for a in [e['a'],e['b']]:
    assert (native.get(a)==name if a in native else nodes[a]['net']==name),(e,a)
    if a in native:seen.add(a)
   parent[find(e['a'])]=find(e['b'])
  opened=[x for x in m['open_ends'] if x['net']==name]
  for x in opened:assert native[x['endpoint']]==name;seen.add(x['endpoint']);find(x['endpoint'])
  endpoints={a for a,n in native.items() if n==name}
  assert {a for a in parent if a in native}==endpoints,name
  assert len({find(a) for a in endpoints})==1,name
  result[name]=sorted(endpoints)
 assert seen=={a for a,n in native.items() if n is not None}
 assert all(e['net'] in ids for e in m['connections'])
 assert {e['a'] if e['b']=='M1/B+' else e['b'] for e in m['connections'] if e['kind']=='C' and 'M1/B+' in [e['a'],e['b']]}=={'F2/2','F3/1'}
 assert [e for e in m['connections'] if e['net']=='BATT_NEG']==[e for e in m['connections'] if e['net']=='BATT_NEG' and {e['a'],e['b']}=={'BT1/-','U2/M8'}]
 assert not any(e['kind']=='C' for e in m['connections'] if e['net']=='ABS_PRESS_RET_TBD')
 for n in ['R3_SG','PD16_SG','R3_CAN_RETURN','DASH_SG']:
  assert not any(e['a'].startswith('GP') or e['b'].startswith('GP') for e in m['connections'] if e['net']==n)
 assert all(e['kind']=='I' for e in m['connections'] if e['a'].startswith('J30/') or e['b'].startswith('J30/'))
 # Every CAN1 trunk/tap pair has one H and one L path with matching endpoint stations.
 pairs=defaultdict(list)
 for e in m['connections']:
  if e.get('pair_group'):pairs[e['pair_group']].append(e)
 for key,es in pairs.items():assert len(es)==2 and {e['net'][-1] for e in es}=={'H','L'},key
 from stock_engine_harness_j import audit
 audit(data,m)
 from harness_construction_j import audit as audit_construction
 audit_construction(m)
 return data,m

def schedules(m):
 from wiring_work_j import write_work_lists
 write_work_lists(m,D)
 path=D/'Physical_Connections.tsv'
 fields=['ID','Kind','Net_ID','Net_Name','From','To','Pair_Group','Length_mm','Gauge_AWG','Insulation_Color','Terminal_A_Part','Terminal_B_Part','Status','Basis']
 with path.open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=fields,delimiter='\t');w.writeheader()
  for e in m['connections']:w.writerow(dict(zip(fields,[e['id'],e['kind'],e['net_id'],e['net'],e['a'],e['b'],e.get('pair_group') or '',e['length_mm'] if e['length_mm'] is not None else 'UNMEASURED',e['gauge_AWG'] or 'UNRELEASED',e['insulation_color'] or 'UNSELECTED',e['terminal_a_part'] or 'UNSELECTED',e['terminal_b_part'] or 'UNSELECTED',e['release'],e['basis']])))
 with (D/'Physical_Junctions.tsv').open('w',newline='',encoding='utf-8') as f:
  fields=['ID','Kind','Net','Label','Status','Note'];w=csv.DictWriter(f,fieldnames=fields,delimiter='\t');w.writeheader()
  for n in m['nodes']:w.writerow(dict(zip(fields,[n['id'],n['kind'],n['net'],n['label'],n['status'],n['note']])))

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--initialize',action='store_true');a=p.parse_args()
 if a.initialize:
  if TARGET.exists():raise SystemExit('Refusing to overwrite maintained topology/measurements. Edit or deliberately migrate instead.')
  TARGET.write_text(json.dumps(initial_model(),indent=2))
 data,m=load_and_audit();schedules(m)
 print(json.dumps({'result':'PASS','native_nets':len(data['nets']),'physical_junction_nodes':len(m['nodes']),'connections_by_kind':{k:sum(e['kind']==k for e in m['connections']) for k in ['C','S','V','I','B','U']},'single_end_holds':len(m['open_ends'])},indent=2))
