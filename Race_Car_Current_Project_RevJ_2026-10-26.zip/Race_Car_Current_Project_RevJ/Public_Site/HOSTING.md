# Public wiring schematic hosting

Owner approved public access on 26 October 2026 and completed GitHub sign-in.
The public repository is https://github.com/dannydowns46/race-car-wiring-schematics .
The Sites connector is unavailable; GitHub Pages is the selected hosting provider.
Publish the CONTENTS of dist/ to the main branch ROOT and enable branch-based Pages.
Do not upload this parent folder as an extra directory, and do not use the optional
Actions workflow with this layout. Record the actual deployed URL in publishing.json.
Do not claim a live URL until deployment succeeds and the URL is observed.

The authoritative design stays in the parent project. This folder holds the publishing
tools and generated static site. `dist/` contains an unchanged copy of the validated
interactive HTML, the three current PDFs, a companion native PDF for existing links,
four construction schedules, a current rebuildable project ZIP and release metadata.
`publishing.json` records the selected provider, access and verified URL once available.
Do not replace the interactive viewer with a newly implemented drawing application.

## Future requested updates

1. Read the parent AGENTS.md and handoff documents; change maintained design sources.
2. Run the normal complete rebuild, inspect affected drawings and check the viewer.
3. Run `python Public_Site/prepare_release.py --date YYYY-MM-DD` from any directory.
   Use the user's America/Chicago date. This checks current engineering outputs and
   refreshes the public assets; it never changes electrical assignments.
4. Review `Public_Site/preview/Release_Validation.json`. Existing dated release ZIPs
   remain available; filenames from released downloads must not be silently reused
   for different bytes. Use `--release-id` for an additional release on the same day.
5. Publish the refreshed `dist/` files to the SAME repository/site, retaining its public
   audience and stable homepage/viewer paths. Verify the deployed URL and release ID.
6. Record deployment evidence/URL in publishing.json. Commit/push no credentials,
   local scratch folders, private machine configuration or unrelated workspace files.

GitHub Pages can publish these files from a public repository's main-branch root
with `.nojekyll`, or from `dist/` using the included Actions workflow. Pick one actual
layout during setup and record it; do not guess a GitHub username or site URL.

The project ZIP is the maintained current-revision working set plus required frozen
I baseline files and source references. It is not an archive of every historical
revision, old transfer ZIP, CAD project or unrelated local file. Its inventory and
SHA256 manifest define the exact included files. The old 23 October complete ZIP
elsewhere in the workspace is historical and must not be advertised as current.

No ongoing scheduled job is created. On future user requests, rebuild and republish
through the configured account. This does not update a website merely because a
local file changed.
