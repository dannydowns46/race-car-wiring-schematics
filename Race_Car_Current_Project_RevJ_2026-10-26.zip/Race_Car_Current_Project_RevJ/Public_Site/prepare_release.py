"""Refresh the public static site from validated current J outputs; no design edits."""
from pathlib import Path
import argparse,json,hashlib,shutil,subprocess,sys,zipfile,html
from html.parser import HTMLParser
SITE=Path(__file__).resolve().parent;R=SITE.parent;D=R/'Race_Car_RevJ';OUT=SITE/'dist';PREVIEW=SITE/'preview'
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--date',required=True);p.add_argument('--release-id');p.add_argument('--skip-check',action='store_true',help='Only when the unchanged current outputs have just passed checks');p.add_argument('--replace-unpublished',action='store_true',help='Replace a prepared archive only before the first successful site publication');a=p.parse_args()
release_id=a.release_id or a.date
assert len(a.date)==10 and all(c.isalnum() or c in '-_.' for c in release_id)
if not a.skip_check:
 run=subprocess.run([sys.executable,str(R/'rebuild_current.py'),'--check-only'],cwd=R,capture_output=True,text=True)
 PREVIEW.mkdir(exist_ok=True);(PREVIEW/'Engineering_Checks.txt').write_text(run.stdout+'\n'+run.stderr,encoding='utf-8')
 if run.returncode:raise SystemExit('Engineering checks failed; see preview/Engineering_Checks.txt')
native=json.loads((D/'Design_Data.json').read_text());assert len(native['parts'])==95 and len(native['nets'])==115
assert json.loads((D/'Validation.json').read_text())['connected_pin_endpoints']==354
OUT.mkdir(exist_ok=True);PREVIEW.mkdir(exist_ok=True)
copies={
 'Race_Car_RevJ_Interactive.html':R/'Race_Car_RevJ_Interactive/Race_Car_RevJ_Interactive.html',
 'Race_Car_RevJ_Interactive_Viewer.zip':R/'Race_Car_RevJ_Interactive/Race_Car_RevJ_Interactive_Viewer.zip',
 'Race_Car_RevJ.pdf':D/'Race_Car_RevJ.pdf',
 'Race_Car_RevJ_Flagged.pdf':D/'Race_Car_RevJ.pdf',
 'Race_Car_RevJ_Continuous_Wiring.pdf':R/'Race_Car_RevJ_Single_Page/Race_Car_RevJ_Continuous_Wiring.pdf',
 'Race_Car_RevJ_Power_Only_Physical_Wiring.pdf':R/'Race_Car_RevJ_Power_Only/Race_Car_RevJ_Power_Only_Physical_Wiring.pdf'}
for name in ['Wires_To_Provide.tsv','Supplied_Leads_To_Finish.tsv','Existing_Loom_And_Cable_Paths.tsv','Other_Connection_References.tsv']:copies[name]=D/name
for name,src in copies.items():shutil.copy2(src,OUT/name)
(OUT/'.nojekyll').write_text('')

root_files=['AGENTS.md','START_HERE.md','CODEX_HANDOFF.md','Vehicle_Wiring_Design_Basis.md','OPEN_ITEMS.tsv','REBUILD.md','requirements-current.txt','AUDIT_NOTICE.md','Delta_ABS_Integration_Notes.md','CHANGELOG.md','rebuild_current.py','build-racecar-revj.js','finish-revj.py','validate-revj.py','physical_topology_j.py','render_physical_j.py','validate_physical_j.py','stock_engine_harness_j.py','harness_construction_j.py','wiring_work_j.py','ground_display_j.py','build_single_page_j.py','validate_single_page_j.py','build_power_systems_j.py','validate_power_systems_j.py','build_interactive_j.py','validate_interactive_j.py','interactive_viewer_j.html','render_review_j.py']
files={f:R/f for f in root_files}
for folder in ['Race_Car_RevJ','Race_Car_RevJ_Single_Page','Race_Car_RevJ_Power_Only','Race_Car_RevJ_Interactive']:
 for src in (R/folder).rglob('*'):
  if not src.is_file() or '__pycache__' in src.parts:continue
  rel=src.relative_to(R).as_posix()
  if '/preview/' in rel and src.name!='netlist.xml':continue
  if src.suffix in ['.lck','.bak','.pyc']:continue
  if src.name=='Race_Car_RevJ_Power_Only_Continuous.pdf':continue
  if src.name in ['CARTEK_XPro_Manual_1.1.pdf','Viewer_Data.json']:continue # Historical replaced hardware / redundant embedded-viewer data.
  files[rel]=src
for name in ['Design_Data.json','IO_Audit.tsv','Race_Car_RevI.kicad_pro','Net_Revision_Record.json','README.md']:files['Race_Car_RevI/'+name]=R/'Race_Car_RevI'/name
files['Race_Car_Readable/Readable_Names.json']=R/'Race_Car_Readable/Readable_Names.json'
for name in ['AGENTS.md','HOSTING.md','prepare_release.py','index.template.html','publishing.json']:
 files['Public_Site/'+name]=SITE/name
files['Public_Site/.github/workflows/pages.yml']=SITE/'.github/workflows/pages.yml'
manifest={'revision':'J','release_id':release_id,'release_date':a.date,'scope':'Maintained current working set, required I regression baseline and source references; historical archives/CAD/scratch excluded','files':[{'path':rel,'bytes':src.stat().st_size,'sha256':hashlib.sha256(src.read_bytes()).hexdigest()} for rel,src in sorted(files.items())]}
bundle='Race_Car_Current_Project_RevJ_'+release_id+'.zip';target=OUT/bundle;temporary=PREVIEW/'project-candidate.zip';prefix='Race_Car_Current_Project_RevJ/'
with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for rel,src in sorted(files.items()):
  zi=zipfile.ZipInfo(prefix+rel,date_time=(2026,1,1,0,0,0));zi.compress_type=zipfile.ZIP_DEFLATED;z.writestr(zi,src.read_bytes(),compresslevel=7)
 zi=zipfile.ZipInfo(prefix+'PUBLIC_PACKAGE_MANIFEST.json',date_time=(2026,1,1,0,0,0));zi.compress_type=zipfile.ZIP_DEFLATED;z.writestr(zi,json.dumps(manifest,indent=2)+'\n',compresslevel=7)
with zipfile.ZipFile(temporary) as z:
 assert z.testzip() is None
 for f in manifest['files']:assert hashlib.sha256(z.read(prefix+f['path'])).hexdigest()==f['sha256']
digest=hashlib.sha256(temporary.read_bytes()).hexdigest()
replacing=target.exists() and hashlib.sha256(target.read_bytes()).hexdigest()!=digest
if replacing:
 state=json.loads((SITE/'publishing.json').read_text())
 if not a.replace_unpublished or state.get('site_url') or state.get('status') in ['published','live','succeeded']:raise SystemExit('A different bundle already uses this release ID. Preserve released bytes and choose --release-id '+release_id+'-2')
 backup=PREVIEW/('Unpublished_'+target.name)
 if not backup.exists():shutil.copy2(target,backup)
shutil.copy2(temporary,target)
(PREVIEW/'Project_Package_Manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
history_path=OUT/'releases.json';history=json.loads(history_path.read_text()) if history_path.exists() else []
entry={'id':release_id,'date':a.date,'revision':'J','project_zip':bundle,'sha256':digest}
existing=next((e for e in history if e['id']==release_id),None)
if existing:
 if replacing and a.replace_unpublished:history[history.index(existing)]=entry
 else:assert existing==entry
else:history.insert(0,entry)
history_path.write_text(json.dumps(history,indent=2)+'\n',encoding='utf-8')
links=''.join('<p><a href="'+html.escape(e['project_zip'],quote=True)+'">'+html.escape(e['date']+' · Revision '+e['revision']+' · Project ZIP')+'</a></p>' for e in history)
page=(SITE/'index.template.html').read_text(encoding='utf-8').replace('@@RELEASE_ID@@',html.escape(release_id)).replace('@@PROJECT_ZIP@@',bundle).replace('@@RELEASE_LINKS@@',links)
assert '@@' not in page;(OUT/'index.html').write_text(page,encoding='utf-8')
report={'revision':'J','release_id':release_id,'release_date':a.date,'engineering_design_date':'2026-10-25','audience':'public','counts':{'sheets':19,'components':95,'nets':115,'full_paths':284,'power_paths':145},'changes':['U3 Cole Hersee24059 and local D60 suppression','S2 removed; R3 C5/SPI1 spare/unconnected'],'files':[{'name':name,'bytes':src.stat().st_size,'sha256':hashlib.sha256(src.read_bytes()).hexdigest()} for name,src in sorted({**{k:OUT/k for k in copies},bundle:target}.items())],'verification':'Current native/physical/viewer validators passed; package CRC and per-file SHA256 checked. Hardware/NSP tests remain open.'}
(OUT/'release.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
class Links(HTMLParser):
 def __init__(self):super().__init__();self.links=[]
 def handle_starttag(self,t,attrs):
  if t=='a':self.links.append(dict(attrs).get('href',''))
parsed=Links();parsed.feed(page)
assert all((OUT/href.split('#')[0]).is_file() for href in parsed.links)
assert all((OUT/name).read_bytes()==src.read_bytes() for name,src in copies.items())
assert all(p.stat().st_size<25000000 for p in OUT.iterdir() if p.is_file())
validation={'result':'PASS','release_id':release_id,'landing_links_verified':len(parsed.links),'viewer_unchanged':True,'copied_artifacts_byte_identical':True,'project_zip_crc_and_hashes':'PASS','project_zip_files':len(manifest['files'])+1,'project_zip_bytes':target.stat().st_size,'all_assets_below_25MB':True,'published':False,'publication_state':'Public repository created; awaiting initial successful upload and deployment'}
(PREVIEW/'Release_Validation.json').write_text(json.dumps(validation,indent=2)+'\n',encoding='utf-8');print(json.dumps(validation,indent=2))
