# Public schematic site

This folder is the independent publishing checkout, not the authoritative electrical design.
The parent workspace has the maintained KiCad sources and build instructions. Never modify
the electrical model in this publishing checkout. Publish only the generated viewer,
approved schematic PDFs, construction work lists and the explicit current-project bundle.

Reuse the actual repository/site identity in `publishing.json` for every future release.
The Sites tool is unavailable; GitHub Pages is the prepared fallback. No Site was created.
Audience is public by explicit owner instruction on 26 October 2026. Never store credentials
in files or Git. Read `HOSTING.md` and `dist/release.json` for refresh/deployment details.
