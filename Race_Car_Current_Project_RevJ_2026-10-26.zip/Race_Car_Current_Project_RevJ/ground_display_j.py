"""Presentation policy only: never reassign a sensor or isolation return."""

CHASSIS_NETS = {'VEHICLE_RETURN': 'W129', 'CHASSIS_GND': 'W015'}
CHASSIS_NODES = {'GP129-F', 'GP129-C', 'GP129-R'}

def is_chassis_edge(edge):
    return edge['net'] in CHASSIS_NETS

def is_structure_reference(edge):
    return is_chassis_edge(edge) and edge['a'] in CHASSIS_NODES and edge['b'] in CHASSIS_NODES

def glyph_segments(point, direction):
    """Three diminishing bars; the conductor terminates at the first bar."""
    x, y = point
    return [[[x-half, y+direction*offset], [x+half, y+direction*offset]]
            for half, offset in [(6, 0), (4, 4), (2, 8)]]
