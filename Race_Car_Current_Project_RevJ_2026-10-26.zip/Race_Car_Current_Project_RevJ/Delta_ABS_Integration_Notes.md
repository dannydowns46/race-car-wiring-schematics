# Delta ABS Gen 2 - schematic design inputs

Status: updated 2026-10-20 for Revision E. Haltech support confirms Delta CAN wheel speeds as the selected traction-control source, with Gen 2 protocol compatibility still to verify. No final circuit protection, wire sizing, installed Haltech configuration or C7 sensor compatibility established.

## Sources

- User-supplied `Delta ABS Gen 2 Pinout Allocation.pdf`: SCS Delta ABS Gen 2 Rev. 3, one page.
- User-supplied `ABS_Manual_Generation2_v3.pdf`: cover states Version 2 (Gen 2), 14/12/23; 25 pages. Filename and printed version differ.
- https://www.deltaabs.com/pages/downloads - identifies Generation 2 as current documentation.
- https://www.deltaabs.com/pages/faq - states compatibility with traditional distribution and solid-state PDMs; this does not establish Nexus R3 output capacity.

## Main connector: Bosch 1928405167, 38 pins

| Function | Pin(s) | Document specification |
|---|---|---|
| Pump battery supply | 1 | Labelled 40 A; not a measured continuous load |
| Other battery supply | 13 | Labelled 25 A; protection sizing still to confirm |
| Ignition wake | 28 | Ignition wakeup switch |
| Pump / power grounds | 25 / 38 | Pinout says direct to battery negative |
| CAN 1 | 33 H, 20 L | Mapping to external interface needs confirmation |
| CAN 2 | 26 H, 14 L | Mapping to external interface needs confirmation |
| Front-left speed | 19 signal, 8 return | Two-wire Hall, 7/14 mA |
| Front-right speed | 34 signal, 4 return | Two-wire Hall, 7/14 mA |
| Rear-left speed | 31 signal, 18 return | Two-wire Hall, 7/14 mA |
| Rear-right speed | 32 signal, 29 return | Two-wire Hall, 7/14 mA |
| Pressure sensor supply | 6 | 5 V, 200 mA maximum for VREF2 |
| Pressure signals | 36 front, 37 rear | Sensor connector pin assignments not supplied here |
| Sensor grounds | 9, 23 | Confirm actual harness allocation |
| Slip selector | 5 supply, 22 signal, 7 return | 5 V supply, 200 mA max; 0-5 V signal |
| ABS enable | 35 | System active when switched to ground |
| Warning / active / brake outputs | 10 / 3 / 15 | 0.75 A open collector |

## Vehicle interface: DTM06-12S (manual pp. 21-22)

1 ground; 2 CAN L; 3 CAN H; 4 ABS active; 5 brake light; 6 speedometer;
7 FL wheel speed; 8 FR wheel speed; 9 RL wheel speed; 10 RR wheel speed;
11 unused; 12 auxiliary 12 V output for sensors.

Outputs on pins 4-10 are specified as 0.75 A open collector. Treat the brake output as a control signal pending lamp load and input-interface design. Auxiliary supply current capability is not stated here. Public CAN has no termination resistor fitted at this interface. Final termination depends on the complete network topology.

## CAN integration (manual p. 23)

- Public bus selectable at 500 kbit/s or 1 Mbit/s.
- 0x24A exports four wheel speeds; 0x5C0 exports pressures, slip position, brake-light state and ABS status; 0x560 exports brake-balance data.
- Manufacturer DBC available by request. Owner-supplied Haltech support reply confirms an existing Delta ECU option and successful CAN traction-control installations. Verify Gen 2 compatibility with the installed NSP profile; exact update rate/latency remain unverified.
- CAN slip selection: 0x24C, unsigned 8-bit field starting at bit 0, values 1-10, at least 5 Hz. Confirm complete frame/DLC and firmware requirements before implementation.
- Physical and CAN slip selectors are alternatives, not simultaneous controls. Invalid CAN selector data disables ABS according to the manual. Timeout behavior requires confirmation.
- Separate physical ABS enable/disable switch is documented. CAN slip selection does not establish a replacement for every physical control.

## Design implications

- Manual pp. 6 and 13 describe two included master-cylinder pressure sensors; rear installation is optional for brake-bias measurement. Plan both for this car, subject to actual kit contents.
- Selected Revision E architecture: wheel sensors feed Delta only; public CAN feeds R3 CAN2 for traction-control wheel speeds. R3 SPI3-6 and public pulse outputs remain unused. Gen 2 profile/bitrate/termination and commissioned speed/fault behavior require verification.
- Include the supplied yaw/IMU sensor, warning lamp and enable switch in the ABS subsystem inventory.
- Manual p. 21 lists 10-18 V supply, pump 280 W, control solenoids 150 W, electronics 10 W. These figures do not establish starting-current peaks or final PDM trip settings.
- Preserve the supplied ABS harness as the draft integration boundary; manual p. 7 states harness modification voids warranty. This is manufacturer guidance, not a user instruction or authorization to change hardware.

## Unresolved items

1. User identifies front sensors as GM 22742183. GM's catalog identifies this number as the 2014-2019 Corvette front driver-side sensor: https://parts.gmparts.com/product/gm-genuine-parts-front-driver-side-wheel-speed-sensor-22742183 . Record the user's intended part; confirm whether both front corners use this same assembly in the custom installation. Sensor polarity and signal format remain unverified: no manufacturer electrical specification confirming conventional 7/14 mA operation was located in this review. Manual p. 10 specifically requires conventional two-wire 7/14 mA Hall sensors and excludes intelligent active sensors and VR types. Do not mark compatibility approved or assign sensor connector cavities from the part number alone.
2. Ground discrepancy: manual p. 7 says chassis ground for loom ring terminal; pinout says battery negative for pins 25 and 38. Obtain manufacturer clarification for this harness revision.
3. Interface discrepancy: table of contents says DTM06-4S, while section 6.3 and its 12-pin table say DTM06-12S. Verify physical harness.
4. Confirm which main-connector CAN pair connects to the public interface; do not assign the Haltech bus to CAN 1 or CAN 2 based only on numbering.
5. Nexus R3 channel capacity, aggregate current, ABS inrush, protection and power sequencing before assigning ABS supplies to PDM outputs.
6. Exact harness/firmware revision, included pressure sensors, manufacturer DBC, C7 compatibility confirmation and chosen keypad's CAN transmit capability.

## Revision E support evidence

Owner supplied a Haltech support email screenshot recommending CAN wheel speeds for traction control and confirming an existing Delta option, conditional on Gen 2 retaining protocol compatibility. Preserved at `Race_Car_RevE/Sources/Haltech_Delta_CAN_Support_Response.png`. See sheet 15 and the current README for setup requirements and spare I/O counts. No raw sensor sharing or direct pulse-output wiring is added.
