from render_physical_j import render
if __name__ == "__main__": render("full")
