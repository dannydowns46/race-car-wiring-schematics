# Race car wiring - Revision I, 23 October 2026

Revision I is current. H and the 22 October audit are preserved as history. The owner requested all proposed master-cutoff and branch-protection changes. I implements the drawing architecture and portable control/protection specification. It is still a design-review draft: unknown physical ratings, measured currents and installed NSP settings are not represented as verified.

## Implemented electrical changes

- U2 is CARTEK X-Pro, documented manual rev1.1. Its M8 stud is the only vehicle connection to BT1 negative. The case bonds to chassis. All ECU/PDM/load negative returns move from W002/BATT_NEG to W129/VEHICLE_RETURN, on the chassis side of isolation. Engine/chassis straps and all four PD16 grounds remain explicit. Ground-output pins A10/A11 and sensor returns remain distinct; they are not tied to the new return bus as added wires.
- U2 DT controls:1 internal black;2 external normally-closed kill loop to chassis;3 engine-stop/run output;4 internal red. S40 is a dedicated latching internal switch; S41 is the external NC kill switch. The vendor LED switch is polarised and must not be powered independently. Either emergency switch operates without the CAN keypad.
- K1 is TE EV200AAANA/1618002-7, normally-open DC contactor. A1 is the positive main input from F0; A2 is the switched LOAD POSITIVE, not battery negative. Red coil lead takes U2:3, black returns to VEHICLE_RETURN. U2:3 also supplies S1 -> R3 A13; R3 A26 is now NC so it cannot bypass the stop signal. K1 physically removes all R3, PD16, ABS and starter-driver positive feeds even if their software does not respond. This is CARTEK's main-engine-relay method plus a parallel ignition-input stop path.
- CARTEK engine-stop limit: specify5A, replacing its20A factory default. F4 is a5A control-feed fuse located near battery positive; proposed18AWG automotive control supply/return, with actual vendor switch/coil leads retained and assessed separately. EV200 published coil maximum3.8A for130ms, average0.13A hold at12V; verify combined A13/coil pull-in and F4's actual clearing curve. No external flyback diode is added: selected contactor has internal economizer/suppression. Its9V pickup/7.5V hold and release timing require actual cranking/shutdown checks.
- Positive distribution: BT1+ -> F0 -> K1 A1/A2 -> W003/MAIN_ISOLATED -> F1/R3, F50/PD16, F41/F42/ABS and F5/starter driver. BT1+ -> F2 -> starter B+; alternator B+ -> F3 -> BT1+. F4 supplies U2 M4 permanently. Starter and alternator positives remain battery-connected with negative isolation OFF, so cover/protect/rout them accordingly. F0/F1/F2/F3/F5/F50 values remain release holds rather than invented amp ratings. Assess alternator cable energization from both ends.
- Lift1 M3 retains R3 E4/W073 LIFT_SUPPLY; lift2 M4 moves to PD16 B4/W132 LIFT2_SUPPLY. Each has independent electronic protection and command/diagnostics. Injector and coil positive banks remain on R3 E1/E2, conditional on protection coordination with every branch/pigtail/contact. No removed injector/coil/lift fuses are restored; no outputs are paralleled.
- Moving a fuel pump to PD16 makes its wake/CAN behavior important. PD16 A25 now has dedicated R3 HBO6/A25/W131. ABS ignition uses R3 HBO3/A21/W130 through retained F43. Cockpit HBO4 no longer powers either critical wake feed. Programme PD16 pump CAN-loss default OFF and inhibit engine operation on a critical fuel-channel trip or invalid PD16 communication; exact available status channels/timeouts must be confirmed in the installed NSP version.
- Owner-confirmed crank GM12703627 remains A->R3 C1, B->C26, C->C25. Cam GM12591720 is now explicitly A->C25 regulated5V, B->C26, C->C3 Home+. The old W079 cam-supply placeholder is retired; W078 remains retired. Source differences between OEM5V application and other ECU12V applications remain documented. Confirm physical mating orientation, current and Hall configuration before power.
- Pressure sensors retain labelled supplied Delta loom connections. W112 depicts supplier-internal return continuity with unknown internal cavity; it is not an instruction to add a chassis ground or a Haltech wire. The supplier assembly boundary supersedes A02's literal new-harness interpretation. The published wheel-speed broadcast is corrected to100Hz, separate from unmeasured end-to-end traction-control latency.

## What these files do not establish

PD16 CAN branch construction is critical: connect CANH, CANL and the specified low-current return to the common Haltech network, but keep PD16 A25/wake power exclusively on R3 HBO6. A standard four-wire CAN hub cable must not bridge PD16's dedicated positive feed to cockpit HBO4. Isolate/omit that shared power leg in the purpose-built harness and verify end-to-end continuity before connecting either controller. Never parallel the two outputs through cable power pins.

No vehicle was powered, no purchased/received CARTEK or contactor is claimed, and no NSP file was available to edit or flash. Current/voltage-drop tests, fuse selection, branch wire/contact ratings, cutoff timing and real fault behavior remain mandatory before fabrication/commissioning release. K1's500A catalog carry rating depends on specified conductors/temperature; it is not a selected main fuse or proof of this installation's thermal rating. The actual starter must stay within CARTEK limits (650A cranking/2000A surge). CARTEK manual and product page differ on maximum operating temperature (manual+100C versus page+85C); use the stricter+85C installation limit pending confirmation.

Haltech's always-connected battery guidance is retained for normal operation: use S1/A13 for ordinary wake/run handling, not repeated K1 power cycling. Emergency master isolation is a separate function. Verify this integration against the supplied hardware, including service laptop/USB and charger connections. Follow CARTEK's charger/booster instructions at battery posts; do not create a ground bypass through equipment.

## Protection and commissioning files

- `Protection_Schedule.tsv`: each electronic channel and physical feeder; programmable settings are distinguished from fixed HBO hardware limits. Numerical thresholds not established by evidence remain UNRELEASED.
- `Branch_Coordination.tsv`: every injector, coil, pump, lamp and accessory branch, including OEM pigtails, with blank measurement/contact/wire fields. Branch count is not a cutting-length schedule.
- `Control_Specification.json`: intended run/prime/stop, CAN loss, fault latching and ownership. It is a specification, not an importable or installed NSP tune.
- `Commissioning.tsv`: acceptance evidence and controlled fault tests. No rows are marked passed without hardware evidence.
- `Audit_Disposition.tsv`: disposition of all14 H findings. Architectural changes and documentation corrections are separated from unresolved hardware checks.
- `Net_Revision_Record.json`: retained/renamed IDs and retired interfaces. Never reuse W006/W007/W024/W031/W078/W079.

## Validation and portable build

I has18 sheets,92 parts,116 named nets,391 modeled pins,333 connected endpoints and58 NC pins. `validate-revi.py` checks a fresh native KiCad export against a manually specified H-to-I endpoint transformation, safety-path contracts and schedules. The continuous validator independently recovers actual PDF conductor connectivity and preserves every source annotation. Passive symbols and these checks do not prove component operation, full electrical ERC or hardware safety.

Run `python rebuild_current.py --help`; current native source is `build-racecar-revi.js`, continuous view `build_single_page_i.py`. Do not run the historical prepare/finish/migration scripts as the normal build. Keep H, readable-name inputs, all I sheets/local library and both I PDF views in the portable project. Do not regenerate measured-data worksheets from migration scripts after entering evidence.

## Manufacturer evidence

- CARTEK manual1.1: `Sources/CARTEK_XPro_Manual_1.1.pdf`, recovered from its manufacturer's public download link. Exact DT pins and methods1/3 reviewed visually.
- https://www.cartekmotorsport.com/battery-isolator-x-pro/ and https://www.cartekmotorsport.com/downloads/.
- TE product1618002-7 and manufacturer EV200 catalog linked in `Sources/Revision_I_Source_Index.json`; live catalog supplies A1/A2 orientation, coil colors/economizer/current/voltage data. Original PDF download returned403 and is not claimed archived; extracted factual review record is included.
- https://www.te.com/en/product-1618002-7.html.
- Haltech R3 wiring/QSG and PD16 documents are retained in the inherited source library. CARTEK integration is the selected design, not an individualized manufacturer approval.

All inherited owner choices, sensor research and vendor documents remain available; current electrical allocations override older revisions. Outstanding DBW/pedal/coil/ABS compatibility and brake-lamp fallback issues are not closed by this revision.
