"""Fresh native export, exact I-to-J change boundary and retained safety contracts."""
from pathlib import Path
import json,csv,xml.etree.ElementTree as ET

r=Path(__file__).resolve().parent;d=r/'Race_Car_RevJ'
baseline=json.loads((r/'Race_Car_RevI/Design_Data.json').read_text())
data=json.loads((d/'Design_Data.json').read_text());parts={p['ref']:p for p in data['parts']}
xml=ET.parse(d/'preview/netlist.xml').getroot()
actual={n.attrib['name']:{(e.attrib['ref'],e.attrib['pin']) for e in n.findall('node')} for n in xml.findall('nets/net')}
nets={n['name']:{(e['ref'],e['pin']) for e in n['endpoints']} for n in data['nets']}
assert len(data['pages'])+1==len(xml.findall('design/sheet'))==19
assert len(parts)==len(xml.findall('components/comp'))==95
assert len(nets)==115
for n in data['nets']:assert actual[n['id']+'_'+n['name']]==nets[n['name']],n['name']
assert {k for k in actual if k.startswith('W')}=={n['id']+'_'+n['name'] for n in data['nets']}

# Explicit I-to-current-J boundary: B33 plus owner-selected shared starter/charging trunk.
expected={n['name']:{(e['ref'],e['pin']) for e in n['endpoints']} for n in baseline['nets']}
expected['PD16_SG'].add(('B33','A'))
expected['TRANS_TEMP_SIG']={('J40','21'),('B33','B')}
expected['BATT_RAW'].remove(('F3','1'))
expected['STARTER_FEED'].add(('F3','1'))
del expected['CUT_EXT_LOOP']
expected['CHASSIS_GND'].remove(('S41','2'))
for name,old,new in [('ISOLATOR_POS','M4','M6_BAT'),('ISOLATOR_INTERNAL_BLACK','1','BLACK'),('ISOLATOR_INTERNAL_RED','4','RED'),('WAKE_SOURCE','3','M6_IGN')]:
    expected[name].remove(('U2',old));expected[name].add(('U2',new))
expected['GT_EXTERNAL_BLUE_LOOP']={('U2','BLUE_A'),('U2','BLUE_B')}
expected['BATT_RAW'].update(('TB1',n) for n in ['BAT','F0','F2','F4'])
expected['MAIN_ISOLATED'].update(('TB2',n) for n in ['IN','F1','F50','F41','F42','F5'])
for ref,triggers in [('X111',{'B':7,'C':5,'F':3,'G':1}),('X113',{'B':2,'C':4,'F':6,'G':8})]:
    for terminal,name in [('A','ENGINE_GND'),('E','R3_SG'),('H','COIL_SUPPLY')]:expected[name].add((ref,terminal))
    for terminal,cylinder in triggers.items():expected['IGN_'+str(cylinder)].add((ref,terminal))
# Owner removes K1: F0 now feeds W003 directly. W128 retired, W003 renamed.
for endpoints in expected.values():endpoints.difference_update({('K1','A1'),('K1','A2'),('K1','RD'),('K1','BK')})
del expected['FUSED_MAIN_BUS']
expected['MAIN_FUSED_BUS']=expected.pop('MAIN_ISOLATED')
expected['MAIN_FUSED_BUS'].add(('F0','2'))
expected['START_CMD'].add(('D60','K'))
expected['VEHICLE_RETURN'].add(('D60','A'))
del expected['START_PERMIT']
expected['R3_SG'].remove(('S2','2'))
assert set(expected)==set(nets)
for name,endpoints in expected.items():assert nets[name]==endpoints,(name,nets[name]^endpoints)
ids={n['name']:n['id'] for n in data['nets']}
for n in baseline['nets']:
    if n['name'] not in ['CUT_EXT_LOOP','FUSED_MAIN_BUS','START_PERMIT']:assert ids['MAIN_FUSED_BUS' if n['name']=='MAIN_ISOLATED' else n['name']]==n['id'],n['name']
assert ids['TRANS_TEMP_SIG']=='W135'
assert ids['GT_EXTERNAL_BLUE_LOOP']=='W136'
assert not {n['id'] for n in data['nets']} & {'W004','W006','W007','W024','W031','W046','W078','W079','W128'}
assert set(parts)==({p['ref'] for p in baseline['parts']}-{'S41','S2','K1'})|{'B33','TB1','TB2','X111','X113','D60'}
old_parts={p['ref']:p for p in baseline['parts']}
for ref in old_parts:
    if ref in ['U2','S41','S2','K1']:continue # Explicit removed/changed interfaces checked below.
    old={p['num']:('MAIN_FUSED_BUS' if p['net']=='MAIN_ISOLATED' else p['net']) for p in old_parts[ref]['pins']}
    new={p['num']:p['net'] for p in parts[ref]['pins']}
    if ref=='J40':old['21']='TRANS_TEMP_SIG'
    if ref=='J11':old['5']=None
    if ref=='F3':old['1']='STARTER_FEED'
    if ref=='F0':old['2']='MAIN_FUSED_BUS'
    assert old==new,ref
for ref,part in parts.items():
    assert len(part['pins'])==len({p['num'] for p in part['pins']}),ref
    for p in part['pins']:
        if p['net'] is None:assert any(e=={(ref,p['num'])} for e in actual.values()),(ref,p)

def pin(ref,num,net):assert next(p['net'] for p in parts[ref]['pins'] if p['num']==num)==net,(ref,num)

# Selected isolated-coil starter relay; functional tags do not claim stamped pin numbers.
for num,net in [('PWR','START_DRIVER_FEED'),('OUT','START_SOL'),('CMD','START_CMD'),('GND','VEHICLE_RETURN')]:pin('U3',num,net)
assert '24059' in parts['U3']['technical_label'] and len(parts['U3']['pins'])==4
assert all('Functional stud tag' in p['status'] for p in parts['U3']['pins'])
pin('D60','K','START_CMD');pin('D60','A','VEHICLE_RETURN')
assert len(parts['D60']['pins'])==2 and '1N5408' in parts['D60']['technical_label']
relay=json.loads((d/'Starter_Relay.json').read_text())
assert relay['specification']['coil_V']==12 and relay['specification']['coil_resistance_ohm']==17.5
assert relay['specification']['contact_continuous_A']==85
assert relay['suppression']['K_banded_cathode']=='U3/CMD / W014'
assert relay['suppression']['A_unbanded_anode']=='U3/GND / W129'
assert {v['tag'] for v in relay['wiring']}=={'PWR','OUT','CMD','GND'}

# Manufacturer-specified single onboard wideband interface; sensor terminals remain functional until selected.
for num,signal in enumerate(['HTR_PLUS','INPUT','PUMP','NERNST','HTR_MINUS','CAL'],29):
    assert nets['WBO_'+signal]=={('J11',str(num)),('B9',signal)}
assert len([p for p in parts.values() if any(x['net'] and x['net'].startswith('WBO_') for x in p['pins'])])==2
for signal in parts['B9']['pins']:assert signal['status']=='TBD cavity'
for ref,channel in [('B32','OIL_TEMP_SIG'),('B33','TRANS_TEMP_SIG')]:
    pin(ref,'A','PD16_SG');pin(ref,'B',channel)
pin('J40','20','OIL_TEMP_SIG');pin('J40','21','TRANS_TEMP_SIG');pin('J40','11','PD16_SG')
assert nets['PD16_SG']=={('J40','11'),('B32','A'),('B33','A')}
for num in ['27','28']:pin('J40',num,None)

# Retain Revision I's hardwired stop, power boundaries and independent critical feeds.
for num,net in [('BLACK','ISOLATOR_INTERNAL_BLACK'),('BLUE_A','GT_EXTERNAL_BLUE_LOOP'),('BLUE_B','GT_EXTERNAL_BLUE_LOOP'),('M6_IGN','WAKE_SOURCE'),('RED','ISOLATOR_INTERNAL_RED'),('M8','BATT_NEG'),('M6_BAT','ISOLATOR_POS'),('CASE','CHASSIS_GND')]:pin('U2',num,net)
assert len(parts['U2']['pins'])==8
assert nets['GT_EXTERNAL_BLUE_LOOP']=={('U2','BLUE_A'),('U2','BLUE_B')}
assert nets['ISOLATOR_INTERNAL_RED']=={('U2','RED'),('S40','1')}
assert nets['ISOLATOR_INTERNAL_BLACK']=={('U2','BLACK'),('S40','2')}
assert 'NC' in parts['S40']['technical_label'] and 'B00NTT91Y0' in parts['S40']['technical_label']
assert all(p['status']=='Functional terminal' for p in parts['S40']['pins'])
assert all('Functional lug identity' in p['status'] for t in ['TB1','TB2'] for p in parts[t]['pins'])
control=json.loads((d/'Control_Specification.json').read_text())['physical_master']
assert control['U2_engine_stop_limit_A']==40 and control['F4_A']==5
assert 'fixed' in control['U2_engine_stop_limit_type'] and 'NONE' in control['external_switch']
for num,net in [('13','R3_WAKE'),('21','ABS_IGN_SOURCE'),('25','PD16_WAKE'),('26',None)]:pin('J10',num,net)
pin('J40','25','PD16_WAKE');pin('J41','4','LIFT2_SUPPLY');pin('J12','4','LIFT_SUPPLY')
for num,net in [('A','CRANK_SIG'),('B','R3_SG'),('C','R3_REF5')]:pin('B1',num,net)
for num,net in [('A','R3_REF5'),('B','R3_SG'),('C','CAM_SIG')]:pin('B2',num,net)
assert nets['BATT_NEG']=={('BT1','-'),('U2','M8')}
assert nets['WAKE_SOURCE']=={('U2','M6_IGN'),('S1','1')}
assert nets['MAIN_FUSED_BUS']=={('F0','2'),('F1','1'),('F41','1'),('F42','1'),('F50','1'),('F5','1')}|{('TB2',n) for n in ['IN','F1','F50','F41','F42','F5']}
assert nets['BATT_RAW']=={('BT1','+'),('F0','1'),('F2','1'),('F4','1')}|{('TB1',n) for n in ['BAT','F0','F2','F4']}
assert nets['STARTER_FEED']=={('F2','2'),('M1','B+'),('F3','1')}
assert nets['ALT_BPLUS']=={('F3','2'),('G1','B+')}
routing=json.loads((d/'Starter_Alternator_Routing.json').read_text())
for entry in routing['net_endpoints']:
    assert ids[entry['name']]==entry['id']
    assert nets[entry['name']]=={tuple(p) for p in entry['endpoints']}
assert routing['common_junction']=={'ref':'M1','terminal':'B+','physical_terminal':'battery-side main stud'}
assert routing['raw_block_connections']==['BT1/+','F0/1','F2/1','F4/1']
assert routing['switched_block_connections']==['F0/2','F1/1','F50/1','F41/1','F42/1','F5/1']
assert routing['release_status']=='HOLD - actual cable/fuse/stud and powered verification pending'
assert not set(parts)&{'F21','F22','F23','F24','F31','F32'}
assert 'S2' not in parts and 'START_PERMIT' not in nets
pin('J11','5',None)
assert 'SPI1 / SPARE' in next(p['func'] for p in parts['J11']['pins'] if p['num']=='5')
assert sum(len(p['pins']) for p in parts.values())==414
assert sum(len(n) for n in nets.values())==354
assert sum(p['net'] is None for part in parts.values() for p in part['pins'])==60
for ref,triggers in [('X111',{'B':7,'C':5,'F':3,'G':1}),('X113',{'B':2,'C':4,'F':6,'G':8})]:
    pin(ref,'A','ENGINE_GND');pin(ref,'E','R3_SG');pin(ref,'H','COIL_SUPPLY');pin(ref,'D',None)
    for terminal,cylinder in triggers.items():pin(ref,terminal,'IGN_'+str(cylinder))
    assert len(parts[ref]['pins'])==8 and all('GM reference cavity' in p['status'] for p in parts[ref]['pins'])
assert not nets['INJECTOR_SUPPLY']&nets['COIL_SUPPLY']
with (d/'Connections.tsv').open(newline='',encoding='utf-8-sig') as f:rows=list(csv.DictReader(f,delimiter='\t'))
assert {(v['Net_ID'],v['Net_Name'],v['Reference'],v['Pin_or_Function_ID']) for v in rows}=={(n['id'],n['name'],e['ref'],e['pin']) for n in data['nets'] for e in n['endpoints']}
with (d/'IO_Audit.tsv').open(newline='',encoding='utf-8-sig') as f:io=list(csv.DictReader(f,delimiter='\t'))
for row in io:
    p=next(v for v in parts[row['Interface']]['pins'] if v['num']==row['Cavity'])
    assert row['Channel / function']==p['func'] and row['Net']==(p['net'] or 'SPARE')
pd16_avi=[row for row in io if row['Interface']=='J40' and row['Cavity'] in ['20','21','27','28']]
assert len(pd16_avi)==4 and sum(row['Allocation']=='UNASSIGNED' for row in pd16_avi)==2
report={'result':'PASS - fresh native export, explicit I-to-current-J regression and GT-only / retained-stock-harness contracts','sheets':19,'components':95,'all_pins':414,'connected_pin_endpoints':354,'unused_pins':60,'named_nets':115,
 'checks':['Fresh KiCad named nets and I/O/connection schedules match the authoritative model.',
 'I-to-J changes: B33, F3/1 on W011, GT interface replacing X-Pro and external S41, blue pair on new W136, proposed common-bus TB1/TB2 ports. Exact endpoint transformation verified.',
 'Shared starter/charge trunk and separate fused alternator branch match the routing record; raw block has four connections and switched block six.',
 'Stock L94 X111/X113 bank interfaces added on sheet 19; fourteen native endpoints and two unavailable D positions added, with all existing device assignments and W IDs retained. Reference cavities remain donor-verification holds.',
 'Exactly one wideband sensor B9 uses R3 onboard WBI1/C29-C34; existing six net IDs preserved.',
 'U3 selected as Cole Hersee 24059 with four functional stud tags. D60 cathode on W014 CMD, anode on W129 return; no new electrical net or ECU allocation.',
 'Owner removes S2 clutch/neutral switch, C076/C123 and W046 START_PERMIT. R3 C5/SPI1 is unconnected/spare; no jumper or replacement neutral switch inferred.',
 'Existing engine-oil temperature remains PD16 A20/AVI1; two PD16 AVIs remain spare.',
 'Retained net IDs preserved; W004 retired with old external-to-chassis loop, never reused. GT M6_IGN controls S1/A13; K1 removed, F0 feeds TB2 on renamed W003 MAIN_FUSED_BUS; W128 retired; blue loop never grounds chassis. No external S41.',
 'GT fixed40A output distinguished from proposed F4 5A; actual GT variant, NC contact markings and block hardware ratings remain holds.',
 'Documented ECU/PD16/sensor cavities remain distinct from unselected wideband sensor terminals.'],
 'limits':['No installed NSP calibration or powered testing performed.',
 'Exact wideband sensor/adapter, exhaust position and sensor-side terminal map remain unselected.',
 'Transmission mechanical mounting, calibration checks, alarm thresholds and CAN failure behavior require commissioning.',
 'All earlier protection, wire/contact rating, physical harness and safety release holds remain applicable.']}
(d/'Validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
