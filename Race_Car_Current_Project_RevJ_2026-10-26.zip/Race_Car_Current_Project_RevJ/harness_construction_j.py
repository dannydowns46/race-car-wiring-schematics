"""Audit build-work classification without changing electrical topology."""
from pathlib import Path
import json
from collections import Counter
from wiring_work_j import construction_map,WORK_CLASSES,CONSTRUCTION

def audit(top):
 records=construction_map();edges={e['id']:e for e in top['connections']}
 assert records.keys()==edges.keys(),'Construction map must cover every retained connection exactly once'
 assert all(v['code'] in WORK_CLASSES for v in records.values())
 assert records['C066']['code']=='F' and records['S048']['code']=='S'
 assert records['C028']['code']=='F' and records['S078']['code']=='S'
 assert all(records['S%03d'%i]['code']=='S' for i in range(1,28))
 assert records['C158']['code']=='U' and records['U001']['code']=='U'
 assert records['C023']['code']=='C' and records['C024']['code']=='C'
 assert all(records['C%03d'%i]['code']=='F' for i in range(194,198))
 for e in edges.values():
  refs={e[k].split('/')[0] for k in ['a','b']}
  if e['kind']=='C' and refs&{'J10','J11','J12','J40','J41'}:assert records[e['id']]['code']=='F'
 assert all(records[e['id']]['code']==e['kind'] for e in edges.values() if e['kind'] in ['I','B','V'])
 return {'result':'PASS','connections':len(records),'construction_counts':dict(Counter(v['code'] for v in records.values())),
         'electrical_changes':False,'limits':['LEAD spans can require extensions/adapters/end work; actual harness revisions and reach unverified.',
          'MAKE paths beyond joints can use suitable supplied branch leads after inspection.',
          'Delta IMU/private CAN cavities and switch conflict remain supplier holds.']}

if __name__=='__main__':
 from physical_topology_j import load_and_audit
 _,top=load_and_audit();report=audit(top)
 (CONSTRUCTION.parent/'Harness_Construction_Validation.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report,indent=2))
