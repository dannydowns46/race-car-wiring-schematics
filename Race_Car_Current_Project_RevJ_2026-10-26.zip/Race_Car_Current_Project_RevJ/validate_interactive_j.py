"""Verify the packaged offline viewer against current native/physical/PDF sources."""
from pathlib import Path
from html.parser import HTMLParser
from collections import defaultdict
import json,base64,hashlib,subprocess,shutil,re,zipfile,xml.etree.ElementTree as ET
from physical_topology_j import R,D,load_and_audit

class Scripts(HTMLParser):
 def __init__(self):super().__init__();self.current=None;self.data='';self.code='';self.remote=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if tag=='script':self.current='data' if a.get('id')=='wiring-data' else 'code'
  for k in ['src','href']:
   if a.get(k,'').startswith(('http:','https:','//')):self.remote.append(a[k])
 def handle_endtag(self,tag):
  if tag=='script':self.current=None
 def handle_data(self,value):
  if self.current=='data':self.data+=value
  elif self.current=='code':self.code+=value

def validate():
 from wiring_work_j import WORK_CLASSES,CONSTRUCTION,work_info
 from harness_construction_j import audit as audit_construction
 native,top=load_and_audit();out=R/'Race_Car_RevJ_Interactive';path=out/'Race_Car_RevJ_Interactive.html'
 parser=Scripts();parser.feed(path.read_text(encoding='utf-8'));embedded=json.loads(parser.data)
 assert not parser.remote,'Viewer requires a network resource'
 assert embedded['connections']==top['connections'];assert embedded['parts']==native['parts'];assert embedded['nets']==native['nets'];assert embedded['nodes']==top['nodes']
 assert embedded['assemblies']==top['assemblies']
 assert embedded['workClasses']==WORK_CLASSES
 assert embedded['construction']==json.loads(CONSTRUCTION.read_text(encoding='utf-8'))
 assert embedded['componentGuide']==json.loads((D/'Component_Guide.json').read_text(encoding='utf-8'))
 assert set(embedded['componentGuide']['components'])=={p['ref'] for p in native['parts']}
 for entry in embedded['componentGuide']['components'].values():assert len(entry['what'])>15 and all(len(entry[k])>30 for k in ['does','note'])
 assert not {'K1','S2'} & set(embedded['componentGuide']['components'])
 assert embedded['starterRelay']==json.loads((D/'Starter_Relay.json').read_text(encoding='utf-8'))
 assert embedded['componentGuide']['components']['U3']['wiring']==embedded['starterRelay']['wiring']
 assert 'explanation.wiring' in parser.code and 'explanation.suppression' in parser.code
 construction_report=audit_construction(top)
 assert embedded['stockHarness']==json.loads((D/'Stock_Engine_Harnesses.json').read_text())
 expected_ids={e['id'] for e in top['connections']}
 assert len(expected_ids)==284 and not expected_ids & {'C076','C123'}
 by_id={e['id']:e for e in top['connections']}
 assert (by_id['C213']['a'],by_id['C213']['b'],by_id['C213']['net_id'])==('U3/CMD','D60/K','W014')
 assert (by_id['C214']['a'],by_id['C214']['b'],by_id['C214']['net_id'])==('U3/GND','D60/A','W129')
 for mode,folder in [('full','Race_Car_RevJ_Single_Page'),('power','Race_Car_RevJ_Power_Only')]:
  view=embedded['views'][mode];source=json.loads((R/folder/'Drawing_Manifest.json').read_text())
  assert set(view['nets'])==set(source['selected_net_names'])
  routes={e['id']:e for e in view['routes']};assert len(routes)==len([e for e in top['connections'] if e['net'] in view['nets']])
  assert set(routes)=={e['id'] for e in top['connections'] if e['net'] in view['nets']}
  for route in source['routes']:
   e=routes[route['id']]
   for k in ['id','a','b','net','net_id','kind','points','color','paths','display']:assert e[k]==route[k],(mode,route['id'],k)
   assert e['assembly_id']==route.get('assembly_id')
  assert view['groundSymbols']==source['ground_symbols']
  assert len(view['groundSymbols'])==26
  for e in view['routes']:
   assert e['work']==work_info(e)
   assert e['points'][0] in view['endpointPositions'][e['a']]
   assert e['points'][-1] in view['endpointPositions'][e['b']]
   if e['display']=='chassis-structure-reference':assert e['paths']==[] and e['kind']=='B'
   if e['net_id'] in ['W002','W009','W026','W062','W085','W112','W124']:assert e['display']=='continuous' and e['paths']==[e['points']]
  svg=base64.b64decode(view['svg64']).decode();root=ET.fromstring(svg)
  assert root.tag.endswith('svg')
  assert float(root.attrib['width'])==view['imageBox'][2] and float(root.attrib['height'])==view['imageBox'][3]
  assert all(v.startswith(('#','data:')) for v in re.findall(r'(?:href|src)="([^"]*)"',svg))
  # Net tracing is bounded by the existing electrical net, never by visual
  # crossings, fuse/contact bodies, adjacent sensor grounds or CAN pair colors.
  bynet=defaultdict(set)
  for e in view['routes']:bynet[e['net_id']].add(e['id'])
  assert bynet['W011']=={'C023','C024'}
  assert len([e for e in view['routes'] if e['net_id']=='W001' and e['kind']=='C'])==4
  assert len([e for e in view['routes'] if e['net_id']=='W003' and e['kind']=='C'])==6
  assert not bynet['W011']&bynet['W001']
  if mode=='full':
   assert len([e for e in view['routes'] if e['net_id']=='W062' and e['kind']=='C'])==16
   assert len([e for e in view['routes'] if e['net_id']=='W062' and e['kind']=='S'])==10
   assert not bynet['W062']&bynet['W129']
   assert not bynet['W033']&bynet['W034']
  assert all(ref in view['placements'] for e in view['routes'] for ref in [e['a'].split('/')[0],e['b'].split('/')[0]])
 manifest=json.loads((out/'Source_Manifest.json').read_text())
 assert manifest['html_sha256']==hashlib.sha256(path.read_bytes()).hexdigest()
 assert manifest['topology_sha256']==hashlib.sha256((D/'Physical_Topology.json').read_bytes()).hexdigest()
 for mode,hashes in manifest['source_hashes'].items():
  for p,h in hashes.items():assert hashlib.sha256((R/p).read_bytes()).hexdigest()==h,p
 node=shutil.which('node');assert node,'Node is required for JS syntax verification'
 result=subprocess.run([node,'--check','-'],input=parser.code,text=True,encoding='utf-8',capture_output=True)
 assert result.returncode==0,result.stderr
 assert not re.search(r'\b(?:fetch|XMLHttpRequest|WebSocket)\s*\(',parser.code)
 with zipfile.ZipFile(out/'Race_Car_RevJ_Interactive_Viewer.zip') as z:
  assert z.read(path.name)==path.read_bytes();assert 'README.md' in z.namelist()
  import csv
  assigned=set()
  for name,codes in [('Wires_To_Provide.tsv',{'C'}),('Supplied_Leads_To_Finish.tsv',{'F'}),('Existing_Loom_And_Cable_Paths.tsv',{'S','V'}),('Other_Connection_References.tsv',{'I','B','U'})]:
   assert z.read(name)==(D/name).read_bytes()==(out/name).read_bytes()
   rows=list(csv.DictReader((D/name).open(encoding='utf-8'),delimiter='\t'))
   ids={r['ID'] for r in rows};assert len(ids)==len(rows)
   assert ids=={e['id'] for e in top['connections'] if work_info(e)['code'] in codes}
   assert not assigned&ids;assigned|=ids
  assert assigned==expected_ids
 report={'result':'PASS','source_revision':'J','date':'2026-10-25','native_electrical_change':False,'offline':True,
  'construction':construction_report,
  'selectable_connections_full':len(embedded['views']['full']['routes']),'selectable_connections_power':len(embedded['views']['power']['routes']),'native_nets_full':len(native['nets']),'native_nets_power':len(embedded['views']['power']['nets']),
  'checks':['Embedded part/pin/net/junction/connection metadata exactly matches maintained engineering models.',
   'Every routed path matches the validated physical PDF manifest; eight terminal-block internal links follow the drawn common metal.',
   'Visible vector art is embedded, cropped in memory from current source PDFs; endpoint coordinates align with that crop.',
   'Net groups preserve native boundaries: starter shared stud, positive blocks, R3 sensor return and CAN H/L independently verified.',
   'Stock X111/X113 interfaces and 56 retained OEM conductor paths match the audited topology; no retired direct-branch ID is reused or injector/coil supply bridge introduced.',
   'All 26 chassis ground symbols match validated PDF glyph/stub records. C214 is a local diode lead at U3 GND, not a second chassis landing. Structure bonds remain selectable without invented spanning wires; sensor, engine and isolated battery paths stay explicit.',
   'No external network resources or runtime requests required; ZIP contains byte-identical standalone HTML.',
   'Browser JavaScript passes Node syntax verification.'],
  'limits':['Interactive tracing is read-only and does not change the engineering design.','All physical hardware/route/material/fabrication holds remain open.','Browser interaction/visual QA is recorded separately in Browser_QA.json.']}
 (out/'Validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

if __name__=='__main__':validate()
