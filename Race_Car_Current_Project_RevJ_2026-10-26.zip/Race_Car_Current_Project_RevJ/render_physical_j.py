"""Render individual conductors and explicit joints over the unchanged J pin/net model."""
from pathlib import Path
from collections import defaultdict
import json,math,re,hashlib,shutil
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor,white
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.pdfbase import pdfdoc
from physical_topology_j import R,D,load_and_audit,schedules
from ground_display_j import CHASSIS_NODES,is_chassis_edge,is_structure_reference,glyph_segments
from wiring_work_j import WORK_CLASSES,route_label,work_info,CONSTRUCTION

COLORS={'power':'#B4232D','ground':'#49515B','signal':'#1769A7','drive':'#257044','can':'#8A35A6','hold':'#A36810'}
KINDS={'C':(1.1,None),'S':(1.1,[4,2]),'V':(2.1,None),'I':(.85,[5,3]),'B':(1.4,[8,3,1,3]),'U':(.95,[2,3])}
def category(n):
 if n.endswith('_TBD'):return 'hold'
 if n.startswith('WOLFBOX_') or ('CAN' in n and n[-1] in ['H','L']):return 'can'
 if any(s in n for s in ['GND','GROUND','RETURN','_RET','_SG','BATT_NEG']):return 'ground'
 if n in ['BATT_RAW','MAIN_FUSED_BUS','WAKE_SOURCE','R3_MAIN_POS','FUSED_MAIN_BUS','STARTER_FEED','ALT_BPLUS','START_DRIVER_FEED'] or any(t in n for t in ['_POS','SUPPLY','_PWR','_POWER','12V','_REF','_5V']):return 'power'
 if n.startswith(('IGN_','INJ_','DBW_M','START_')):return 'drive'
 return 'signal'
def wrap(t,width,size=10,font='Helvetica'):
 lines=[];line=''
 for word in t.split():
  test=(line+' '+word).strip()
  if line and stringWidth(test,font,size)>width:lines.append(line);line=word
  else:line=test
 if line:lines.append(line)
 return lines or ['']

def render(mode='full'):
 data,m=load_and_audit();schedules(m);full=mode=='full'
 out=R/('Race_Car_RevJ_Single_Page' if full else 'Race_Car_RevJ_Power_Only');out.mkdir(exist_ok=True)
 selected={n['name'] for n in data['nets']} if full else set(m['power_net_names'])
 nativeparts=[dict(p,pins=[x for x in p['pins'] if full or x['net'] in selected]) for p in data['parts'] if full or any(x['net'] in selected for x in p['pins'])]
 nets=[n for n in data['nets'] if n['name'] in selected]
 edges=[dict(e,work=work_info(e)) for e in m['connections'] if e['net'] in selected]
 nodes=[n for n in m['nodes'] if n['net'] in selected]
 # These I links are inside a real terminal block, not routed as external wires.
 inside=[e for e in edges if e['kind']=='I' and e['a'].split('/')[0]==e['b'].split('/')[0] and e['a'].startswith(('TB1/','TB2/'))]
 external=[e for e in edges if e not in inside]
 ground_edges=[e for e in external if is_chassis_edge(e)]
 structure=[e for e in ground_edges if is_structure_reference(e)]
 routed=[e for e in external if not is_chassis_edge(e)]
 incident=defaultdict(list)
 for e in external:
  incident[e['a']].append(e);incident[e['b']].append(e)
 items=[]
 for p in nativeparts:
  slots=[]
  for pin in p['pins']:
   endpoint=p['ref']+'/'+pin['num'];ee=incident[endpoint]
   for e in ee:slots.append({'endpoint':endpoint,'pin':pin['num'],'func':pin['func'],'status':pin['status'],'net':pin['net'],'connection':e['id']})
   if not ee:slots.append({'endpoint':endpoint,'pin':pin['num'],'func':pin['func'],'status':pin['status'],'net':pin['net'],'connection':None})
  label='PD16 internal termination / representation' if p['ref']=='J30' else p['value']
  items.append({'ref':p['ref'],'label':label,'technical':p.get('technical_label',''),'page':p['page'],'virtual':False,'slots':slots})
 for n in nodes:
  if n['id'] in CHASSIS_NODES:continue
  items.append({'ref':n['id'],'label':n['label'],'technical':n['status'],'page':None,'virtual':True,'kind':n['kind'],
   'slots':[{'endpoint':n['id'],'pin':'','func':e['id']+' to '+(e['b'] if e['a']==n['id'] else e['a']),'status':n['status'],'net':n['net'],'connection':e['id']} for e in incident[n['id']]]})
 pitch=16;LEFT=80;TOP=210;PH=244;GAP=20;GG=38
 for p in items:p['width']=math.ceil(max(158 if not p['virtual'] else 152,(len(p['slots'])+3)*pitch)/pitch)*pitch
 groups=[];rowitems={'top':[],'bottom':[]}
 top_pages=[2,3,4,5,6,14,16,18,19] if full else [2,18,3,4,19]
 bottom_pages=[7,8,9,10,11,13,17] if full else [8,9,11,7,10,6,13,16,17]
 for side,order in [('top',top_pages),('bottom',bottom_pages)]:
  for num in order:
   pp=[p for p in items if p['page']==num]
   if not pp:continue
   rowitems[side]+=pp;groups.append({'side':side,'page':num,'refs':[p['ref'] for p in pp]})
 def rowwidth(side):return sum(p['width']+GAP for p in rowitems[side])+GG*len([g for g in groups if g['side']==side])
 virtualgroups={'top':[],'bottom':[]}
 for p in [p for p in items if p['virtual']]:
  side=min(rowitems,key=rowwidth);rowitems[side].append(p);virtualgroups[side].append(p['ref'])
 for side,refs in virtualgroups.items():
  if refs:groups.append({'side':side,'page':None,'refs':refs})
 placements={};ports={};pairport={}
 for side in ['top','bottom']:
  x=LEFT
  for group in [g for g in groups if g['side']==side]:
   group['x']=x
   for ref in group['refs']:
    p=next(p for p in items if p['ref']==ref)
    p.update({'x':x,'side':side})
    for i,s in enumerate(p['slots']):
     s['x']=x+24+i*pitch+(8 if side=='bottom' else 0)
     key=ref+'@'+str(i);s['port']=key;ports[key]=s
     if s['connection']:pairport[(s['connection'],s['endpoint'])]=key
    placements[ref]=p;x+=p['width']+GAP
   group['width']=x-group['x']-GAP;x+=GG
 WIDTH=max(p['x']+p['width'] for p in items)+80
 assert WIDTH<14400,('Page too wide',WIDTH)
 # Interval tracks are wire routes, not electrical buses. Each polyline is one
 # conductor/assembly with exactly two ends and its own stable connection ID.
 tracks=[];routes=[];BUS_TOP=TOP+PH+230;TRACK=19
 for e in sorted(routed,key=lambda e:-abs(ports[pairport[(e['id'],e['a'])]]['x']-ports[pairport[(e['id'],e['b'])]]['x'])):
  a=pairport[(e['id'],e['a'])];b=pairport[(e['id'],e['b'])];x1=ports[a]['x'];x2=ports[b]['x'];lo,hi=sorted([x1,x2])
  track=next((i for i,spans in enumerate(tracks) if all(hi+90<l or h+90<lo for l,h in spans)),len(tracks))
  if track==len(tracks):tracks.append([])
  tracks[track].append((lo,hi));routes.append(dict(e,port_a=a,port_b=b,track=track,span=[lo,hi]))
 BOTTOM=BUS_TOP+len(tracks)*TRACK+230
 for p in items:
  p['y']=TOP if p['side']=='top' else BOTTOM
  for s in p['slots']:s['y']=p['y']+PH if p['side']=='top' else p['y']
 for e in routes:
  a=ports[e['port_a']];b=ports[e['port_b']];y=BUS_TOP+e['track']*TRACK
  e['points']=[[a['x'],a['y']],[a['x'],y],[b['x'],y],[b['x'],b['y']]]
  e['color']=COLORS['hold'] if e['kind']=='U' else COLORS[category(e['net'])]
  e['paths']=[e['points']];e['display']='continuous'
 # Replace only chassis returns with local stubs. The original electrical and
 # physical endpoints remain in every record. Engine, sensor, CAN and isolated
 # battery returns keep their original explicit routes.
 ground_symbols=[]
 for e in ground_edges:
  if is_structure_reference(e):continue
  paths=[];endpoints={};epports={}
  for end in ['a','b']:
   endpoint=e[end]
   if endpoint in CHASSIS_NODES:continue
   key=pairport[(e['id'],endpoint)];s=ports[key];p=placements[endpoint.split('/')[0]]
   direction=1 if p['side']=='top' else -1
   start=[s['x'],s['y']];anchor=[s['x'],s['y']+direction*108]
   remote=e['b'] if end=='a' else e['a'];gp=remote if remote in CHASSIS_NODES else 'CHASSIS'
   symbol={'id':e['id']+'-'+end,'connection':e['id'],'net':e['net'],'net_id':e['net_id'],
    'endpoint':endpoint,'remote_endpoint':remote,'ground_point':gp,'point':anchor,'direction':direction,
    'segments':glyph_segments(anchor,direction),'label':e['net_id']+' / '+gp}
   label_end=anchor[1]+direction*(19+stringWidth(symbol['label'],'Helvetica-Bold',6.8))
   symbol['bounds']=[anchor[0]-10,min(anchor[1],label_end)-4,20,abs(label_end-anchor[1])+8]
   ground_symbols.append(symbol);endpoints[end]=start;epports[end]=key
   paths.append([start,anchor] if end=='a' else [anchor,start])
   if remote in CHASSIS_NODES:endpoints['b' if end=='a' else 'a']=anchor
  points=[q for path in paths for q in path]
  routes.append(dict(e,port_a=epports.get('a'),port_b=epports.get('b'),points=points,paths=paths,
   display='chassis-ground-stub',color=COLORS['ground']))
 # The two proposed chassis-structure bonds are not additional field wires.
 # Keep them selectable as references to the already drawn ground symbols.
 for e in structure:
  a=next(g['point'] for g in ground_symbols if g['ground_point']==e['a'])
  b=next(g['point'] for g in ground_symbols if g['ground_point']==e['b'])
  routes.append(dict(e,port_a=None,port_b=None,points=[a,b],paths=[],display='chassis-structure-reference',color=COLORS['ground']))
 NOTES_TOP=BOTTOM+PH+140
 annotations=[];sourcefiles=[D/'Race_Car_RevJ.kicad_sch']+[D/(p['file']+'.kicad_sch') for p in data['pages']]
 scope=[
  'WHAT YOU BUILD: C / MAKE = connection you provide, using new wire or suitable reused donor wire/pigtail. S / LOOM = existing OEM/vendor loom wire; retain it. V / CABLE = intact supplied assembly to connect.',
  'Read MAKE / LEAD / LOOM / CABLE tags, not ID prefixes, for construction work. LEAD = supplied harness wire needing end work; MAKE = additional connection/branch to provide. Inspect actual grouped leads before adding wire.',
  'R3 HT-183200 and PD16 HT-188000 flying-lead harnesses are owner selected. Controller-side leads are supplied; free ends need routing/termination. Heavy main feeders and vehicle branches are separate. A drawn LEAD span can include an extension or adapter.',
  'Delta loom, sensor branches, two pressure plugs, slip/OFF switches, warning lamp, fused feeds and IMU/private CAN are supplied assemblies. Do not fabricate duplicate branches or add sensor grounds. IMU cavities remain supplier-internal/unmapped.',
  'Delta switch HOLD: current guide describes hardware solenoid-power interruption; historical pin35 ground-enable model is unresolved. C158 is HOLD, not a wire to make. Keep actual supplied switch loom intact pending revision verification.',
  'Delta F41/F42/F43 represent supplied loom protection: current guide lists pump40A/solenoid20A/ignition10A; older pinout labels a25A supply. Confirm received loom before final coordination. Public CAN uses auxiliary port; private four-pin port is service only.',
  'I / INTERNAL and B / BOND are not extra cut wires. U / HOLD is unresolved supplier construction. Wires_To_Provide.tsv and Supplied_Leads_To_Finish.tsv separate added wiring from lead end work; neither is a measured cut schedule.',
  'Each solid C line is one individual proposed field conductor with exactly two ends. Bends and white crossing breaks do not add wire ends. W identifiers still name electrical nets.',
  'S lines are individual supplied-loom conductor paths, retained within their supplier assembly; verify actual construction. V thick purple lines are intact multi-wire vendor cables, not single cut wires.',
  'Short black bars inside SP nodes denote explicit proposed splices; inside TB1/TB2 they denote conducting metal. Repeated same pin labels share one actual terminal/stud; they are not additional cavities.',
  'U3 is Cole Hersee 24059: large PWR from F5/2, large OUT to M1 small SOL; small CMD from R3 A18/HBO5 and small GND to GP129-C. These are installer tags, not stamped terminal numbers. Coil and contact supplies are separate.',
  'D60 1N5408 is local across U3 small coil studs: band/K to CMD via C213; unbanded/A to GND via C214. C213/C214 are insulated diode leads, not long harness cuts. The W129 ground-stub depiction of C214 does not require another chassis landing. Verify polarity and prompt disengagement.',
  'S2 clutch/neutral switch is removed by owner; C076/C123 and W046 retired. R3 C5/SPI1 is spare/unconnected, never jumpered. Actual start logic must omit that input requirement while retaining fresh request, engine-not-running, bounded crank and release controls.',
  'Dashed I lines denote internal device/supplier continuity; dash-dot B lines denote metal/lug/bond continuity. Neither is an extra cut wire. Dotted U lines remain unresolved supplier paths.',
  'Splice and ground-point positions, hardware, joining method, wire gauge/color, route, cut length and terminal parts are UNRELEASED. This diagram proposes connection topology, not measured vehicle geometry.',
  'Ground points GP129-F/C/R are proposed front/control/rear vehicle-side returns. Their metal/bond network must be verified; no extra field wire is specified by dash-dot structure paths.',
  'Chassis returns use short stubs and labelled ground symbols. Match W IDs; the graphic stub is not a measured cut length. GP129-F/C/R remain distinct proposed physical landing points on W129.',
  'B005 GP129-F to GP129-C and B006 GP129-C to GP129-R are proposed chassis metal/bond continuity, represented by the W129 ground references, not extra drawn field wires.',
  'W015 chassis/case bond references stay distinct from W129 return/strap terminals. No ground symbol is substituted for W002 isolated battery negative, W009 engine returns, sensor grounds, CAN returns or supplied Delta sensor returns.',
  'J2/J3 ground straps and J21 ground assembly have two ends joined by their own assembly bodies. Those bodies are depicted inside their boxes, not as additional field wires.',
  'CAN1 uses a proposed linear trunk R3 -> dash tap -> keypad tap -> TMS4 tap -> PD16. H/L pair IDs match each trunk/tap. J30 is the PD16 end-termination representation; no third resistor is added.',
  'TB1 four branch wires and TB2 six branch wires (incoming directly from F0) land at explicit functional lug ports. Actual stud/stack assignments and block ratings/boots remain open. M1 B+ has two wires on the same battery-side stud.',
  'Existing device pin/net assignments are retained. Stock L94 X111/X113 bank connector reference interfaces are added; functional device IDs do not imply inspected donor cavities.',
  'S paths marked OEM-COIL or OEM-INJ are retained donor-loom conductors, not new branch wires. OEM splice nodes depict shared continuity; exact internal locations, wire sizes and condition require inspection.',
  'Stock injector integration uses functional CUT-INJ boundaries, not an invented factory bulkhead plug. Isolate injector-only feed branches from factory coil/other loads; never bridge HCO1 and HCO2.',
  'Stock coil low-reference grounding remains HOLD: retained C26 routing is not final approval; resolve GM separate low reference versus Haltech generic head-ground advice with actual coil/R3 evidence.',
  'Use Physical_Connections.tsv for ID/from/to/kind/pair and blank measurement fields, Physical_Junctions.tsv for joint intent, and Physical_Topology.json as the maintained topology source. Never overwrite measured entries by re-initializing it.'
 ]
 annotations.append({'page':None,'title':'PHYSICAL CONDUCTOR VIEW - READ FIRST','body':scope})
 if full:
  for i,path in enumerate(sourcefiles):
   texts=[json.loads(t) for t in re.findall(r'\(text\s+("(?:\\.|[^"\\])*")\s+\(at',path.read_text())]
   title='System index' if i==0 else data['pages'][i-1]['title']
   annotations.append({'page':i+1,'title':title,'body':[t for t in texts if t!=title and not t.startswith('REV J  |')]})
 else:
  annotations.append({'page':None,'title':'POWER-SYSTEM SCOPE / RELEASE HOLDS','body':[
   'All 43 selected power/control/vendor-link nets are complete. Other component pins, sensor networks, CAN data and driver signals are omitted, not declared NC. See full continuous sheet for those conductors.',
   'GT M6_IGN -> S1 -> R3 A13 only. K1 removed by owner; F0 feeds TB2 directly on W003 MAIN_FUSED_BUS. Verify engine-stop, PD16 OFF/CAN-loss and GT timing; positive feeders remain connected.',
   'S40 is the single owner-ordered BAOMAIN latching NC stop, actual contact markings to verify. Blue/blue flying leads join at SP136; no external switch or chassis connection.',
   'TB1 is proposed Sierra FS46540 common M10 post. TB2 is proposed Summit SUM-900533; specific250A vs family150A listing conflict remains open. Verify allowed stacks, torque, covers and hot continuous duty.',
   'F2 shared trunk near battery -> M1 battery B+; separate wire same stud -> F3 near starter -> G1. F2/F3 retained, no removal authorized. Actual feeder fuse values/cable sizing and both-source fault checks remain open.',
   'PD16 A31-A34 each has an individual ground conductor. R3 A11 CAN return stays separate from vehicle grounds. Injector PWR branches return via omitted driver wiring; coil power grounds are included.',
   'WolfBox BATT/ACC are separate wires sharing one explicit switched-feed splice. Preserve regulated5V USB-C and rear-camera V assemblies. GPS/reverse lead unused; verify received kit and switched startup.',
   'R3/PD16 channel assignments, separate lift pumps, full-speed fan control and no injector/coil/lift bank fuses are unchanged. No actual NSP tune or powered testing is claimed.'
  ]})
 cols=4;ngap=36;nleft=32;nwidth=(WIDTH-64-(cols-1)*ngap)/cols;ys=[NOTES_TOP]*cols;nl=[]
 for panel in annotations:
  i=min(range(cols),key=lambda j:ys[j]);lines=[]
  for t in panel['body']:lines+=wrap(t,nwidth-30,11)+['']
  h=52+len(lines)*14;nl.append((panel,nleft+i*(nwidth+ngap),ys[i],h,lines));ys[i]+=h+22
 HEIGHT=max(ys)+100;assert HEIGHT<14400
 # New power filename also keeps an already-open earlier PDF from blocking updates.
 filename='Race_Car_RevJ_Continuous_Wiring.pdf' if full else 'Race_Car_RevJ_Power_Only_Physical_Wiring.pdf'
 c=canvas.Canvas(str(out/filename),pagesize=(WIDTH,HEIGHT),pageCompression=1)
 c.setTitle('Race Car Rev J - '+('Full' if full else 'Power Only')+' - Individual Physical Conductors')
 c.setAuthor('Race Car Wiring Schematic');c.setSubject('Proposed physical conductor topology, electrically equivalent to current native Revision J')
 ink='#182537';muted='#596778';border='#A9B7C8';segments=[];bonds=[];dots=[]
 def text(x,y,s,size=10,color=ink,font='Helvetica'):
  c.setFont(font,size);c.setFillColor(HexColor(color));c.drawString(x,HEIGHT-y,s)
 def line(a,b,color=ink,width=.7,dash=None,record=None):
  c.setStrokeColor(HexColor(color));c.setLineWidth(width);c.setDash(dash or []);c.line(a[0],HEIGHT-a[1],b[0],HEIGHT-b[1]);c.setDash([])
  if record is not None:record.append({'start':a,'end':b,'width':width,'color':color,'dash':dash or []})
 def rect(x,y,w,h,fill='#FFFFFF',stroke=border):
  c.setFillColor(HexColor(fill));c.setStrokeColor(HexColor(stroke));c.setLineWidth(.7);c.rect(x,HEIGHT-y-h,w,h,stroke=1,fill=1)
 def dot(x,y):
  c.setFillColor(HexColor(ink));c.setStrokeColor(HexColor(ink));c.setLineWidth(.6);c.circle(x,HEIGHT-y,1.8,stroke=1,fill=1);dots.append([x,y])
 def book(key,title,x,y):c.bookmarkPage(key,fit='XYZ',left=x,top=HEIGHT-y,zoom=1);c.addOutlineEntry(title,key,level=0,closed=True)
 def link(x,y,w,h,page):
  action=pdfdoc.PDFDictionary({'S':pdfdoc.PDFName('GoToR'),'F':pdfdoc.PDFString('Race_Car_RevJ_Flagged.pdf'),'D':pdfdoc.PDFArray([page-1,pdfdoc.PDFName('Fit')]),'NewWindow':pdfdoc.PDFtrue})
  c._addAnnotation(pdfdoc.PDFDictionary({'Type':pdfdoc.PDFName('Annot'),'Subtype':pdfdoc.PDFName('Link'),'Rect':pdfdoc.PDFArray([x,HEIGHT-y-h,x+w,HEIGHT-y]),'Border':pdfdoc.PDFArray([0,0,0]),'A':action}))
 book('start','START - Individual physical conductors',0,0)
 text(32,52,'RACE CAR | '+('FULL HARNESS' if full else 'POWER SYSTEMS ONLY'),34,font='Helvetica-Bold')
 text(32,81,'INDIVIDUAL PHYSICAL CONDUCTORS / REV J / 25 OCT 2026',19,font='Helvetica-Bold')
 counts={k:sum(e['kind']==k for e in edges) for k in KINDS}
 text(32,107,f'{len(nets)} native nets | {counts["C"]} field conductors | {counts["S"]} supplier paths | {counts["V"]} intact cable assemblies | {len(nodes)} explicit joint / ground nodes',14)
 text(32,132,'PROPOSED CONNECTION TOPOLOGY - unmeasured lengths, wire sizes, colors, terminals and splice hardware. NOT A FABRICATION RELEASE.',12,color=COLORS['hold'],font='Helvetica-Bold')
 x=2100
 for kind,label in [('C','FIELD PATH'),('S','SUPPLIED LOOM'),('V','VENDOR CABLE'),('I','INTERNAL'),('B','BOND / METAL'),('U','UNRESOLVED')]:
  width,dash=KINDS[kind];line([x,48],[x+40,48],COLORS['can'] if kind=='V' else ink,width,dash);text(x+48,52,kind+' / '+label,12);x+=260
 text(2100,81,'BUILD TAGS: MAKE = provide branch | LEAD = supplied wire, finish ends | LOOM = existing path | CABLE = intact cable | HOLD = verify',11,font='Helvetica-Bold')
 text(2100,105,'Black bars inside boxes are explicit splices/common metal/shared terminals. Crossings with white gaps never join.',12)
 text(2100,129,'Find by wire ID, net ID, component, joint or PDF bookmark. Click a component header for the complete native sheet.',12,color=muted)
 text(WIDTH-1400,52,f'VECTOR / SEARCHABLE | {WIDTH/72:.1f} x {HEIGHT/72:.1f} inches',14,font='Helvetica-Bold')
 text(WIDTH-1400,81,'Line geometry is illustrative; vehicle routes and cut lengths are unmeasured.',12,color=muted)
 # Horizontal conductor spans first, then unique vertical endpoint lanes with
 # white underlay at crossings. No central net-wide trunk or implied splice.
 for e in routes:
  if e['display']!='continuous':continue
  width,dash=KINDS[e['kind']];a,b=e['points'][1:3];line(a,b,e['color'],width,dash,segments)
 for e in routes:
  if e['display']!='continuous':continue
  width,dash=KINDS[e['kind']]
  for a,b in [(e['points'][0],e['points'][1]),(e['points'][2],e['points'][3])]:
   line(a,b,'#FFFFFF',4.1);line(a,b,e['color'],width,dash,segments)
 # The ID sits above the span; endpoint ID labels identify short spans too.
 for e in routes:
  if e['display']!='continuous':continue
  a,b=e['points'][1:3];w=abs(a[0]-b[0]);label=route_label(e)
  if w>100:
   xx=(a[0]+b[0])/2-stringWidth(label,'Helvetica-Bold',8)/2
   c.setFillColor(white);c.rect(xx-2,HEIGHT-a[1]+1,stringWidth(label,'Helvetica-Bold',8)+4,10,fill=1,stroke=0)
   text(xx,a[1]-3,label,8,e['color'],'Helvetica-Bold')
 for e in routes:
  if e['display']!='chassis-ground-stub':continue
  width,dash=KINDS[e['kind']]
  for path in e['paths']:
   for a,b in zip(path,path[1:]):line(a,b,e['color'],width,dash,segments)
 ground_segments=[]
 for g in ground_symbols:
  for a,b in g['segments']:line(a,b,COLORS['ground'],.9,record=ground_segments)
  x,y=g['point'];direction=g['direction']
  c.saveState();c.translate(x+3 if direction==1 else x-3,HEIGHT-(y+direction*19));c.rotate(270 if direction==1 else 90)
  c.setFont('Helvetica-Bold',6.8);c.setFillColor(HexColor(COLORS['ground']));c.drawString(0,0,g['label']);c.restoreState()
 pages={p['number']:p['title'] for p in data['pages']}
 for g in groups:
  y=TOP-48 if g['side']=='top' else BOTTOM+PH+12
  rect(g['x']-8,y,g['width']+16,36,'#E9EFF5')
  title=pages[g['page']] if g['page'] else 'EXPLICIT SPLICES / PROPOSED GROUND POINTS / SUPPLIER JOINS'
  lines=wrap(title,g['width']-16,10.5,'Helvetica-Bold')
  if len(lines)>2:lines=wrap(title,g['width']-16,8.2,'Helvetica-Bold')
  for j,t in enumerate(lines):text(g['x'],y+13+j*11,t,10.5 if len(lines)<=2 else 8.2,font='Helvetica-Bold')
 for p in items:
  ref=p['ref'];x=p['x'];y=p['y'];w=p['width'];side=p['side'];header=y if side=='top' else y+PH-82
  rect(x,y,w,PH,'#FFFCF4' if p['virtual'] else '#FDFEFE',stroke='#67768A')
  rect(x,header,w,82,'#FFF0CF' if p['virtual'] else '#E8EEF5',stroke='#67768A')
  text(x+8,header+18,ref,14,font='Helvetica-Bold')
  ll=wrap(p['label'],w-16,9.8,'Helvetica-Bold')
  assert len(ll)<=3,(ref,ll)
  for j,t in enumerate(ll):text(x+8,header+33+j*11,t,9.8,font='Helvetica-Bold')
  small=min(7.0,(w-16)/max(1,stringWidth(p['technical'],'Helvetica',1)))
  text(x+8,header+68,p['technical'],small,color=muted)
  if not p['virtual']:text(x+8,header+78,f'Native sheet {p["page"]:02d} / click header',6.8,color='#1A5DB2');link(x,header,w,82,p['page'])
  else:text(x+8,header+78,'Explicit join / no extra terminal numbers',6.7,color=COLORS['hold'])
  book('item_'+ref,ref+' - '+p['label'],x-15,y-35)
  # Every endpoint gets its own conductor attachment lane. Multiple lanes on
  # one native stud are joined only by an explicit short terminal bar inside.
  byendpoint=defaultdict(list)
  for s in p['slots']:
   px=s['x'];py=s['y'];byendpoint[s['endpoint']].append(s)
   label=s['func'].replace('_',' ');fs=min(7.7,134/max(1,stringWidth(label,'Helvetica',1)))
   c.saveState();c.translate(px+2.8,HEIGHT-(py-30 if side=='top' else py+30));c.rotate(90 if side=='top' else 270);c.setFont('Helvetica',fs);c.setFillColor(HexColor(ink));c.drawString(0,0,label);c.restoreState()
   if not p['virtual']:
    if stringWidth(s['pin'],'Helvetica-Bold',8)<pitch-3:text(px+2,py+(12 if side=='top' else -4),s['pin'],8,font='Helvetica-Bold')
    else:
     c.saveState();c.translate(px+2.7,HEIGHT-(py+(3 if side=='top' else -3)));c.rotate(270 if side=='top' else 90);c.setFont('Helvetica-Bold',7);c.setFillColor(HexColor(ink));c.drawString(0,0,s['pin']);c.restoreState()
   if s['connection']:
    e=next(e for e in external if e['id']==s['connection']);label=route_label(e)
    # Always rotate away from the body, giving long functional pin IDs room.
    offset=25 if is_chassis_edge(e) else 38;fs=6.8 if is_chassis_edge(e) else 7.2
    c.saveState();c.translate(px+(4 if side=='top' else -3),HEIGHT-(py+(offset if side=='top' else -offset)));c.rotate(270 if side=='top' else 90);c.setFont('Helvetica-Bold',fs);c.setFillColor(HexColor(COLORS[category(s['net'])]));c.drawString(0,0,label);c.restoreState()
   elif s['net'] is None:
    end=py+(23 if side=='top' else -23);line([px,py],[px,end]);line([px-2.3,end-2.3],[px+2.3,end+2.3]);line([px-2.3,end+2.3],[px+2.3,end-2.3])
   else:
    end=py+(23 if side=='top' else -23);line([px,py],[px,end],COLORS['hold'],.6,[2,2]);c.setFillColor(white);c.setStrokeColor(HexColor(COLORS['hold']));c.setLineWidth(.6);c.circle(px,HEIGHT-end,2.2,stroke=1,fill=1)
    c.saveState();c.translate(px-3,HEIGHT-(end+(9 if side=='top' else -9)));c.rotate(270 if side=='top' else 90);c.setFont('Helvetica',7);c.setFillColor(HexColor(COLORS['hold']));c.drawString(0,0,'HOLD - NO CUT WIRE');c.restoreState()
  common=p['virtual'] or ref in ['TB1','TB2']
  lists=[p['slots']] if common else [v for v in byendpoint.values() if len(v)>1]
  for slots in lists:
   yy=(y+PH-18) if side=='top' else (y+18)
   xs=[s['x'] for s in slots]
   if len(xs)>1:line([min(xs),yy],[max(xs),yy],ink,.65,record=bonds)
   for s in slots:
    line([s['x'],s['y']],[s['x'],yy],ink,.65,record=bonds);dot(s['x'],yy)
  if ref in ['J2','J3','J21']:
   ss=p['slots'];yy=y+PH-18 if side=='top' else y+18
   line([ss[0]['x'],yy],[ss[-1]['x'],yy],COLORS['ground'],4)
   for s in ss:line([s['x'],s['y']],[s['x'],yy],COLORS['ground'],4)
   text(x+8,(header+95 if side=='top' else header-14),'ASSEMBLY A-'+ref+' / body joins ends',6.8,color=muted)
 text(32,NOTES_TOP-58,'PHYSICAL CONNECTION NOTES / NATIVE DESIGN HOLDS',22,font='Helvetica-Bold')
 text(32,NOTES_TOP-32,'All new joint/ground locations and material choices remain proposed. Electrical endpoint sets are checked against the native KiCad export.',12,color=muted)
 for panel,x,y,h,lines in nl:
  rect(x,y,nwidth,h,'#FAFBFD');rect(x,y,nwidth,30,'#E8EEF5')
  text(x+14,y+20,panel['title'],12,font='Helvetica-Bold')
  for j,t in enumerate(lines):text(x+14,y+49+j*14,t,11)
  book('note_'+str(annotations.index(panel)),panel['title'],x,y-15)
  if panel['page']:link(x,y,nwidth,30,panel['page'])
 text(32,HEIGHT-48,f'REV J / PHYSICAL CONDUCTOR VIEW 01 | {len(nativeparts)} native component interfaces | {len(nets)} native nets | C{counts["C"]} / S{counts["S"]} / V{counts["V"]} / I{counts["I"]} / B{counts["B"]} / U{counts["U"]}',12,font='Helvetica-Bold')
 text(32,HEIGHT-25,'Connection topology is proposed and geometry is illustrative. No measured cut lengths, fabrication release, installed NSP settings or powered verification claimed.',11,color=muted)
 c.showPage();c.save()
 hashes=sourcefiles+[D/'Design_Data.json',D/'Physical_Topology.json',D/'Stock_Engine_Harnesses.json',D/'preview/netlist.xml',CONSTRUCTION,R/'wiring_work_j.py']
 manifest={'schema':'physical-conductors-v1','mode':mode,'pdf':filename,'page_size_points':[WIDTH,HEIGHT],'native_parts':nativeparts,'placements':placements,
  'routes':routes,'internal_block_links':inside,'conductor_segments':segments,'inside_joint_segments':bonds,'joint_dots':dots,'selected_net_names':sorted(selected),
  'ground_symbols':ground_symbols,'ground_symbol_segments':ground_segments,'chassis_structure_references':structure,
  'work_classes':WORK_CLASSES,
  'annotations':annotations,'counts_by_kind':counts,'source_hashes':{str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in hashes},
  'limits':m['holds'],'native_unchanged':True,'track_count':len(tracks)}
 (out/'Drawing_Manifest.json').write_text(json.dumps(manifest,indent=2))
 shutil.copy2(D/'preview/netlist.xml',out/'Source_Netlist.xml');shutil.copy2(D/'Race_Car_RevJ.pdf',out/'Race_Car_RevJ_Flagged.pdf')
 (out/'READ_ME.txt').write_text('CURRENT REVISION J / PHYSICAL CONDUCTOR VIEW 01 / 25 OCT 2026. Each C record is an individual proposed field wire with an ID and two endpoints. Chassis returns use short labelled ground-symbol stubs: match W IDs, use GP129-F/C/R for proposed physical landing points. Stub length is graphical, not a cut length. B005/B006 chassis structure is represented by W129 references, not extra cut wires. Sensor/CAN, engine and isolated battery returns remain explicit. S supplied-loom paths, V intact cable assemblies, I internal continuity, B metal/bond paths and U unresolved supplier paths are distinguished. W identifiers retain their electrical-net meaning. Use Physical_Topology.json and Physical_Connections.tsv under Race_Car_RevJ. All routing, gauges, lengths, physical joints, terminal hardware and fabrication release remain open. Keep adjacent native PDF for component-header links.\n')
 print(json.dumps({'mode':mode,'pdf':str(out/filename),'size_inches':[round(WIDTH/72,2),round(HEIGHT/72,2)],'native_nets':len(nets),'tracks':len(tracks),'counts_by_kind':counts},indent=2))
 return manifest

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--mode',choices=['full','power'],default='full');render(p.parse_args().mode)
