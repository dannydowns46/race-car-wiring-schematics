"""Render current native sheet contact sheet and changed sheet for human visual QA."""
from pathlib import Path
import json
import pymupdf as fitz
from PIL import Image,ImageDraw
r=Path(__file__).resolve().parent;out=r/'Race_Car_RevJ/preview';out.mkdir(exist_ok=True)
pdf=fitz.open(r/'Race_Car_RevJ/Race_Car_RevJ.pdf')
assert len(pdf)==19
thumbs=[]
for i,page in enumerate(pdf):
    pix=page.get_pixmap(matrix=fitz.Matrix(540/page.rect.width,540/page.rect.width),alpha=False)
    im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples)
    tile=Image.new('RGB',(560,420),'#e9edf1');tile.paste(im,(10,30));ImageDraw.Draw(tile).text((12,9),f'Sheet {i+1:02d}',fill='black');thumbs.append(tile)
contact=Image.new('RGB',(560*4,420*5),'#d3d9df')
for i,tile in enumerate(thumbs):contact.paste(tile,((i%4)*560,(i//4)*420))
contact.save(out/'All_Sheets_Contact.png')
pdf[4].get_pixmap(matrix=fitz.Matrix(2,2),alpha=False).save(out/'05_Engine_Sensors_Review.png')
pdf[2].get_pixmap(matrix=fitz.Matrix(1.7,1.7),alpha=False).save(out/'03_R3_Review.png')
for sheet in [1,2,3,4,6,7,8,9,10,11,12,13,15,16,18]:
    pdf[sheet-1].get_pixmap(matrix=fitz.Matrix(1.5,1.5),alpha=False).save(out/f'{sheet:02}_Changed_Review.png')
print('Rendered 19-sheet contact sheet and full changed J pages.')
continuous=r/'Race_Car_RevJ_Single_Page'
manifest=json.loads((continuous/'Drawing_Manifest.json').read_text())
cpdf=fitz.open(continuous/manifest['pdf'])
for ref in ['U2','TB2','M4','B9','B33','X111','X113']:
    pos=manifest['placements'][ref]
    clip=fitz.Rect(pos['x']-18,pos['y']-40,pos['x']+pos['width']+22,pos['y']+244+75)
    cpdf[0].get_pixmap(matrix=fitz.Matrix(2,2),clip=clip,alpha=False).save(continuous/'preview'/(ref+'.png'))
