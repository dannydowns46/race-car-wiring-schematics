"""Portable Revision J rebuild. Run from any working directory; no network required."""
from pathlib import Path
import argparse,shutil,subprocess,sys,json,os
r=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--node',default='node',help='Node executable/path, default PATH node')
p.add_argument('--kicad-cli',default=None,help='KiCad CLI executable; PATH or common Windows install locations searched by default')
p.add_argument('--check-only',action='store_true',help='Validate the included native export and continuous PDF without rebuilding')
a=p.parse_args()
log=[]
def run(args):
    print('Running: '+' '.join(str(v) for v in args),flush=True)
    result=subprocess.run([str(v) for v in args],cwd=r,text=True,capture_output=True)
    print(result.stdout,end='');print(result.stderr,end='',file=sys.stderr)
    log.append({'command':[str(v) for v in args],'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
    if result.returncode:raise SystemExit(result.returncode)
if not a.check_only:
    node=shutil.which(a.node) or (a.node if Path(a.node).is_file() else None)
    kicad=a.kicad_cli or shutil.which('kicad-cli')
    if not kicad and os.name=='nt':
        base=Path(os.environ.get('ProgramFiles','C:/Program Files'))/'KiCad'
        candidates=sorted(base.glob('*/bin/kicad-cli.exe'),reverse=True)
        if candidates:kicad=str(candidates[0])
    if not node:p.error('Node not found; install Node or supply --node with its executable path.')
    if not kicad:p.error('KiCad CLI not found; supply --kicad-cli with the installed executable path.')
    run([node,'--version']);run([kicad,'version'])
    run([node,r/'build-racecar-revj.js'])
    (r/'Race_Car_RevJ/preview').mkdir(exist_ok=True)
    sch=r/'Race_Car_RevJ/Race_Car_RevJ.kicad_sch'
    run([kicad,'sch','export','netlist','--format','kicadxml','-o',r/'Race_Car_RevJ/preview/netlist.xml',sch])
    run([kicad,'sch','export','pdf','-o',r/'Race_Car_RevJ/Race_Car_RevJ.pdf',sch])
    run([sys.executable,r/'finish-revj.py'])
run([sys.executable,r/'validate-revj.py'])
run([sys.executable,r/'physical_topology_j.py'])
if not a.check_only:run([sys.executable,r/'build_single_page_j.py'])
run([sys.executable,r/'validate_single_page_j.py'])
if not a.check_only:run([sys.executable,r/'build_power_systems_j.py'])
run([sys.executable,r/'validate_power_systems_j.py'])
if not a.check_only:run([sys.executable,r/'build_interactive_j.py'])
run([sys.executable,r/'validate_interactive_j.py'])
(r/'CURRENT_BUILD_LOG.json').write_text(json.dumps({'result':'PASS','mode':'check-only' if a.check_only else 'full rebuild','python':sys.version,'commands':log},indent=2))
print('PASS: Revision J native connectivity, both physical PDF views and offline interactive-viewer equivalence.')
