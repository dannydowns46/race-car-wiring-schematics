# Revision J - 23 October 2026

## Revision J - wideband and transmission temperature

- Owner selects exactly ONE wideband O2 sensor, directly controlled by the R3 onboard WBI1. B9 and its six WBO nets are retained: C29 HTR+, C30 INPUT, C31 PUMP, C32 NERNST, C33 HTR-, C34 CAL. Revision I already modeled a single sensor, so no second sensor/controller circuit existed to delete. No WB1/WB2, extra CAN branch, AVI or external heater feed is added.
- Exact wideband sensor/adapter is not selected. R3 supports Bosch LSU4.9 or NTK; use the matching hardware/adapter and NSP sensor selection. B9 terminals are functional labels, not confirmed sensor connector cavities. Confirm exhaust location and the tuner's single-sensor strategy; do not treat one measured exhaust stream as independent two-bank feedback. Keep supplied sensor calibration components/connector intact.
- B32 remains the engine-oil HT-010306 high-range 150C sensor: EV1 B signal -> PD16 A20/AVI1; A return -> PD16 A11.
- Added B33, a second HT-010306 high-range 150C sensor for transmission oil: EV1 B signal -> PD16 A21/AVI2, new W135/TRANS_TEMP_SIG; EV1 A -> existing W124/PD16_SG and PD16 A11.
- Configure independent Engine Oil Temperature and Transmission Oil Temperature channels. Each AVI uses its internal 1k pull-up and the full manufacturer `Temperature - Haltech Oil 150C 1/8 NPT HT010306.cal` calibration. No external 5V lead or accessory ground is added. Verify PD16-to-R3 sharing and actual installed firmware/configuration; no tune was supplied or edited.
- R3 spare capacity stays one AVI, four SPI and six DPO. PD16 now has TWO spare AVIs (AVI3/A27, AVI4/A28); all output reserves remain unchanged. No I/O expander is needed for this addition.
- Transmission sensor mounting/thread/immersion and mechanical clearance, operating-temperature range, reference-temperature verification, separate alarms/open/short diagnosis and stale-CAN behavior remain commissioning work. No temperature thresholds or protection actions are invented.
- All Revision I power, cutoff, split-pump and isolated CAN-power construction requirements remain in force. No change to installed-hardware or fabrication-release status.

# Revision I - 23 October 2026

CARTEK X-Pro/K1 master isolation; complete main/starter/alternator feeder paths; downstream vehicle returns; separate lift outputs; separate critical wake feeds; cam/crank identities and cam5V connection; 100Hz correction; protection/control/commissioning specifications. H retained. Counts18 sheets/92 parts/116 nets/391 pins/333 connected/58 NC. Numeric protection and hardware checkout remain release holds.

# Revision map

| Revision | Main change | State |
|---|---|---|
| H - current,22Oct2026 | Crank A/B/C, regulated5V from R3C25; W078 retired; installed-sensor S02 retained |17sheets,84parts,113nets |
| G -22Oct2026 | Onboard R3 MAP, removed external MAP; electronic protection replaces injector/coil/lift branch fuses; two separate tail/brake bulbs per side; shared head/tail hazards | Historical |
| F -21Oct2026 | iC-7 replaces uC-10; selected WolfBox kit and keypad camera control; TPMS/oil-temp/IAT/fuel-pressure integration and I/O audit | Historical |
| E -20Oct2026 | Delta public CAN wheel speeds selected for traction control; spare I/O and owner Haltech support evidence | Historical |
| D | HGT amplified shift-force knob on R3AVI11 | Historical |
| C | Novotechnik gear sensor on R3AVI10, regulated5V and sensor return | Historical |
| B | PD16HT-198100 and PROFORM67049 fans | Historical |
| A / Readable / initial example | Original functional harness draft and readability work | Historical |

Earlier README sections describe their own stage; some contain superseded equipment, fuse and capacity statements. Use H when statements conflict. Dates not recorded above should be read from the corresponding original project rather than inferred. Old ZIP duplicates are omitted from this transfer; their extracted project content is preserved.
