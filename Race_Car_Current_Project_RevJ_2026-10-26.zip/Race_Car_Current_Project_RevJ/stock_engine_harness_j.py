"""Audit maintained retained-OEM topology without rebuilding or overwriting it."""

def audit(data, model):
    from pathlib import Path
    import csv
    parts={p['ref']:p for p in data['parts']}
    edges=model['connections'];nodes={n['id']:n for n in model['nodes']}
    def linked(a,b,net,kind):
        found=[e for e in edges if {e['a'],e['b']}=={a,b} and e['net']==net and e['kind']==kind]
        assert len(found)==1,(a,b,net,kind)
        return found[0]
    for ref,bank,cylinders,pins in [('X111','ODD',[1,3,5,7],{'B':7,'C':5,'F':3,'G':1}),
                                  ('X113','EVEN',[2,4,6,8],{'B':2,'C':4,'F':6,'G':8})]:
        native={p['num']:p['net'] for p in parts[ref]['pins']}
        assert native=={'A':'ENGINE_GND','B':'IGN_'+str(pins['B']),'C':'IGN_'+str(pins['C']),
                        'D':None,'E':'R3_SG','F':'IGN_'+str(pins['F']),'G':'IGN_'+str(pins['G']),'H':'COIL_SUPPLY'}
        for func,pin,net,field_joint in [('PWR','H','COIL_SUPPLY','SP071'),('PG','A','ENGINE_GND','GP009'),('SG','E','R3_SG','SP062')]:
            hub='OEM'+ref[1:]+'-'+func
            assert nodes[hub]['kind']=='supplier_junction'
            linked(field_joint,ref+'/'+pin,net,'C')
            linked(ref+'/'+pin,hub,net,'S')
            for cylinder in cylinders:linked(f'IC{cylinder}/{func}',hub,net,'S')
        for pin,cylinder in pins.items():
            linked(ref+'/'+pin,f'IC{cylinder}/SIG','IGN_'+str(cylinder),'S')
            linked('J10/'+str(26+cylinder),ref+'/'+pin,'IGN_'+str(cylinder),'C')
    for bank,cylinders in [('ODD',[1,3,5,7]),('EVEN',[2,4,6,8])]:
        hub='OEM-INJ-'+bank;cut='CUT-INJ-'+bank+'-PWR'
        assert nodes[cut]['kind']=='integration_boundary'
        linked('SP070',cut,'INJECTOR_SUPPLY','C');linked(cut,hub,'INJECTOR_SUPPLY','S')
        for cylinder in cylinders:linked(f'INJ{cylinder}/PWR',hub,'INJECTOR_SUPPLY','S')
    for cylinder in range(1,9):
        cut='CUT-INJ'+str(cylinder);net='INJ_'+str(cylinder)
        linked('J10/'+str(cylinder),cut,net,'C');linked(cut,f'INJ{cylinder}/DRV',net,'S')
    # No retained stock device branch is still called a new C field wire.
    assert not any(e['kind']=='C' and any(a.startswith(('IC','INJ')) for a in [e['a'],e['b']]) for e in edges)
    assert len([e for e in edges if e.get('assembly_id','').startswith('A-OEM-COIL')])==38
    assert len([e for e in edges if e.get('assembly_id')=='A-OEM-INJ'])==18
    assert not set(model['retired_connection_ids']) & {e['id'] for e in edges}
    with (Path(__file__).resolve().parent/'Race_Car_RevJ/OEM_Harness_Interfaces.tsv').open(newline='',encoding='utf-8') as f:
        rows=list(csv.DictReader(f,delimiter='\t'))
    assert len(rows)==32
    for ref,pins in [('X111',{'B':7,'C':5,'F':3,'G':1}),('X113',{'B':2,'C':4,'F':6,'G':8})]:
        assert {r['Reference_terminal']:int(r['Cylinder_or_bank']) for r in rows if r['Interface']==ref and r['Function']=='Individual ignition trigger'}==pins
    # Other branch records, cavities, isolated battery and electronic-output
    # safety contracts remain independently checked by existing validators.
