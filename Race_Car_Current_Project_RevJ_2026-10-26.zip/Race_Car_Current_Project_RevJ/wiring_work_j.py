"""Construction/material classification independent of stable conductor IDs."""
import json
from pathlib import Path
from functools import lru_cache
CONSTRUCTION=Path(__file__).resolve().parent/'Race_Car_RevJ/Harness_Construction.json'
WORK_CLASSES={
 'C':{'label':'ADDITIONAL WIRE / INTEGRATION','tag':'MAKE','action':'Provide this connection using suitable new or donor wire. Check available supplied branch leads first; route and terminate as required.'},
 'F':{'label':'SUPPLIED LEAD - FINISH ENDS','tag':'LEAD','action':'Use the supplied harness lead at the controller end. Route, trim and terminate/join the free end. A schematic path may include an extension, mating pigtail or adapter; verify reach and actual supplied construction before adding wire.'},
 'S':{'label':'EXISTING / SUPPLIED LOOM','tag':'LOOM','action':'Retain this wire inside its OEM/vendor loom. Connect or terminate the assembly ends as required; do not fabricate a duplicate branch.'},
 'V':{'label':'SUPPLIED CABLE','tag':'CABLE','action':'Connect the intact vendor cable assembly; do not fabricate its internal conductors.'},
 'I':{'label':'INTERNAL CONNECTION','tag':'INTERNAL','action':'Internal device/common-metal continuity; no separate wire to make.'},
 'B':{'label':'BOND / METAL CONTACT','tag':'BOND','action':'Provide/verify the documented bolted or structural bond. This record is not a separate cut wire.'},
 'U':{'label':'UNRESOLVED','tag':'HOLD','action':'Supplier-internal path unresolved. Verify supplier construction; do not invent a new wire.'}
}
@lru_cache(maxsize=1)
def construction_map():
 return json.loads(CONSTRUCTION.read_text(encoding='utf-8'))['connections']

def work_info(edge):
 record=construction_map()[edge['id']]
 return {**WORK_CLASSES[record['code']],**record}

def route_label(edge):
 return edge['id']+' / '+work_info(edge)['tag']+' / '+edge['net_id']

def write_work_lists(model, directory):
 import csv
 groups=[('Wires_To_Provide.tsv',{'C'}),('Supplied_Leads_To_Finish.tsv',{'F'}),('Existing_Loom_And_Cable_Paths.tsv',{'S','V'}),('Other_Connection_References.tsv',{'I','B','U'})]
 fields=['ID','Build_category','Action','From','To','Net_ID','Net_Name','Assembly','Length_mm','Gauge_AWG','Status','Connection_basis']
 for filename,kinds in groups:
  with (directory/filename).open('w',newline='',encoding='utf-8') as f:
   w=csv.writer(f,delimiter='\t');w.writerow(fields)
   for e in model['connections']:
    info=work_info(e)
    if info['code'] not in kinds:continue
    w.writerow([e['id'],info['label'],info.get('note',info['action']),e['a'],e['b'],e['net_id'],e['net'],info.get('assembly',e.get('assembly_id','')),
                e['length_mm'] if e['length_mm'] is not None else 'UNMEASURED',e['gauge_AWG'] or 'UNRELEASED',e['release'],e['basis']])
