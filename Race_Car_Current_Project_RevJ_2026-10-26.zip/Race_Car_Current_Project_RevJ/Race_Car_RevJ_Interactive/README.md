# Revision J interactive wiring viewer

Open Race_Car_RevJ_Interactive.html in Chrome, Edge or Firefox. It is a standalone
offline file with both full-harness and power-only drawings embedded. No install,
server, account, internet connection or external library is needed.

The viewer opens with C023, the shared starter cable, selected as an example.
Click a wire to highlight its complete path and endpoints. Switch Wire / Net to
trace all branches on that electrical net. Ctrl-click (Command-click on Mac) adds
or removes wires from a multiple
selection. Normal click replaces the selection. Ctrl-click also works on wire
search results and connection-list entries. Net mode traces each selected wire's
net separately; it does not join different nets. Fit selection includes all of
the selected wires; Clear or Escape removes the complete selection. Bookmarked
URLs preserve multiple selected IDs. Switching to power-only retains only
selected wires in that scope. Dim others makes the selected paths
stand out. Wheel to zoom around the pointer; drag to pan. Fit selection includes
the selected paths and their endpoint components. Endpoint buttons jump to the
actual component or joint. Search by conductor C023, net W001, component M1,
splice SP062, device name or terminal (for example M1/B+). Search also finds full
harness items while in power-only view and switches scope when needed.

Click a component box to inspect its connections. A splice box selects its net.
Net highlighting stops at device terminals; it does not cross fuses/contactors,
join CAN H/L, or treat crossing lines as connected. Internal terminal-block metal
and shared-stud connections are explicit. I/B/U continuity and V intact vendor
cables remain distinct from individual C wires and supplied-loom S paths.

Chassis returns are short stubs ending in labelled ground symbols. W IDs retain
electrical identity; GP129-F/C/R identify proposed front/control/rear landing
points. Symbolic B005/B006 chassis-structure bonds are selectable references,
not extra wires drawn between those points. Ground-point endpoint zoom chooses
the symbol for the selected wire. Stub lengths are graphic, not measured cuts.
Sensor/CAN returns, engine returns and isolated battery negative stay explicit.

The retained L94 coil looms are shown through X111 (odd cylinders) and X113
(even cylinders), with their existing internal shared feeds and returns. OEM
bank cavities are reference information pending actual donor verification.
S paths with A-OEM assembly identities are retained stock wiring, not new cut
wires. Injector CUT-INJ nodes are functional cut/termination boundaries, not
factory connectors. Keep the donor injector-only feeds isolated from coil feeds:
never bridge the R3 HCO1 and HCO2 outputs. Final coil low-reference grounding
remains a documented hold; the viewer does not approve a W009/W062 bond.

Escape clears the selection (or closes search first). The address hash records
the selected wire/net/component so a bookmarked file URL can reopen that trace.
The file is read-only with respect to the engineering model and does not modify
native schematics, proposed topology, PDF files or NSP settings.

This is a proposed physical connection topology, not a fabrication release.
Splice/ground locations, materials, cut lengths, hardware and all existing design
holds remain open. The geometry illustrates connectivity, not measured routes.

Rebuild with build_interactive_j.py after the current physical PDFs validate;
validate_interactive_j.py verifies route/native equivalence and embedded data.
Normal rebuild_current.py also includes these steps. Do not hand-edit the
generated HTML or Viewer_Data.json; change the maintained template/builder or
authoritative engineering sources and rebuild.

## Component explanations

Click a component box or choose Explain a component in the sidebar. Each of the 95 native component references has a plain-language description, function and project-specific note. The selected box and its incident paths highlight; the Construction filter applies to those paths. Endpoint traces also offer Explain buttons. Selecting a full-harness component from power-only switches scope automatically. K1 and S2 are removed. R3 C5/SPI1 is spare; no clutch/neutral input or jumper. U3 is the selected Cole Hersee 24059 starter relay; its explanation lists the four threaded studs and the D60 coil-diode polarity. PWR/OUT/CMD/GND are installer tags, not stamped factory numbers. Actual starter current, F5 coordination and disengagement tests remain open.

## What you need to build

Read the MAKE / LEAD / LOOM / CABLE / HOLD tag on each path, rather than its ID prefix. IDs are retained for traceability. Use the Construction filter to inspect added wiring, supplied lead end work, existing looms or intact cables. Net mode respects that filter; choose All construction to trace the entire net. Searching a hidden wire restores All construction.

LEAD means supplied controller/kit-side wire, still requiring routing and end work, and possibly an extension, adapter or mating pigtail. R3 HT-183200 and PD16 HT-188000 catalog references are recorded; inspect actual harness labels/revisions and reach. Do not assume every displayed end-to-end span is a finished supplied cable. Main heavy feeders are separate. Factory CAN connectors require the dedicated PD16 wake-positive isolation: no cockpit-positive bridge.

The complete Delta sensor/control loom, supplied fuses, pressure returns and IMU/private CAN stay intact. C158 is a held supplier-routing reference, not a wire to fabricate. Its old ground-enable representation conflicts with current hardware-OFF wording; verify the received loom. IMU cavities and public/private HCU pair mapping remain unconfirmed.

Four TSV work lists are packaged with this viewer. They contain connection references, not measured cut lengths. Additional-wire entries beyond shared joints may use suitable supplied branch leads after inspection. No new wire is automatically required solely because a proposed splice is drawn.
