# Crank sensor research and selected Revision H basis

## Owner identification - 23 October 2026

Owner confirms the installed crankshaft sensor is **GM 12703627**. GM's official parts catalog identifies it as a three-terminal crankshaft position sensor. Dealer catalogs identify12703627 as the58x replacement for12585546; that cross-reference is catalog evidence, not a sensor electrical datasheet. The part-identity portion of S02 is resolved. Do not ask for the part number again.

H's existing A=signal to R3 C1, B=return to C26, C=regulated5V from C25 connection remains the selected factory-style basis. Reviewed GM application documents give that pinout and5V supply. The reviewed official12703627 product listing does not specify operating range or current. Haltech's generic Gen IV guide uses12V; FuelTech LS550 manual section7.2 also lists12V at C for12585546. Preserve this distinction between supported application wiring and an unpublished full operating range. Do not infer5V-only operation, automatic12V damage, or a new12V wiring decision.

Sources refreshed23October2026:

- [GM official12703627 product](https://parts.gmparts.com/product/gm-genuine-parts-engine-crankshaft-position-sensor-12703627): identity and three terminals; no voltage/current specification found.
- [GM Performance Motor dealer catalog](https://www.gmperformancemotor.com/parts/12703627.html):58x title and older12585546 reference.
- [Dealer supersession listing](https://www.gmpartsgiant.com/parts/gm-sensor-asm-cr-shf-posn-12703627.html):12703627 replaces12585546.
- [FuelTech manufacturer LS550 manual](https://files.fueltech.net/manual/Ingles/LS550%20Manual.pdf), version1.4 June2025, section7.2 printed page12:12585546 crank A=signal/B=negative/C=switched12V. This is a different ECU harness; its grounding/configuration is not copied to the R3.

Remaining S02 work: actual mating orientation; sensor current and aggregate C25 supply/C26 return budgets; supply applicability; correct Hall input/reference/pull-up/edge and actual cranking sync/timing. Part number alone does not prove the installed reluctor wheel, software trigger settings or sensor waveform. No schematic or supply connection changed in this research update. W078 stays retired.

## Original Revision H research - 22 October 2026

At the original review, the engine was identified by the owner as2011 Yukon Denali L94 and the installed sensor part number had not yet been supplied. H adopted regulated5V, A signal/B low reference/C supply, as the requested drawing basis. The dated research below is retained; its request to identify the part is superseded by the owner confirmation above.

| Evidence | Finding | Applicability |
|---|---|---|
| GM service information,2009 Yukon XL2WD, connector end-view table, CKP section | A signal, circuit6271, WH/BK; B low reference6272, GY/BK; C5V reference6270, PU/WH. Listed connector12129946/service88987997, grey3-way sealed Metri-Pack150. | Factory GM document reproduced by an independent archive; related Yukon reference, not exact2011 L94 verification. Colors/part numbers are reference evidence, not inspected donor-harness claims. |
| GM service diagnostics,2009 Yukon Denali, CKP | Diagnostic supply check at terminalC is4.8-5.2V. | Related model-year factory reference. |
| GM service diagnostics,2011 Camaro6.2L, P0335 | Prior indexed review corroborated5V three-wire Hall sensor and A/B/C functions. | Same-generation corroboration, different vehicle/engine application. Exact page retrieval is intermittent; the22Oct refresh failed. |
| MegaSquirt MS3XV3.0 hardware manual1.5, section5.2.7 | Manufacturer58x wiring guidance corroborates5V and A signal/B return/C supply. | Different ECU documentation; corroboration, not Haltech configuration instructions. |
| Haltech LS2-LS3 Gen4 engine guide, Crank Sensor table | A Trigger+, B signal ground, C12V. Describes58x/60-2 Hall sensor. | Direct manufacturer guide; conflicts with GM5V supply basis and is explicitly retained as conflicting evidence. |

Sources:

- [GM2009 Yukon connector table](https://gm.saturn.team/GMC_Truck/Yukon_XL___2WD/2009/99/10/7709/164814), CKP subsection, archive lines2555-2572 in the reviewed text.
- [GM2009 Yukon Denali diagnostics](https://gm.saturn.team/GMC_Truck/Yukon_Denali/2009/99/31/7714/144575).
- [GM2011 Camaro6.2 P0335](https://charm.li/Chevrolet/2011/Camaro%20V8-6.2L/Repair%20and%20Diagnosis/A%20L%20L%20%20Diagnostic%20Trouble%20Codes%20%28%20DTC%20%29/Testing%20and%20Inspection/P%20Code%20Charts/P0335/).
- [MegaSquirt manufacturer manual](https://www.msextra.com/doc/pdf/MS3XV30_Hardware-1.5.pdf).
- [Haltech Gen4 guide](https://support.haltech.com/portal/en/kb/articles/ls2-ls3-gen-4-engine).
- [Exact2011 Yukon Denali6.2 service-tree entry](https://charm.li/GMC/2011/Yukon%20Denali%202WD%20V8-6.2L/Repair%20and%20Diagnosis/); exact CKP connector/diagnostic contents were not successfully recovered in the prior research.

Selected mapping is B1A -> R3C1/Trigger+, B1B -> R3C26 sensor return, B1C -> R3C25 regulated5V. W044signal and W062return are retained. Supply joins existing W061R3_REF5; W078placeholder is retired without reuse. C2 Trigger- remains NC for the proposed Hall interface. The cam placeholder W079 is unchanged.

Before hardware power: identify the sensor by actual part marking, match molded terminal letters and correct connector viewing side, resolve supply applicability for that exact part, determine maximum current and sum all C25 loads against200mA. Check Hall input configuration, required pull-up, signal edge, cranking waveform/synchronization and timing with the actual engine. No max12V tolerance, sensor current, edge or timing offset is inferred from the chosen5V factory wiring basis. Sensor body/connector color alone is insufficient proof of the installed part.

Downloaded-file status, hashes and failures are recorded in Crank_Source_Downloads.json if a download was attempted. An archived HTML file may be an access/challenge page; a successful HTTP response alone does not prove its technical content. This research note preserves the reviewed findings and conflict independently of network availability.
