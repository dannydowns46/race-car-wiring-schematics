"""Audit proposed locations and individual four-end joints; never infer cut lengths."""
from pathlib import Path
import json,csv
from collections import Counter
from wire_specifications_j import wire_spec
R=Path(__file__).resolve().parent;D=R/'Race_Car_RevJ';ROUTING=D/'Harness_Routing.json'

def routing():return json.loads(ROUTING.read_text(encoding='utf-8'))

def joint_records(top):
    plan=routing();result={}
    for node in top['nodes']:
        if node['kind'] not in ['splice','can_splice']:continue
        ends=[e for e in top['connections'] if node['id'] in [e['a'],e['b']]]
        sizes=[wire_spec(e)['awg'] for e in ends]
        area=sum(.012668*92**((36-g)/19.5) for g in sizes) if all(g is not None for g in sizes) else None
        # Nominal copper area, not insulation diameter, barrel fit or crimp approval.
        result[node['id']]={'total_ends':len(ends),'max_total_ends':plan['joint_limit']['max_total_wire_ends'],
            'connections':[e['id'] for e in ends], 'nominal_total_mm2':round(area,3) if area is not None else None,
            'tool_status':'SIZE HOLD' if area is None else 'LARGER TOOL/SPLICE REQUIRED' if area>plan['joint_limit']['budget_tool_nominal_max_mm2'] else 'QUALIFICATION REQUIRED',
            'location':plan['joint_locations'].get(node['id'])}
    return result

def audit(top):
    plan=routing();records=joint_records(top)
    for id,joint in records.items():
        assert 2<=joint['total_ends']<=joint['max_total_ends'],(id,joint)
        assert joint['location'],('Missing proposed location',id)
    assert all(b['length_mm'] is None for b in plan['branches'].values()),'No route length inferred from perspective'
    assert len(top['connections'])==299
    assert all(e['net']=='R3_SG' for e in top['connections'] if e['id'] in [f'C{i}' for i in range(224,232)])
    assert 'stock' in plan['locations']['B6']['description'].lower() and 'temperature' in plan['locations']['B32']['description'].lower()
    assert 'inboard' in plan['locations']['B22']['description'].lower() and 'inboard' in plan['locations']['B23']['description'].lower()
    return {'result':'PASS','custom_joints':len(records),'max_total_ends':max(j['total_ends'] for j in records.values()),
        'ends_histogram':dict(Counter(j['total_ends'] for j in records.values())),
        'larger_tool_splice_holds':[id for id,j in records.items() if j['tool_status']=='LARGER TOOL/SPLICE REQUIRED'],
        'unknown_area_holds':[id for id,j in records.items() if j['nominal_total_mm2'] is None],
        'native_electrical_change':False,'cut_lengths_inferred':False}

def schedules(top):
    report=audit(top);records=joint_records(top);byid={e['id']:e for e in top['connections']}
    with (D/'Splice_Connections.tsv').open('w',encoding='utf-8',newline='') as f:
        w=csv.writer(f,delimiter='\t');w.writerow(['Joint','Net','Total_wire_ends','Wire','Other_end','Recommended_AWG','Gauge_status','Nominal_total_mm2','Tool_status','Proposed_location'])
        for id,j in records.items():
            for eid in j['connections']:
                e=byid[eid];s=wire_spec(e)
                w.writerow([id,e['net_id'],j['total_ends'],eid,e['b'] if e['a']==id else e['a'],s['awg'] if s['awg'] is not None else '',s['status'],j['nominal_total_mm2'] or 'UNKNOWN',j['tool_status'],j['location']['description']])
    (D/'Harness_Planning_Validation.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    return report

if __name__=='__main__':
    from physical_topology_j import load_and_audit
    _,top=load_and_audit();print(json.dumps(schedules(top),indent=2))
