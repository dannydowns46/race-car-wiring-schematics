Latest release13Nov2026: 2026-11-13-4. Bird’s-eye vehicle layout, selectable T01-T12 trunk/branch groups, compact collision-free overview labels and retained Circuit / rows. All301 physical paths and116 electrical nets unchanged; underlying four engineering JSON sources byte-identical. All23 hosted and committed files match. Extracted project checks pass. See preview/Publication_Verification_2026-11-13-4.json and Live_Vehicle_Layout_2026-11-13-4.png. Earlier dated notes are historical.

Latest release13Nov2026: 2026-11-13-2. Haltech lead filters,172 gauge annotations,34 custom joints with at most4 total ends, and owner-informed tunnel/branch locations. All21 hosted and committed files match prepared bytes. Live SP062 joint and route-plan panel verified. Current counts301 full/146 power paths;116 electrical nets unchanged. See preview/Publication_Verification_2026-11-13-2.json and Live_Harness_Plan_2026-11-13-2.png. Earlier dated notes below are historical.

Latest release27Oct2026: S50 HT-010504 traction-control selector on R3 C5/SPI1. All18 hosted files match prepared release bytes, including preserved26Oct archive. Live component table and C216 trace verified. See preview/Publication_Verification_2026-10-27.json and Live_S50_2026-10-27.png. Earlier initial-publication notes below are historical.

# Public wiring schematic hosting

Owner approved public access on 26 October 2026 and completed GitHub sign-in.
LIVE: https://dannydowns46.github.io/race-car-wiring-schematics/
Repository: https://github.com/dannydowns46/race-car-wiring-schematics
The site is published from main / (root), using Deploy from a branch and .nojekyll.
All17 hosted files match the prepared release byte for byte through anonymous HTTP.
The live browser verified U3, its four-stud table, the spare C5 note, absence of S2
and Ctrl-click multi-wire tracing. See preview/Publication_Verification.json.

The Sites connector was unavailable, so GitHub Pages is the configured provider.
Upload the CONTENTS of dist/ to the main-branch ROOT, not the parent directory.
Do not enable the optional dist-based Actions workflow for this root layout.
The public repository includes a README and .gitattributes for future maintenance.
Large web uploads needed separate commits: documents, standalone viewer, then
project ZIP. Keep each browser-upload batch below25MB; actual complete release
can exceed that total. No personal access token was created or persisted.

The authoritative design stays in the parent project. This folder holds the publishing
tools and generated static site. `dist/` contains an unchanged copy of the validated
interactive HTML, the three current PDFs, a companion native PDF for existing links,
four construction schedules, a current rebuildable project ZIP and release metadata.
`publishing.json` records the selected provider, access and verified URL once available.
Do not replace the interactive viewer with a newly implemented drawing application.

## Future requested updates

1. Read the parent AGENTS.md and handoff documents; change maintained design sources.
2. Run the normal complete rebuild, inspect affected drawings and check the viewer.
3. Run `python Public_Site/prepare_release.py --date YYYY-MM-DD` from any directory.
   Use the user's America/Chicago date. This checks current engineering outputs and
   refreshes the public assets; it never changes electrical assignments.
4. Review `Public_Site/preview/Release_Validation.json`. Existing dated release ZIPs
   remain available; filenames from released downloads must not be silently reused
   for different bytes. Use `--release-id` for an additional release on the same day.
5. Publish the refreshed `dist/` files to the SAME repository/site, retaining its public
   audience and stable homepage/viewer paths. Verify the deployed URL and release ID.
6. Record deployment evidence/URL in publishing.json. Commit/push no credentials,
   local scratch folders, private machine configuration or unrelated workspace files.

GitHub Pages can publish these files from a public repository's main-branch root
with `.nojekyll`, or from `dist/` using the included Actions workflow. Pick one actual
layout during setup and record it; do not guess a GitHub username or site URL.

The project ZIP is the maintained current-revision working set plus required frozen
I baseline files and source references. It is not an archive of every historical
revision, old transfer ZIP, CAD project or unrelated local file. Its inventory and
SHA256 manifest define the exact included files. The old 23 October complete ZIP
elsewhere in the workspace is historical and must not be advertised as current.

No ongoing scheduled job is created. On future user requests, rebuild and republish
through the configured account. This does not update a website merely because a
local file changed.
