## 15 November 2026 - external starter diode removed

Owner removes D60 external coil diode. C213/C214 are permanently retired; U3 Cole Hersee24059 retains C025/C026/C027/C180 and R3 A18/HBO5 control. W014/W129 and all other net assignments remain. This supersedes older instructions to fit D60. No claim of Haltech approval or powered relay/output verification; C19 remains open. Current counts:95 parts/415 pins/356 connected/59 NC/116 nets;299 full/144 power physical paths and24 ground glyphs. Both online layouts derive from this same model.

## 13 November 2026 — bird’s-eye viewer and loom groups

The ONLINE viewer now defaults to a loose car plan: FRONT LEFT, DRIVER SIDE
BOTTOM. Vehicle_Layout.json maintains display positions and proposed loom
corridors only. vehicle_layout_j.py derives both full/power vehicle views from
the same301 physical records; validate_vehicle_layout_j.py checks IDs/ends/nets,
all417 pins/59NC, component and splice clearance and retained ground references.

Select a trunk band or use Trunk or branch to inspect T01-T12 connection groups.
Bands do not electrically join wires, prescribe cable diameter or establish cut
lengths. Local paths stay local; long front/rear spans use the proposed tunnel
corridor. Individual wires appear on zoom and selections trace end-to-end.
Circuit / rows remains available; switching layouts preserves wire selections.
Full/power share positions. Unconfirmed pressure-sensor locations are separate.

Physical_Topology.json, Design_Data.json, Wire_Specifications.json and
Harness_Routing.json are BYTE-IDENTICAL to the prior release. No pin, net,
allocation, splice assignment, gauge, material or entered measurement changed.
Only vehicle display geometry and viewer controls were added. The maintained
builder/validator include both layouts; generated HTML/SVG/data are not edited.
Historical two-row presentation notes below apply to Circuit / rows.

## 13 November 2026 — current physical harness plan

The interactive ONLINE schematic remains the requested deliverable. Owner CAD
walkthrough establishes R3/PD16 behind driver seat, tunnel-first routing and
regional branches. Read Harness_Routing.json, Wire_Specifications.json and
Splice_Connections.tsv under Race_Car_RevJ. Locations distinguish owner statements
from design proposals; all cut lengths remain unmeasured/unreleased. CAD/video
source files are local review evidence and are not part of public downloads.

HT-R3/HT-PD16 identify 75 supplied Haltech lead paths. Asterisked gauge annotations
are proposals/manufacturer baselines, not inspected material. Existing material
and measurement fields are preserved. Custom joints have at most FOUR TOTAL wire
ends including inter-joint links. Retained OEM/Delta internal joint construction
remains unknown. SP070/SP071/SP116 exceed the budget tool nominal6mm2 envelope;
larger matched splice/tool qualification remains a fabrication hold.

All287 retained paths preserve IDs, nets and material fields;28 joint ends are
redistributed and14 links C218-C231 are added. Current301 full /146 power paths;
native remains96 parts/417 pins/358 connected/59NC/116nets. S50 reference/return
now land at SP061-C2/SP062-C2, retaining W061/W062 and C215/C217. C216 still uses
R3 C5/SPI1/W137, pull-up OFF. No electrical allocation or extra I/O changed.

Owner corrections: rearward LS3 throttle despite CAD front-facing placeholder;
rear speeds read inboard CV tone rings; only driver tank has fuel sender; engine
oil temperature at remote filter, stock oil pressure at engine. Exact oil-pressure
part/cavities/calibration remain unverified. Main fuses/blocks/relay positions,
connector orientation, grommets and removable interfaces remain proposed.
Later entries below are historical where this amendment supersedes them.


## 27 October 2026 - current HT-010504 TC selector / online-first delivery

Owner selects Haltech HT-010504 as S50, a 12-position traction-control level selector.
Module DTM3 pin1/red -> R3 C25 regulated5V via SP061/W061; pin2/white ->
R3 C5/SPI1 on new W137 TC_TRIM_SIG; pin3/black -> R3 C26 via SP062/W062.
Pull-up MUST be OFF. Use the manufacturer HT-010504 calibration matching the
fitted decal; verify molded numbering using the harness-side view. Colours refer
to module leads. Reference/return current, reach/materials and actual hardware
remain to verify. S2 remains absent; W046/C076/C123 stay retired; no start interlock.
This latest C5 allocation supersedes earlier spare/unconnected statements.

Four wheel sensors still feed Delta only; public CAN2 wheel speeds feed R3 TC.
No raw-sensor split, CAN node, extra PDM or output allocation is added. Use rotary
position as the TC Desired Slip and/or Cut Percentage table axis; level direction,
slip/cut values, any OFF detent and invalid-input/CAN response remain tuner choices.
See Traction_Control_Selector.json and C21. No installed NSP setup or powered test.
R3 retains AVI9/C18 and four SPIs C7/C8/C19/C20; PD16 retains two spare AVIs.

New physical paths C215/C216/C217 preserve every retained record and measurement;
C216 uses the supplied R3 flying lead; reference/return branches require grouped
tail/reach inspection. 96 parts /417 pins /358 connected /59NC /116nets;
287 full physical paths, unchanged145 power paths. Source/model checks are retained
to support the interactive view. The owner requests the interactive ONLINE schematic
as the deliverable from here forward; no separate PDF delivery is required.

# Project orientation for Codex

Read `START_HERE.md`, `CODEX_HANDOFF.md`, `Vehicle_Wiring_Design_Basis.md`, `Race_Car_RevJ/README.md` and `OPEN_ITEMS.tsv` before modifying the design. This is the owner's portable handoff of an ongoing race-car harness project.

- Revision J is current; A-I and the uC-10 CAD are historical. Preserve owner decisions summarized in CODEX_HANDOFF.md. A user instruction overrides this orientation.
- Current native source is generated by `build-racecar-revj.js`; continuous view by `build_single_page_j.py`. Current authoritative pin/net model is `Race_Car_RevJ/Design_Data.json`, checked against fresh KiCad exports. Make coordinated edits rather than letting PDFs, schedules and native files disagree.
- Run `rebuild_current.py --help` for a portable rebuild. Do not run legacy prepare/finish scripts as the default build; some use original-computer paths or recreate historical outputs. `prepare-revh.py` deliberately regenerates H scripts from G and will overwrite manual H script edits; it is a migration record, not the normal build entry point.
- Preserve net identifiers for retained circuits and never reuse retired identifiers such as W078. W identifiers name electrical nets, not individual branch conductors or cutting lengths.
- Keep documented cavities distinct from functional/TBD terminals. Do not turn open technical questions into confirmed specifications. Record source conflicts and actual hardware/configuration evidence as they are resolved.
- Verify native connectivity and continuous PDF equivalence after wiring changes; render/inspect changed drawing pages. The passive harness symbols do not establish full electrical ERC. Existing checks do not prove real-world hardware operation.
- Neither installed NSP configurations nor a final wire-size/protection/route/cut schedule exists yet. Use the explicit open items when planning that work.

- Read the current J protection/control/commissioning files. H audit is historical; use J/Audit_Disposition.tsv. create_revision_i.py and Revision_I_Work scripts are one-time migration records and must not overwrite maintained I source/evidence during normal builds.

- J retains one R3 onboard wideband; B9 sensor type/adapter/cavities remain unselected. Transmission HT-010306 B33 uses PD16 A21/AVI2 and A11 return; B32 engine oil stays A20/AVI1. Two PD16 AVIs remain spare. Revision_J_Work scripts are one-time migration records; do not rerun them over maintained J source.

- 25 October J update integrates ordered CARTEK GT, ONE BAOMAIN internal latching NC stop only, and joined blue/blue loop W136. S41 and W004 are retired; do not reuse. Confirm received GT-s/GT-x variant and actual NC markings. GT has distinct M6_BAT/M6_IGN studs and fixed40A output; no X-Pro DT numbering or selectable5A setting. K1 remains physical main-positive cutoff; F4 5A stays proposed.
- TB1 Sierra FS46540 and TB2 Summit SUM-900533 are PROPOSED parts only. Functional TB ports identify common-bus branch/lug intent, not numbered physical studs or extra cut wires. See Distribution_Blocks.json and P07/C16 for rating/stack/cover holds.
- Power-only continuous view is generated by build_power_systems_j.py and checked by validate_power_systems_j.py, both included in rebuild_current.py. It shows complete selected power nets with other pins omitted, not declared NC. Change_Records scripts are one-time records; do not rerun them over maintained sources.

- 25 October physical-view update: both continuous PDFs now render individual C conductors, S supplied paths, V intact cable assemblies, explicit splice/ground nodes, and distinct I/B/U non-cut-wire continuity. Native electrical nets are unchanged. Current power PDF is Race_Car_RevJ_Power_Only_Physical_Wiring.pdf; older power Continuous PDF is superseded.
- Physical_Topology.json is the maintained proposed connection model; preserve entered measurements, endpoint/ID records and material fields. physical_topology_j.py normally audits and derives schedules; --initialize refuses an existing file and must not be used to overwrite measurements. render_physical_j.py / validate_physical_j.py are called by current build/validate wrappers. Splice/ground layouts, CAN station order, material and cut lengths remain proposed/unreleased; W IDs remain electrical nets.


## Interactive wire tracing - 25 October

Open `Race_Car_RevJ_Interactive/Race_Car_RevJ_Interactive.html` in a modern browser,
or transfer `Race_Car_RevJ_Interactive/Race_Car_RevJ_Interactive_Viewer.zip` and
extract it first. The standalone file embeds both physical-conductor drawings
and all tracing data; it needs no server/install/internet. The local browser
preview is for review only; the standalone file/ZIP is the portable deliverable.

Click a wire to highlight its path and endpoints. Wire/Net chooses one conductor
or every branch of the same electrical net. Dim others, Fit selection, Overview,
scroll zoom, drag pan, endpoint zoom buttons and ID/name/terminal search are
included. The initial example is C023, the shared starter cable. Full-harness-only
search results switch scope automatically. The URL hash can bookmark a selection.

This read-only derived view changes no native or physical topology assignments.
It retains all 117 full-harness nets (44 power-only) and 288 selectable connection
records (147 power), including explicit internal block metal. Internal/bond/
unresolved paths and intact cable assemblies remain distinct from cut wires.
Existing material, physical location, rating, hardware and fabrication holds apply.

Maintain `interactive_viewer_j.html` and `build_interactive_j.py`; generated HTML
and Viewer_Data.json must not be hand-edited. `validate_interactive_j.py` checks
embedded metadata and drawing paths against the current model and validated PDF
manifests. Both are integrated into `rebuild_current.py`; read Viewer Validation
and Browser_QA.json alongside the native/physical validation reports. Regenerate
after a changed physical drawing so the viewer cannot silently become stale.

Ctrl-click (Command-click on Mac) now adds/removes individual wires without clearing the others; normal click replaces the selection. This also works on wire search results and connection-list entries. Fit selection and Net mode apply to all selected wires; different nets remain separate. Clear/Escape removes all selections and bookmarked URLs preserve multiple IDs.

- Chassis-ground display uses short W129/GP129 and W015 symbol stubs in the continuous PDFs/viewer. ground_display_j.py is presentation policy only. Preserve sensor/CAN/engine and isolated battery return routing; no underlying physical wires are deleted. Validate actual ground glyphs and matching labels as well as drawn conductor segments.

- Current J retained-stock-loom update adds sheet19 and X111/X113: 96 parts/418 pins/359 connected/59 NC and the same117 W nets. Read Stock_Engine_Harnesses.json and OEM_Harness_Interfaces.tsv. Keep 56 OEM S paths distinct from C integration wires; CUT-INJ nodes are functional boundaries, not factory connectors. Preserve retired C IDs and all retained measurements. stock_engine_harness_j.py audits the model. Final coil low-reference grounding and HCO1/HCO2 donor-feed separation remain explicit holds; do not merge W009/W062.

- 25Oct latest owner update: K1 REMOVED. F0 feeds TB2 directly; W003 renamed MAIN_FUSED_BUS, W128 retired. C063/C064/C178/C179 retired; preserve IDs/measurements for retained paths. GT method1 M6_IGN -> S1 -> R3 A13; shutdown/PD16 safe states remain hardware holds. Physical fuses retained, Delta supplied fuses explicitly required.
- Owner uses complete Delta harnesses plus R3/PD16 flying-lead harnesses. Harness_Construction.json gives construction tags independently of C/S IDs; LEAD paths use supplied wire needing end work, not necessarily a fully finished span. C158 is a Delta switch-routing HOLD, not a wire to fabricate. Keep supplier pressure returns/IMU/private CAN intact. Current totals95parts/414pins/355connected/59NC/116nets;284 full and143 power paths,24 ground symbols.

- Latest U3 update: selected Cole Hersee24059, functional four-stud tags retained; external D60 1N5408 cathode/K toCMD W014 and anode/A toGND W129. Only C213/C214 added as local supplied diode leads; no new I/O or W net. Read Starter_Relay.json and C19. Current96parts/416pins/357connected/59NC/116nets;286full/145power paths;26ground glyphs. Actual hardware/F5 coordination and disengagement tests remain open.

- Latest S2 owner update supersedes counts above: S2 removed; C076/C123 and W046 START_PERMIT retired permanently. R3 C5/SPI1 now spare/NC; no jumper or replacement neutral switch. Current95parts/414pins/354connected/60NC/115nets;284full/145power paths;26ground glyphs. Start control has no clutch/neutral input requirement; see C20.

- Public site published26Oct: https://dannydowns46.github.io/race-car-wiring-schematics/ ; repo dannydowns46/race-car-wiring-schematics. Public_Site/HOSTING.md and publishing.json record the identity. Keep same URL/repo; publish dist CONTENTS to main/root, not a nested dist folder. Regenerate/validate engineering before future requested publication; preserve dated ZIPs. Public scope approved; no scheduled job or stored token.
